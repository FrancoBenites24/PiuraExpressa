package com.piuraexpressa;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PiuraexpressaApplication {

    public static void main(String[] args) {
        SpringApplication.run(PiuraexpressaApplication.class, args);
    }
}
