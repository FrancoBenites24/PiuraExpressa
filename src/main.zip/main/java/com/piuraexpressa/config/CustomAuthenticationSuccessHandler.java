package com.piuraexpressa.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;

// Anotación para registrar logs con Lombok
@Slf4j
@Component
// Implementa la interfaz AuthenticationSuccessHandler para manejar eventos de éxito en autenticación
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    // Método que se ejecuta cuando la autenticación es exitosa
    @Override
    public void onAuthenticationSuccess(
            HttpServletRequest request, // Objeto que representa la solicitud HTTP
            HttpServletResponse response, // Objeto que representa la respuesta HTTP
            Authentication authentication) throws IOException, ServletException { // Información de autenticación

        // Obtener los roles o autoridades del usuario autenticado
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

        // URL de redirección por defecto para usuarios normales
        String redirectUrl = "/";

        // Verificar si el usuario tiene el rol de ADMIN
        boolean isAdmin = authorities.stream()
                .anyMatch(ga -> ga.getAuthority().equals("ROLE_ADMIN"));

        // Si es administrador, cambiar la URL de redirección a /admin
        if (isAdmin) {
            redirectUrl = "/admin";
        }

        // Registrar en el log el nombre del usuario y la URL a la que será redirigido
        log.info("User '{}' logged in, redirecting to '{}'", authentication.getName(), redirectUrl);

        // Redirigir al usuario a la URL correspondiente
        response.sendRedirect(redirectUrl);
    }
}
