package com.piuraexpressa.config;

import com.piuraexpressa.model.Permiso;
import com.piuraexpressa.model.Rol;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.PermisoRepository;
import com.piuraexpressa.repository.RolRepository;
import com.piuraexpressa.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final PermisoRepository permisoRepository;
    private final PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        initializePermissions(); // Inicializa permisos si no existen
        initializeRoles(); // Inicializa roles si no existen
        initializeUsers(); // Inicializa usuarios si no existen
    }

    // Método para inicializar permisos en la base de datos
    private void initializePermissions() {
        if (permisoRepository.count() == 0) {
            log.info("Inicializando permisos...");

            // Permisos para administración de roles
            Permiso adminRolesAccess = new Permiso("ADMIN_ROLES_ACCESS", "/admin/roles");
            Permiso adminRolesCreate = new Permiso("ADMIN_ROLES_CREATE", "/admin/roles/nuevo");
            Permiso adminRolesEdit = new Permiso("ADMIN_ROLES_EDIT", "/admin/roles/editar");
            Permiso adminRolesSave = new Permiso("ADMIN_ROLES_SAVE", "/admin/roles/guardar");
            Permiso adminRolesDelete = new Permiso("ADMIN_ROLES_DELETE", "/admin/roles/eliminar");

            // Permisos para administración de usuarios
            Permiso adminUsersAccess = new Permiso("ADMIN_USERS_ACCESS", "/admin/usuarios");
            Permiso adminUsersCreate = new Permiso("ADMIN_USERS_CREATE", "/admin/usuarios/nuevo");
            Permiso adminUsersEdit = new Permiso("ADMIN_USERS_EDIT", "/admin/usuarios/editar");
            Permiso adminUsersSave = new Permiso("ADMIN_USERS_SAVE", "/admin/usuarios/guardar");
            Permiso adminUsersDelete = new Permiso("ADMIN_USERS_DELETE", "/admin/usuarios/eliminar");

            // Permisos para administración de platos
            Permiso adminPlatosAccess = new Permiso("ADMIN_PLATOS_ACCESS", "/admin/platos");
            Permiso adminPlatosCreate = new Permiso("ADMIN_PLATOS_CREATE", "/admin/platos/nuevo");
            Permiso adminPlatosEdit = new Permiso("ADMIN_PLATOS_EDIT", "/admin/platos/editar");
            Permiso adminPlatosSave = new Permiso("ADMIN_PLATOS_SAVE", "/admin/platos/guardar");
            Permiso adminPlatosDelete = new Permiso("ADMIN_PLATOS_DELETE", "/admin/platos/eliminar");

            // Permisos para administración de eventos
            Permiso adminEventosAccess = new Permiso("ADMIN_EVENTOS_ACCESS", "/admin/eventos");
            Permiso adminEventosCreate = new Permiso("ADMIN_EVENTOS_CREATE", "/admin/eventos/nuevo");
            Permiso adminEventosEdit = new Permiso("ADMIN_EVENTOS_EDIT", "/admin/eventos/editar");
            Permiso adminEventosSave = new Permiso("ADMIN_EVENTOS_SAVE", "/admin/eventos/guardar");
            Permiso adminEventosDelete = new Permiso("ADMIN_EVENTOS_DELETE", "/admin/eventos/eliminar");

            // Permisos para administración de comentarios
            Permiso adminComentariosAccess = new Permiso("ADMIN_COMENTARIOS_ACCESS", "/admin/comentarios");

            // Permisos para administración de provincias
            Permiso adminProvinciasAccess = new Permiso("ADMIN_PROVINCIAS_ACCESS", "/admin/provincias");
            Permiso adminProvinciasCreate = new Permiso("ADMIN_PROVINCIAS_CREATE", "/admin/provincias/nueva");
            Permiso adminProvinciasEdit = new Permiso("ADMIN_PROVINCIAS_EDIT", "/admin/provincias/editar");
            Permiso adminProvinciasSave = new Permiso("ADMIN_PROVINCIAS_SAVE", "/admin/provincias/guardar");
            Permiso adminProvinciasDelete = new Permiso("ADMIN_PROVINCIAS_DELETE", "/admin/provincias/eliminar");

            // Permisos para administración de historia de provincias
            Permiso adminProvinciasHistoriaAccess = new Permiso("ADMIN_PROVINCIAS_HISTORIA_ACCESS", "/admin/provincias/historia");
            Permiso adminProvinciasHistoriaNuevo = new Permiso("ADMIN_PROVINCIAS_HISTORIA_NUEVO", "/admin/provincias/historia/nuevo");
            Permiso adminProvinciasHistoriaEditar = new Permiso("ADMIN_PROVINCIAS_HISTORIA_EDITAR", "/admin/provincias/historia/editar");
            Permiso adminProvinciasHistoriaGuardar = new Permiso("ADMIN_PROVINCIAS_HISTORIA_GUARDAR", "/admin/provincias/historia/guardar");
            Permiso adminProvinciasHistoriaEliminar = new Permiso("ADMIN_PROVINCIAS_HISTORIA_ELIMINAR", "/admin/provincias/historia/eliminar");

            // Permisos para administración de estadísticas de provincias
            Permiso adminProvinciasEstadisticasAccess = new Permiso("ADMIN_PROVINCIAS_ESTADISTICAS_ACCESS", "/admin/provincias/estadisticas");
            Permiso adminProvinciasEstadisticasNuevo = new Permiso("ADMIN_PROVINCIAS_ESTADISTICAS_NUEVO", "/admin/provincias/estadisticas/nuevo");
            Permiso adminProvinciasEstadisticasEditar = new Permiso("ADMIN_PROVINCIAS_ESTADISTICAS_EDITAR", "/admin/provincias/estadisticas/editar");
            Permiso adminProvinciasEstadisticasGuardar = new Permiso("ADMIN_PROVINCIAS_ESTADISTICAS_GUARDAR", "/admin/provincias/estadisticas/guardar");
            Permiso adminProvinciasEstadisticasEliminar = new Permiso("ADMIN_PROVINCIAS_ESTADISTICAS_ELIMINAR", "/admin/provincias/estadisticas/eliminar");

            // Permisos para administración de puntos de interés de provincias
            Permiso adminProvinciasPuntosInteresAccess = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_ACCESS", "/admin/provincias/puntos-interes");
            Permiso adminProvinciasPuntosInteresNuevo = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_NUEVO", "/admin/provincias/puntos-interes/nuevo");
            Permiso adminProvinciasPuntosInteresEditar = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_EDITAR", "/admin/provincias/puntos-interes/editar");
            Permiso adminProvinciasPuntosInteresGuardar = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_GUARDAR", "/admin/provincias/puntos-interes/guardar");
            Permiso adminProvinciasPuntosInteresEliminar = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_ELIMINAR", "/admin/provincias/puntos-interes/eliminar");
            Permiso adminProvinciasPuntosInteresActivar = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_ACTIVAR", "/admin/provincias/puntos-interes/activar");
            Permiso adminProvinciasPuntosInteresDesactivar = new Permiso("ADMIN_PROVINCIAS_PUNTOS_INTERES_DESACTIVAR", "/admin/provincias/puntos-interes/desactivar");

            // Permiso general de acceso (ACCESS)
            Permiso accessPermission = new Permiso("ACCESS", "ACCESS");

            // Guardar todos los permisos
            permisoRepository.save(adminRolesAccess);
            permisoRepository.save(adminRolesCreate);
            permisoRepository.save(adminRolesEdit);
            permisoRepository.save(adminRolesSave);
            permisoRepository.save(adminRolesDelete);

            permisoRepository.save(adminUsersAccess);
            permisoRepository.save(adminUsersCreate);
            permisoRepository.save(adminUsersEdit);
            permisoRepository.save(adminUsersSave);
            permisoRepository.save(adminUsersDelete);

            permisoRepository.save(adminPlatosAccess);
            permisoRepository.save(adminPlatosCreate);
            permisoRepository.save(adminPlatosEdit);
            permisoRepository.save(adminPlatosSave);
            permisoRepository.save(adminPlatosDelete);

            permisoRepository.save(adminEventosAccess);
            permisoRepository.save(adminEventosCreate);
            permisoRepository.save(adminEventosEdit);
            permisoRepository.save(adminEventosSave);
            permisoRepository.save(adminEventosDelete);

            permisoRepository.save(adminComentariosAccess);

            permisoRepository.save(adminProvinciasAccess);
            permisoRepository.save(adminProvinciasCreate);
            permisoRepository.save(adminProvinciasEdit);
            permisoRepository.save(adminProvinciasSave);
            permisoRepository.save(adminProvinciasDelete);

            permisoRepository.save(adminProvinciasHistoriaAccess);
            permisoRepository.save(adminProvinciasHistoriaNuevo);
            permisoRepository.save(adminProvinciasHistoriaEditar);
            permisoRepository.save(adminProvinciasHistoriaGuardar);
            permisoRepository.save(adminProvinciasHistoriaEliminar);

            permisoRepository.save(adminProvinciasEstadisticasAccess);
            permisoRepository.save(adminProvinciasEstadisticasNuevo);
            permisoRepository.save(adminProvinciasEstadisticasEditar);
            permisoRepository.save(adminProvinciasEstadisticasGuardar);
            permisoRepository.save(adminProvinciasEstadisticasEliminar);

            permisoRepository.save(adminProvinciasPuntosInteresAccess);
            permisoRepository.save(adminProvinciasPuntosInteresNuevo);
            permisoRepository.save(adminProvinciasPuntosInteresEditar);
            permisoRepository.save(adminProvinciasPuntosInteresGuardar);
            permisoRepository.save(adminProvinciasPuntosInteresEliminar);
            permisoRepository.save(adminProvinciasPuntosInteresActivar);
            permisoRepository.save(adminProvinciasPuntosInteresDesactivar);

            permisoRepository.save(accessPermission);

            log.info("Permisos inicializados correctamente");
        }
    }

    // Método para inicializar roles en la base de datos
    private void initializeRoles() {
        // Solo inicializa si no hay roles existentes
        if (rolRepository.count() == 0) {
            log.info("Inicializando roles...");

            // Obtener todos los permisos para asignar al rol ADMIN
            Set<Permiso> adminPermisos = new HashSet<>(permisoRepository.findAll());

            // Crear rol de administrador con todos los permisos
            Rol adminRole = Rol.builder()
                    .nombre("ADMIN")
                    .descripcion("Administrador del sistema")
                    .permisos(adminPermisos)
                    .build();

            // Crear rol de usuario regular (sin permisos administrativos)
            Rol userRole = Rol.builder()
                    .nombre("USER")
                    .descripcion("Usuario regular")
                    .permisos(new HashSet<>())
                    .build();

            // Crear rol de moderador (con algunos permisos)
            Set<Permiso> moderatorPermisos = new HashSet<>();
            permisoRepository.findAll().forEach(permiso -> {
                if (permiso.getNombre().contains("COMENTARIOS") || permiso.getNombre().equals("ACCESS")) {
                    moderatorPermisos.add(permiso);
                }
            });

            Rol moderatorRole = Rol.builder()
                    .nombre("MODERATOR")
                    .descripcion("Moderador de contenido")
                    .permisos(moderatorPermisos)
                    .build();

            // Guardar roles en la base de datos
            rolRepository.save(adminRole);
            rolRepository.save(userRole);
            rolRepository.save(moderatorRole);

            log.info("Roles inicializados correctamente");
        }
    }

    // Método para inicializar usuarios en la base de datos
    private void initializeUsers() {
        // Solo inicializa si no hay usuarios existentes
        if (usuarioRepository.count() == 0) {
            log.info("Inicializando usuarios...");

            // Obtener rol de administrador desde la base de datos
            Rol adminRole = rolRepository.findByNombre("ADMIN")
                    .orElseThrow(() -> new RuntimeException("Rol ADMIN no encontrado"));
            // Obtener rol de usuario desde la base de datos
            Rol userRole = rolRepository.findByNombre("USER")
                    .orElseThrow(() -> new RuntimeException("Rol USER no encontrado"));

            // Crear usuario administrador con datos predefinidos
            Usuario admin = Usuario.builder()
                    .email("francobenites24@gmail.com")
                    .username("blackHBT")
                    .password(passwordEncoder.encode("76540705"))
                    .nombres("Franco Alexis")
                    .apellidos("Benites")
                    .tipoDocumento(Usuario.TipoDocumento.DNI) // Tipo de documento DNI
                    .numeroDocumento("76540705")
                    .telefono("997068821")
                    .fechaNacimiento(LocalDate.of(2004, 7, 24))
                    .provincia("Piura")
                    .distrito("Piura")
                    .direccion("AA.HH Almirante Miguel Grau Mz O Lt 7")
                    .activo(true)
                    .roles(Set.of(adminRole))
                    .build();

            // Crear usuario regular con datos predefinidos
            Usuario user = Usuario.builder()
                    .email("user@piuraexpressa.com")
                    .username("user")
                    .password(passwordEncoder.encode("user123"))
                    .nombres("Usuario")
                    .apellidos("Regular")
                    .tipoDocumento(Usuario.TipoDocumento.DNI) // Tipo de documento DNI
                    .numeroDocumento("87654321")
                    .telefono("912345678")
                    .fechaNacimiento(LocalDate.of(1995, 5, 15))
                    .provincia("Piura")
                    .distrito("Piura")
                    .direccion("Calle Secundaria 456")
                    .activo(true)
                    .roles(Set.of(userRole))
                    .build();

            // Guardar usuarios en la base de datos
            usuarioRepository.save(admin);
            usuarioRepository.save(user);

            log.info("Usuarios inicializados correctamente");
        }
    }
}
