package com.piuraexpressa.config;

import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
// Habilita los repositorios JPA en el paquete com.piuraexpressa.repository
@EnableJpaRepositories(basePackages = "com.piuraexpressa.repository")
@EnableJpaAuditing
@EnableTransactionManagement
public class DatabaseConfig {
}
