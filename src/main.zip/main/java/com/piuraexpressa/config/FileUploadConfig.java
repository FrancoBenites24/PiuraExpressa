package com.piuraexpressa.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.springframework.lang.NonNull;

import java.nio.file.Path;
import java.nio.file.Paths;

@Configuration
// Implementa WebMvcConfigurer para personalizar la configuración MVC
public class FileUploadConfig implements WebMvcConfigurer {

    // Inyecta el valor de la propiedad app.upload.dir o usa "uploads" por defecto
    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    @Override
    public void addResourceHandlers(@NonNull ResourceHandlerRegistry registry) {
        // Configurar el manejo de archivos estáticos para uploads
        Path uploadPath = Paths.get(uploadDir);
        // Obtener la ruta absoluta del directorio de uploads
        String uploadPathPattern = uploadPath.toFile().getAbsolutePath();

        // Mapear las solicitudes /uploads/** a la ubicación física en el sistema de archivos
        registry.addResourceHandler("/uploads/**")
                .addResourceLocations("file:" + uploadPathPattern + "/");
    }
}
