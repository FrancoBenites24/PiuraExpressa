package com.piuraexpressa.config;

import com.piuraexpressa.dto.ProvinciaDTO;
import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.service.AuthService;
import com.piuraexpressa.service.ProvinciaService;

import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;

@ControllerAdvice
@RequiredArgsConstructor
public class GlobalControllerAdvice {

    private final ProvinciaService provinciaService;
    private final AuthService authService;

    // Añade al modelo una lista de provincias activas para la barra de navegación
    @ModelAttribute("provinciasNavbar")
    public List<ProvinciaDTO> addProvinciasToModel() {
        try {
            // Obtiene todas las provincias activas
            return provinciaService.obtenerTodasActivas();
        } catch (Exception e) {
            // En caso de error, retorna una lista vacía
            return List.of();
        }
    }

    // Añade al modelo el usuario autenticado actual o null si no hay sesión
    @ModelAttribute("usuario")
    public UsuarioDTO addUsuarioToModel() {
        // Retorna el usuario autenticado actual o null
        return authService.obtenerUsuarioActual();
    }
}
