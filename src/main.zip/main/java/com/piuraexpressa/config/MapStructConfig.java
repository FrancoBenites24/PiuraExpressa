package com.piuraexpressa.config;

import org.mapstruct.MapperConfig;
import org.mapstruct.ReportingPolicy;

// Configuración global para MapStruct, definiendo el modelo de componente y políticas de mapeo
@MapperConfig(componentModel = "spring", unmappedTargetPolicy = ReportingPolicy.IGNORE, unmappedSourcePolicy = ReportingPolicy.IGNORE)
public interface MapStructConfig {
}
