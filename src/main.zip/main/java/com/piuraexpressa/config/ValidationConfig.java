package com.piuraexpressa.config;

// Importaciones necesarias para configuración de validación
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

// Marca esta clase como configuración de Spring
@Configuration
public class ValidationConfig {
    // Define un bean para el validador local que integra JSR-303 con Spring
    @Bean
    public LocalValidatorFactoryBean validator() {
        return new LocalValidatorFactoryBean();
    }
}
