package com.piuraexpressa.controller;

import com.piuraexpressa.service.PermisoService;
import com.piuraexpressa.service.ProvinciaService;
import com.piuraexpressa.service.UsuarioService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin")
@RequiredArgsConstructor
@Slf4j
public class AdminController {

    private final ProvinciaService provinciaService;
    private final UsuarioService usuarioService;
    private final PermisoService permisoService;

    @PreAuthorize("hasPermission(null, 'ADMIN_DASHBOARD_ACCESS')")
    @GetMapping
    public String dashboard(Model model) {
        log.debug("Accediendo al dashboard de administración");
        
        try {
            // Estadísticas del dashboard
            long totalProvincias = provinciaService.contarActivas();
            long totalUsuarios = usuarioService.contarUsuarios();
            
            model.addAttribute("totalProvincias", totalProvincias);
            model.addAttribute("totalUsuarios", totalUsuarios);
            
            // Obtener provincias recientes para mostrar en el dashboard
            model.addAttribute("provinciasRecientes", provinciaService.obtenerTodasActivas());

            // Obtener cantidad de permisos para mostrar en el dashboard
            long totalPermisos = permisoService.findAll(org.springframework.data.domain.PageRequest.of(0, 1)).getTotalElements();
            model.addAttribute("totalPermisos", totalPermisos);
            
            return "admin/dashboard";
            
        } catch (Exception e) {
            log.error("Error al cargar dashboard: {}", e.getMessage(), e);
            model.addAttribute("error", "Error al cargar los datos del dashboard");
            model.addAttribute("exceptionMessage", e.getMessage());
            return "admin/dashboard";
        }
    }

    @PreAuthorize("hasPermission('/admin/noticias', 'ACCESS')")
    @GetMapping("/noticias")
    public String redirectToNoticias() {
        return "redirect:/admin/noticias";
    }
}
