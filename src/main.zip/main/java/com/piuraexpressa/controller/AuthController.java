package com.piuraexpressa.controller;

import com.piuraexpressa.dto.RegistroDTO;
import com.piuraexpressa.model.TipoDocumento;
import com.piuraexpressa.service.AuthService;
import jakarta.validation.Valid;
import lombok.extern.slf4j.Slf4j;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/auth")
@Slf4j
public class AuthController {

    private final AuthService authService;

    public AuthController(AuthService authService) {
        this.authService = authService;
    }

    @GetMapping("/login")
    public String mostrarLogin(@RequestParam(value = "error", required = false) String error,
            @RequestParam(value = "logout", required = false) String logout,
            Model model) {
                        log.info("🔍 ACCEDIENDO A /auth/login"); // ✅ Debug log

        if (error != null) {
            model.addAttribute("error", "Usuario o contraseña incorrectos");
        }
        if (logout != null) {
            model.addAttribute("message", "Has cerrado sesión correctamente");
        }
        return "auth/login";
    }

    @GetMapping("/registro")
    public String mostrarRegistro(Model model) {
                log.info("🔍 ACCEDIENDO A /auth/registro"); // ✅ Debug log

        model.addAttribute("registroDTO", new RegistroDTO());
        model.addAttribute("tiposDocumento", TipoDocumento.values());
        return "auth/registro";
    }

    @PostMapping("/registro")
    public String procesarRegistro(@Valid @ModelAttribute("registroDTO") RegistroDTO registroDTO,
            BindingResult result,
            Model model,
            RedirectAttributes redirectAttributes) {

        // Validaciones adicionales
        if (authService.existeUsername(registroDTO.getUsername())) {
            result.rejectValue("username", "error.usuario", "El nombre de usuario ya existe");
        }

        if (authService.existeEmail(registroDTO.getEmail())) {
            result.rejectValue("email", "error.usuario", "El email ya está registrado");
        }

        if (authService.existeDocumento(registroDTO.getNumeroDocumento())) {
            result.rejectValue("numeroDocumento", "error.usuario", "El número de documento ya está registrado");
        }

        if (result.hasErrors()) {
            model.addAttribute("tiposDocumento", TipoDocumento.values());
            model.addAttribute("registroDTO", registroDTO);
            return "auth/registro";
        }

        try {
            authService.registrar(registroDTO); // Cambiar a registrar
            redirectAttributes.addFlashAttribute("success",
                    "Usuario registrado exitosamente. Puedes iniciar sesión ahora.");
            return "redirect:/auth/login";
        } catch (Exception e) {
            model.addAttribute("error", "Error al registrar usuario: " + e.getMessage());
            model.addAttribute("tiposDocumento", TipoDocumento.values());
            model.addAttribute("registroDTO", registroDTO);
            return "auth/registro";
        }
    }

    // Endpoints AJAX para validaciones en tiempo real
    @GetMapping("/check-username")
    @ResponseBody
    public boolean checkUsername(@RequestParam String username) {
        return !authService.existeUsername(username);
    }

    @GetMapping("/check-email")
    @ResponseBody
    public boolean checkEmail(@RequestParam String email) {
        return !authService.existeEmail(email);
    }

    @GetMapping("/check-documento")
    @ResponseBody
    public boolean checkDocumento(@RequestParam String numeroDocumento) {
        return !authService.existeDocumento(numeroDocumento);
    }
}
