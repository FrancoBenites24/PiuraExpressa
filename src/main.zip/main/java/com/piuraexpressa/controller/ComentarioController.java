package com.piuraexpressa.controller;

import com.piuraexpressa.dto.ComentarioDTO;
import com.piuraexpressa.service.ComentarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.User;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/publicaciones/{publicacionId}/comentarios")
@RequiredArgsConstructor
public class ComentarioController {

    private final ComentarioService comentarioService;

    @GetMapping
    public ResponseEntity<List<ComentarioDTO>> obtenerComentarios(@PathVariable Long publicacionId) {
        List<ComentarioDTO> comentarios = comentarioService.obtenerComentariosPorPublicacion(publicacionId);
        return ResponseEntity.ok(comentarios);
    }

    @PostMapping
    public ResponseEntity<ComentarioDTO> crearComentario(@PathVariable Long publicacionId,
                                                         @RequestBody ComentarioDTO comentarioDTO,
                                                         @AuthenticationPrincipal User user) {
        String username = user.getUsername();
        ComentarioDTO nuevoComentario = comentarioService.crearComentario(publicacionId, comentarioDTO.getContenido(), username);
        return ResponseEntity.ok(nuevoComentario);
    }
}
