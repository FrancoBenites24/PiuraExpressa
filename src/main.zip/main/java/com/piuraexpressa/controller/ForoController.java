package com.piuraexpressa.controller;

import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import java.util.Optional;

@Controller
public class ForoController {

    @Autowired
    private UsuarioService usuarioService;

    @GetMapping("/foro")
    public String mostrarForo(Authentication authentication, Model model) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        String username = authentication.getName();
        Optional<UsuarioDTO> usuarioOpt = usuarioService.obtenerPorUsername(username);

        if (usuarioOpt.isEmpty()) {
            return "redirect:/login";
        }

        UsuarioDTO usuario = usuarioOpt.get();

        boolean esModerador = usuario.getRoles().stream()
                .anyMatch(rol -> rol.getNombre().equalsIgnoreCase("MODERADOR") || rol.getNombre().equalsIgnoreCase("ADMIN"));

        model.addAttribute("usuario", usuario);
        model.addAttribute("esModerador", esModerador);

        return "foro";
    }
}
