package com.piuraexpressa.controller;

import com.piuraexpressa.service.EventoService;
import com.piuraexpressa.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class MisEventosController {

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private EventoService eventoService;

    @GetMapping("/mis-eventos")
    public String misEventos(@AuthenticationPrincipal UserDetails userDetails, Model model) {
        if (userDetails != null) {
            var usuarioOpt = usuarioService.obtenerTodos().stream()
                .filter(u -> u.getUsername().equals(userDetails.getUsername()))
                .findFirst();
            if (usuarioOpt.isPresent()) {
                var usuario = usuarioOpt.get();
                // Assuming eventoService has a method to get events by user

            }
        }
        return "mis-eventos";
    }
}
