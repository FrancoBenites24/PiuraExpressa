package com.piuraexpressa.controller;

import com.piuraexpressa.dto.EventoDTO;
import com.piuraexpressa.dto.PublicacionDTO;
import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.service.AuthService;
import com.piuraexpressa.service.EventoService;
import com.piuraexpressa.service.PublicacionService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/perfil")
@RequiredArgsConstructor
@Slf4j
public class PerfilController {

    private final AuthService authService;
    private final PublicacionService publicacionService;
    private final EventoService eventoService;

    @GetMapping({ "", "/", "/index" })
    public String mostrarPerfil(Model model,
            RedirectAttributes redirectAttributes,
            @RequestParam(defaultValue = "0") int pubPage,
            @RequestParam(defaultValue = "5") int pubSize,
            @RequestParam(defaultValue = "0") int evtPage,
            @RequestParam(defaultValue = "5") int evtSize) {
        try {
            UsuarioDTO usuarioActual = authService.obtenerUsuarioActual();
            if (usuarioActual == null) {
                redirectAttributes.addFlashAttribute("error", "Debe iniciar sesión para acceder al perfil");
                return "redirect:/auth/login";
            }

            Pageable publicacionesPageable = PageRequest.of(pubPage, pubSize);
            Pageable eventosPageable = PageRequest.of(evtPage, evtSize);

            Page<PublicacionDTO> publicaciones = publicacionService.obtenerPorUsuarioPaginadas(usuarioActual.getId(),
                    publicacionesPageable);
            Page<EventoDTO> eventosAsistidos = eventoService.obtenerEventosPorUsuarioPaginadas(usuarioActual.getId(),
                    eventosPageable);

            // datos de paginación en el DTO
            usuarioActual.setPublicaciones(publicaciones.getContent());
            usuarioActual.setEventosAsistidos(eventosAsistidos.getContent());
            usuarioActual.setTotalPublicacionesPaginas(publicaciones.getTotalPages());
            usuarioActual.setTotalEventosPaginas(eventosAsistidos.getTotalPages());
            usuarioActual.setTienePublicacionesSiguientes(publicaciones.hasNext());
            usuarioActual.setTieneEventosSiguientes(eventosAsistidos.hasNext());

            model.addAttribute("usuario", usuarioActual);
            model.addAttribute("publicacionesPage", publicaciones);
            model.addAttribute("eventosPage", eventosAsistidos);

            return "perfil/index";

        } catch (Exception e) {
            log.error("Error al cargar perfil: {}", e.getMessage(), e);
            redirectAttributes.addFlashAttribute("error", "Error al cargar el perfil");
            return "redirect:/";
        }
    }

}
