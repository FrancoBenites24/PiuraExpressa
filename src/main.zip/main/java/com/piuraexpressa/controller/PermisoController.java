package com.piuraexpressa.controller;

import com.piuraexpressa.model.Permiso;
import com.piuraexpressa.service.PermisoService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/permisos")
@RequiredArgsConstructor
public class PermisoController {

    private final PermisoService permisoService;

    @GetMapping
    public String listPermisos(@RequestParam(defaultValue = "0") int page,
                              @RequestParam(defaultValue = "10") int size,
                              Model model) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Permiso> permisosPage = permisoService.findAll(pageable);
        model.addAttribute("permisosPage", permisosPage);
        return "admin/permisos/list";
    }

    @GetMapping("/nuevo")
    public String showCreateForm(Model model) {
        model.addAttribute("permiso", new Permiso());
        return "admin/permisos/form";
    }

    @PostMapping("/guardar")
    public String savePermiso(@ModelAttribute Permiso permiso) {
        permisoService.save(permiso);
        return "redirect:/admin/permisos";
    }

    @GetMapping("/editar/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        permisoService.findById(id).ifPresent(permiso -> model.addAttribute("permiso", permiso));
        return "admin/permisos/form";
    }

    @GetMapping("/eliminar/{id}")
    public String deletePermiso(@PathVariable Long id) {
        permisoService.deleteById(id);
        return "redirect:/admin/permisos";
    }
}
