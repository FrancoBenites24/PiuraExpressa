package com.piuraexpressa.controller;

import com.piuraexpressa.service.PlatoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PlatoController {

    @Autowired
    private PlatoService platoService;

    @GetMapping("/platos")
    public String platos(Model model) {
        model.addAttribute("platos", platoService.obtenerTodosPaginados(org.springframework.data.domain.Pageable.unpaged()).getContent());
        return "platos";
    }
}
