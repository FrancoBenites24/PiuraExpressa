package com.piuraexpressa.controller;

import com.piuraexpressa.dto.ProvinciaDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.service.ProvinciaService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/provincias")
@RequiredArgsConstructor
@Slf4j
public class ProvinciaController {

    private final ProvinciaService provinciaService;

    /**
     * Mostrar la lista completa de provincias activas.
     * URL: /provincias
     */
    @GetMapping
    public String listarProvincias(Model model) {
        log.debug("Accediendo a listado de provincias");

        List<ProvinciaDTO> provincias = provinciaService.obtenerTodasActivas();
        model.addAttribute("provincias", provincias);

        return "provincias"; // nombre de la vista para la lista
    }

    /**
     * Mostrar detalle de una provincia determinada por su nombre.
     * URL ejemplo: /provincias/piura
     */
    @GetMapping("/{nombre}")
    public String detalleProvincia(@PathVariable("nombre") String nombre, Model model) {
        log.debug("Solicitando detalle de la provincia: {}", nombre);

        ProvinciaDTO provincia = provinciaService.obtenerPorNombre(nombre)
                .orElseThrow(() -> {
                    log.warn("Provincia no encontrada o inactiva: {}", nombre);
                    return new ResourceNotFoundException("Provincia no encontrada: " + nombre);
                });

        // Cargar datos completos para evitar errores en la vista
        provincia = provinciaService.obtenerCompleta(provincia.getId())
                .orElse(provincia);

        model.addAttribute("provincia", provincia);

        return "detalle-provincia"; // nombre de la vista para detalles
    }

    // Metodo para manejar error 404
    @ExceptionHandler(ResourceNotFoundException.class)
    public String handleResourceNotFound(ResourceNotFoundException ex, Model model) {
        model.addAttribute("mensajeError", ex.getMessage());
        return "error/404";
    }
}
