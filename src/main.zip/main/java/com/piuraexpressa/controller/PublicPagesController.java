package com.piuraexpressa.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class PublicPagesController {

    @GetMapping("/sobre-nosotros")
    public String sobreNosotros() {
        return "sobre-nosotros";
    }

    @GetMapping("/contacto")
    public String contacto() {
        return "contacto";
    }

    @GetMapping("/terminos-y-condiciones")
    public String terminosYCondiciones() {
        return "terminos-y-condiciones";
    }

    @GetMapping("/politica-de-privacidad")
    public String politicaDePrivacidad() {
        return "politica-de-privacidad";
    }
}
