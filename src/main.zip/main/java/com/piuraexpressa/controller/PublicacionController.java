package com.piuraexpressa.controller;

import com.piuraexpressa.dto.PublicacionDTO;
import com.piuraexpressa.dto.PublicacionCreateDTO;
import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.service.PublicacionService;
import com.piuraexpressa.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import jakarta.validation.Valid;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Optional;
import org.springframework.data.domain.Pageable;

@RestController
@RequestMapping("/api/publicaciones")
public class PublicacionController {

    @Autowired
    private PublicacionService publicacionService;

    @Autowired
    private UsuarioService usuarioService;

    @Autowired
    private com.piuraexpressa.service.ImagenService imagenService;

    @GetMapping
    public ResponseEntity<?> listarPublicaciones(Pageable pageable, Authentication authentication) {
        Long usuarioId = null;
        if (authentication != null && authentication.isAuthenticated()) {
            usuarioId = usuarioService.obtenerPorUsername(authentication.getName())
                    .map(u -> u.getId())
                    .orElse(null);
        }
        return ResponseEntity.ok(publicacionService.obtenerTodasPaginadas(pageable, usuarioId));
    }

    @PostMapping(consumes = {"application/json"})
    public ResponseEntity<?> crearPublicacion(@Valid @RequestBody PublicacionCreateDTO publicacionCreateDTO, BindingResult result, Authentication authentication) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getAllErrors());
        }
        String username = authentication.getName();
        Optional<UsuarioDTO> usuarioOpt = usuarioService.obtenerPorUsername(username);
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(401).body("Usuario no encontrado");
        }
        PublicacionDTO publicacionDTO = PublicacionDTO.builder()
                .titulo(publicacionCreateDTO.getTitulo())
                .contenido(publicacionCreateDTO.getContenido())
                .imagen(publicacionCreateDTO.getImagen())
                .usuarioId(usuarioOpt.get().getId())
                .build();
        PublicacionDTO creada = publicacionService.guardar(publicacionDTO);
        return ResponseEntity.ok(creada);
    }

    @PostMapping(consumes = {"multipart/form-data"})
    public ResponseEntity<?> crearPublicacionConImagen(@RequestPart("publicacion") String publicacionJson,
                                                      @RequestPart(value = "file", required = false) MultipartFile file,
                                                      Authentication authentication) {
        try {
            // Parsear JSON a PublicacionCreateDTO
            com.fasterxml.jackson.databind.ObjectMapper objectMapper = new com.fasterxml.jackson.databind.ObjectMapper();
            PublicacionCreateDTO publicacionCreateDTO = objectMapper.readValue(publicacionJson, PublicacionCreateDTO.class);

            String username = authentication.getName();
            Optional<UsuarioDTO> usuarioOpt = usuarioService.obtenerPorUsername(username);
            if (usuarioOpt.isEmpty()) {
                return ResponseEntity.status(401).body("Usuario no encontrado");
            }

            PublicacionDTO publicacionDTO = PublicacionDTO.builder()
                    .titulo(publicacionCreateDTO.getTitulo())
                    .contenido(publicacionCreateDTO.getContenido())
                    .usuarioId(usuarioOpt.get().getId())
                    .build();

            // Guardar publicación sin imagen
            PublicacionDTO creada = publicacionService.guardar(publicacionDTO);

            // Si hay archivo, guardar imagen y actualizar publicación
            if (file != null && !file.isEmpty()) {
                // Usar ImagenService para subir imagen y obtener ruta
                // Convertir UsuarioDTO a Usuario usando MapperUtil
                com.piuraexpressa.model.Usuario usuarioEntidad = com.piuraexpressa.util.MapperUtil.mapToUsuario(usuarioOpt.get());
                String rutaImagenSubida = imagenService.subirImagenPublicacion(file, creada.getId(), usuarioEntidad);
                publicacionService.actualizarImagen(creada.getId(), rutaImagenSubida);

                // Recargar publicación actualizada para devolver con imagen
creada = publicacionService.obtenerPorId(creada.getId(), usuarioOpt.get().getId()).orElse(creada);
            }

            return ResponseEntity.ok(creada);
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(400).body("Error al crear la publicación con imagen");
        }
    }

    @PutMapping("/{id}")
    public ResponseEntity<?> actualizarPublicacion(@PathVariable Long id, @Valid @RequestBody PublicacionDTO publicacionDTO, BindingResult result, Authentication authentication) {
        if (result.hasErrors()) {
            return ResponseEntity.badRequest().body(result.getAllErrors());
        }
        PublicacionDTO actualizada = publicacionService.actualizar(id, publicacionDTO);
        if (actualizada == null) {
            return ResponseEntity.status(403).body("No tiene permiso para actualizar esta publicación");
        }
        return ResponseEntity.ok(actualizada);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminarPublicacion(@PathVariable Long id, Authentication authentication) {
        // Se asume que el servicio controla permisos internamente
        publicacionService.eliminar(id);
        return ResponseEntity.ok().build();
    }

    @PostMapping("/{id}/like")
    public ResponseEntity<?> darLike(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        Optional<UsuarioDTO> usuarioOpt = usuarioService.obtenerPorUsername(username);
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(401).body("Usuario no encontrado");
        }
        publicacionService.darLike(id, usuarioOpt.get().getId());
        long totalLikes = publicacionService.contarLikes(id);
        return ResponseEntity.ok(new LikeResponse(totalLikes));
    }

    @PostMapping("/{id}/unlike")
    public ResponseEntity<?> quitarLike(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        Optional<UsuarioDTO> usuarioOpt = usuarioService.obtenerPorUsername(username);
        if (usuarioOpt.isEmpty()) {
            return ResponseEntity.status(401).body("Usuario no encontrado");
        }
        publicacionService.quitarLike(id, usuarioOpt.get().getId());
        long totalLikes = publicacionService.contarLikes(id);
        return ResponseEntity.ok(new LikeResponse(totalLikes));
    }

    // Clase interna para respuesta de likes
    public static class LikeResponse {
        private long totalLikes;

        public LikeResponse(long totalLikes) {
            this.totalLikes = totalLikes;
        }

        public long getTotalLikes() {
            return totalLikes;
        }

        public void setTotalLikes(long totalLikes) {
            this.totalLikes = totalLikes;
        }
    }

    @PostMapping("/{id}/reportar")
    public ResponseEntity<?> reportarPublicacion(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        boolean exito = publicacionService.reportarPublicacion(id, username);
        if (exito) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.status(400).body("No se pudo reportar la publicación");
        }
    }

    @PostMapping("/{id}/guardar")
    public ResponseEntity<?> guardarPublicacion(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        boolean exito = publicacionService.guardarPublicacion(id, username);
        if (exito) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.status(400).body("No se pudo guardar la publicación");
        }
    }

    @PostMapping("/{id}/compartir")
    public ResponseEntity<?> compartirPublicacion(@PathVariable Long id, Authentication authentication) {
        String username = authentication.getName();
        boolean exito = publicacionService.compartirPublicacion(id, username);
        if (exito) {
            return ResponseEntity.ok().build();
        } else {
            return ResponseEntity.status(400).body("No se pudo compartir la publicación");
        }
    }

    @PostMapping("/{id}/uploadImage")
    public ResponseEntity<?> uploadImage(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Archivo vacío");
        }
        try {
            String uploadDir = "uploads/";
            File uploadFolder = new File(uploadDir);
            if (!uploadFolder.exists()) {
                uploadFolder.mkdirs();
            }
            String filename = System.currentTimeMillis() + "_" + file.getOriginalFilename();
            Path filepath = Paths.get(uploadDir, filename);
            Files.write(filepath, file.getBytes());

            // Construir ruta relativa para la imagen accesible desde frontend
            String rutaImagen = "/uploads/" + filename;

            // Actualizar la publicación con la ruta de la imagen
            publicacionService.actualizarImagen(id, rutaImagen);

            return ResponseEntity.ok("Imagen subida correctamente: " + rutaImagen);
        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error al subir la imagen");
        }
    }
}
