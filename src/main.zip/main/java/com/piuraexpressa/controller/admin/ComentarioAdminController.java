package com.piuraexpressa.controller.admin;

import com.piuraexpressa.service.ComentarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/admin/comentarios")
@RequiredArgsConstructor
public class ComentarioAdminController {

    private final ComentarioService comentarioService;

    @PreAuthorize("hasPermission('/admin/comentarios', 'ACCESS')")
    @GetMapping
    public String listarComentarios(Model model) {
        model.addAttribute("comentarios", comentarioService.obtenerTodosPaginados(PageRequest.of(0, 100)));
        return "admin/comentarios/list";
    }
}
