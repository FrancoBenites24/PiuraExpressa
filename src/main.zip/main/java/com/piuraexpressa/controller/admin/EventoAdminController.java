package com.piuraexpressa.controller.admin;

import com.piuraexpressa.dto.EventoDTO;
import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.model.Evento;
import com.piuraexpressa.service.AuthService;
import com.piuraexpressa.service.EventoService;
import com.piuraexpressa.service.ProvinciaService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import lombok.extern.slf4j.Slf4j;

import org.springframework.security.access.prepost.PreAuthorize;

@Slf4j
@Controller
@RequestMapping("/admin/eventos")
public class EventoAdminController {

    private final EventoService eventoService;
    private final ProvinciaService provinciaService;
    private AuthService authService;

    public EventoAdminController(EventoService eventoService, 
                               ProvinciaService provinciaService,
                               AuthService authService) {
        this.eventoService = eventoService;
        this.provinciaService = provinciaService;
        this.authService = authService;
    }

    @PreAuthorize("hasPermission('/admin/eventos', 'ACCESS')")
    @GetMapping
    public String listarEventos(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            Model model) {
        Pageable pageable = PageRequest.of(page, size);
        // ✅ Corregido: usar Page<EventoDTO>
        Page<EventoDTO> eventos = eventoService.obtenerTodosPaginados(pageable);

        model.addAttribute("eventos", eventos);
        return "admin/eventos/list";
    }

    @PreAuthorize("hasPermission('/admin/eventos/nuevo', 'ACCESS')")
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("evento", new Evento());
        model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
        return "admin/eventos/form";
    }

    @PreAuthorize("hasPermission('/admin/eventos/guardar', 'ACCESS')")
    @PostMapping("/guardar")
    public String guardarEvento(@Valid @ModelAttribute("evento") EventoDTO evento,
            BindingResult result,
            RedirectAttributes redirectAttributes,
            Model model) {
        if (result.hasErrors()) {
            model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
            return "admin/eventos/form";
        }

        try {
            UsuarioDTO usuarioActual = authService.obtenerUsuarioActual();
            if (usuarioActual == null) {
                redirectAttributes.addFlashAttribute("error", "Debe iniciar sesión para crear eventos");
                return "redirect:/auth/login";
            }

            // Asignar el usuario actual al evento
            evento.setUsuarioId(usuarioActual.getId());

            EventoDTO eventoGuardado = eventoService.guardar(evento);
            log.info("Evento guardado con ID: {} por usuario: {}",
                    eventoGuardado.getId(), usuarioActual.getUsername());

            redirectAttributes.addFlashAttribute("success", "Evento creado exitosamente");
            return "redirect:/admin/eventos";

        } catch (Exception e) {
            log.error("Error al guardar evento: {}", e.getMessage(), e);
            redirectAttributes.addFlashAttribute("error", "Error al guardar el evento: " + e.getMessage());
            model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
            return "admin/eventos/form";
        }
    }

    @PreAuthorize("hasPermission('/admin/eventos/editar', 'ACCESS')")
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        EventoDTO evento = eventoService.obtenerPorId(id).orElse(null);
        if (evento == null) {
            redirectAttributes.addFlashAttribute("error", "Evento no encontrado");
            return "redirect:/admin/eventos";
        }
        model.addAttribute("evento", evento);
        model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
        return "admin/eventos/form";
    }

    @PreAuthorize("hasPermission('/admin/eventos/eliminar', 'ACCESS')")
    @PostMapping("/eliminar/{id}")
    public String eliminarEvento(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        eventoService.eliminar(id);
        redirectAttributes.addFlashAttribute("success", "Evento eliminado correctamente");
        return "redirect:/admin/eventos";
    }
}
