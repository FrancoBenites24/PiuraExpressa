package com.piuraexpressa.controller.admin;

import com.piuraexpressa.model.Plato;
import com.piuraexpressa.service.PlatoService;
import com.piuraexpressa.service.ProvinciaService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import org.springframework.security.access.prepost.PreAuthorize;

@Controller
@RequestMapping("/admin/platos")
public class PlatoAdminController {

    private final PlatoService platoService;
    private final ProvinciaService provinciaService;

    public PlatoAdminController(PlatoService platoService, ProvinciaService provinciaService) {
        this.platoService = platoService;
        this.provinciaService = provinciaService;
    }

    @PreAuthorize("hasPermission('/admin/platos', 'ACCESS')")
    @GetMapping
    public String listarPlatos(@RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "10") int size,
                               Model model) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Plato> platos = platoService.obtenerTodosPaginados(pageable);
        model.addAttribute("platos", platos);
        return "admin/platos/list";
    }

    @PreAuthorize("hasPermission('/admin/platos/nuevo', 'ACCESS')")
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("plato", new Plato());
        model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
        return "admin/platos/form";
    }

    @PreAuthorize("hasPermission('/admin/platos/guardar', 'ACCESS')")
    @PostMapping("/guardar")
    public String guardarPlato(@Valid @ModelAttribute("plato") Plato plato,
                               BindingResult result,
                               RedirectAttributes redirectAttributes,
                               Model model) {
        if (result.hasErrors()) {
            model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
            return "admin/platos/form";
        }

        platoService.guardar(plato);
        redirectAttributes.addFlashAttribute("success", "Plato guardado correctamente");
        return "redirect:/admin/platos";
    }

    @PreAuthorize("hasPermission('/admin/platos/editar', 'ACCESS')")
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Plato plato = platoService.obtenerPorId(id).orElse(null);
        if (plato == null) {
            redirectAttributes.addFlashAttribute("error", "Plato no encontrado");
            return "redirect:/admin/platos";
        }
        model.addAttribute("plato", plato);
        model.addAttribute("provincias", provinciaService.obtenerTodasActivas());
        return "admin/platos/form";
    }

    @PreAuthorize("hasPermission('/admin/platos/eliminar', 'ACCESS')")
    @PostMapping("/eliminar/{id}")
    public String eliminarPlato(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        platoService.eliminar(id);
        redirectAttributes.addFlashAttribute("success", "Plato eliminado correctamente");
        return "redirect:/admin/platos";
    }
}
