package com.piuraexpressa.controller.admin;

import com.piuraexpressa.dto.EstadisticaProvinciaDTO;
import com.piuraexpressa.dto.HistoriaProvinciaDTO;
import com.piuraexpressa.dto.PuntoInteresDTO;
import com.piuraexpressa.dto.ProvinciaDTO;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.UsuarioRepository;
import com.piuraexpressa.service.ImagenService;
import com.piuraexpressa.service.ProvinciaService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import org.springframework.security.access.prepost.PreAuthorize;

@Controller
@RequestMapping("/admin/provincias")
@RequiredArgsConstructor
@Slf4j
public class ProvinciaAdminController {

    private final ProvinciaService provinciaService;
    private final ImagenService imagenService;
    private final UsuarioRepository usuarioRepository;

    @PreAuthorize("hasPermission('/admin/provincias', 'ACCESS')")
    @GetMapping
    public String listarProvincias(@RequestParam(defaultValue = "0") int page,
                                  @RequestParam(defaultValue = "10") int size,
                                  @RequestParam(required = false) String search,
                                  @RequestParam(required = false) String estado,
                                  Model model) {
        log.debug("Listando provincias - página: {}, tamaño: {}, búsqueda: {}, estado: {}",
                page, size, search, estado);

        Pageable pageable = PageRequest.of(page, size);
        Page<ProvinciaDTO> provincias;

        if (StringUtils.hasText(search) || StringUtils.hasText(estado)) {
            provincias = provinciaService.buscarPaginadas(search, estado, pageable);
        } else {
            provincias = provinciaService.obtenerTodasPaginadas(pageable);
        }

        model.addAttribute("provincias", provincias);
        model.addAttribute("search", search);
        model.addAttribute("estado", estado);

        return "admin/provincias/list";
    }

    @PreAuthorize("hasPermission('/admin/provincias/nueva', 'ACCESS')")
    @GetMapping("/nueva")
    public String mostrarFormularioNueva(Model model) {
        log.debug("Mostrando formulario para nueva provincia");
        ProvinciaDTO provincia = new ProvinciaDTO();
        provincia.setActiva(true);
        model.addAttribute("provincia", provincia);
        return "admin/provincias/formulario";
    }

    @PreAuthorize("hasPermission('/admin/provincias/editar', 'ACCESS')")
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        log.debug("Mostrando formulario para editar provincia ID: {}", id);

        return provinciaService.obtenerPorId(id)
                .map(provincia -> {
                    String urlImagen = imagenService.obtenerUrlImagenProvincia(id);
                    if (urlImagen != null) {
                        provincia.setImagenPrincipal(urlImagen);
                    }
                    model.addAttribute("provincia", provincia);
                    return "admin/provincias/editar";
                })
                .orElseGet(() -> {
                    redirectAttributes.addFlashAttribute("error", "Provincia no encontrada");
                    return "redirect:/admin/provincias";
                });
    }

    @PreAuthorize("hasPermission('/admin/provincias/guardar', 'ACCESS')")
    @PostMapping("/guardar")
    public String guardarProvincia(@Valid @ModelAttribute("provincia") ProvinciaDTO provincia,
                                  BindingResult result,
                                  @RequestParam(value = "imagenFile", required = false) MultipartFile imagenFile,
                                  RedirectAttributes redirectAttributes,
                                  Model model) {
        log.debug("Guardando provincia: {}", provincia.getNombre());

        if (result.hasErrors()) {
            log.warn("Errores de validación al guardar provincia: {}", result.getAllErrors());
            return provincia.getId() == null ? "admin/provincias/formulario" : "admin/provincias/editar";
        }

        if (provincia.getId() == null) {
            if (provinciaService.existePorNombre(provincia.getNombre())) {
                result.rejectValue("nombre", "error.provincia.nombre.exists",
                        "Ya existe una provincia con este nombre");
                return "admin/provincias/formulario";
            }
        } else {
            if (provinciaService.existePorNombre(provincia.getNombre(), provincia.getId())) {
                result.rejectValue("nombre", "error.provincia.nombre.exists",
                        "Ya existe otra provincia con este nombre");
                return "admin/provincias/editar";
            }
        }

        try {
            ProvinciaDTO provinciaGuardada;
            boolean esNueva = provincia.getId() == null;

            if (provincia.getHistoria() == null) {
                provincia.setHistoria(new java.util.ArrayList<>());
            }
            if (provincia.getPuntosInteres() == null) {
                provincia.setPuntosInteres(new java.util.ArrayList<>());
            }

            if (esNueva) {
                provinciaGuardada = provinciaService.guardar(provincia);
                redirectAttributes.addFlashAttribute("success", "Provincia creada exitosamente");
            } else {
                provinciaGuardada = provinciaService.actualizar(provincia.getId(), provincia);
                redirectAttributes.addFlashAttribute("success", "Provincia actualizada exitosamente");
            }

            if (imagenFile != null && !imagenFile.isEmpty()) {
                try {
                    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
                    String username = auth.getName();
                    Usuario usuario = usuarioRepository.findByUsernameAndActivoTrue(username)
                            .orElseThrow(() -> new IllegalStateException("Usuario no encontrado: " + username));

                    String urlImagen = imagenService.subirImagenProvincia(imagenFile, provinciaGuardada.getId(), usuario);

                    provinciaGuardada.setImagenPrincipal(urlImagen);
                    provinciaService.actualizar(provinciaGuardada.getId(), provinciaGuardada);

                    log.info("Imagen subida exitosamente para provincia: {}", provinciaGuardada.getNombre());
                } catch (Exception e) {
                    log.error("Error al subir imagen: {}", e.getMessage(), e);
                    redirectAttributes.addFlashAttribute("warning",
                            "Provincia guardada pero hubo un error al subir la imagen: " + e.getMessage());
                }
            }

            log.info("Provincia guardada exitosamente: {}", provinciaGuardada.getNombre());
            return "redirect:/admin/provincias";

        } catch (Exception e) {
            log.error("Error al guardar provincia: {}", e.getMessage(), e);
            model.addAttribute("error", "Error al guardar la provincia: " + e.getMessage());
            return provincia.getId() == null ? "admin/provincias/formulario" : "admin/provincias/editar";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/eliminar', 'ACCESS')")
    @PostMapping("/eliminar/{id}")
    public String eliminarProvincia(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        log.debug("Eliminando provincia ID: {}", id);

        try {
            imagenService.eliminarImagenProvincia(id);

            provinciaService.eliminar(id);
            redirectAttributes.addFlashAttribute("success", "Provincia eliminada exitosamente");
            log.info("Provincia eliminada exitosamente con ID: {}", id);
        } catch (Exception e) {
            log.error("Error al eliminar provincia ID {}: {}", id, e.getMessage(), e);
            redirectAttributes.addFlashAttribute("error", "Error al eliminar la provincia: " + e.getMessage());
        }

        return "redirect:/admin/provincias";
    }

    @PreAuthorize("hasPermission('/admin/provincias/activar', 'ACCESS')")
    @PostMapping("/activar/{id}")
    public String activarProvincia(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        log.debug("Activando provincia ID: {}", id);

        try {
            provinciaService.activar(id);
            redirectAttributes.addFlashAttribute("success", "Provincia activada exitosamente");
            log.info("Provincia activada exitosamente con ID: {}", id);
        } catch (Exception e) {
            log.error("Error al activar provincia ID {}: {}", id, e.getMessage(), e);
            redirectAttributes.addFlashAttribute("error", "Error al activar la provincia: " + e.getMessage());
        }

        return "redirect:/admin/provincias";
    }

    @PreAuthorize("hasPermission('/admin/provincias/desactivar', 'ACCESS')")
    @PostMapping("/desactivar/{id}")
    public String desactivarProvincia(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        log.debug("Desactivando provincia ID: {}", id);

        try {
            provinciaService.desactivar(id);
            redirectAttributes.addFlashAttribute("success", "Provincia desactivada exitosamente");
            log.info("Provincia desactivada exitosamente con ID: {}", id);
        } catch (Exception e) {
            log.error("Error al desactivar provincia ID {}: {}", id, e.getMessage(), e);
            redirectAttributes.addFlashAttribute("error", "Error al desactivar la provincia: " + e.getMessage());
        }

        return "redirect:/admin/provincias";
    }

    // Puntos de Interes management

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes', 'ACCESS')")
    @GetMapping("/{provinciaId}/puntos-interes")
    public String listarPuntosInteres(@PathVariable Long provinciaId,
                                      @RequestParam(defaultValue = "0") int page,
                                      @RequestParam(defaultValue = "10") int size,
                                      Model model) {
        Pageable pageable = PageRequest.of(page, size);
        var puntosInteresPage = provinciaService.obtenerPuntosInteresPorProvinciaPaginados(provinciaId, pageable);
        model.addAttribute("puntosInteresPage", puntosInteresPage);
        model.addAttribute("puntosInteres", puntosInteresPage.getContent());
        model.addAttribute("provinciaId", provinciaId);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", puntosInteresPage.getTotalPages());
        return "admin/provincias/puntos-interes/list";
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/nuevo', 'ACCESS')")
    @GetMapping("/{provinciaId}/puntos-interes/nuevo")
    public String mostrarFormularioNuevoPuntoInteres(@PathVariable Long provinciaId, Model model) {
        model.addAttribute("puntoInteres", new PuntoInteresDTO());
        model.addAttribute("provinciaId", provinciaId);
        return "admin/provincias/puntos-interes/formulario";
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/guardar', 'ACCESS')")
    @PostMapping("/{provinciaId}/puntos-interes/guardar")
    public String guardarPuntoInteres(@PathVariable Long provinciaId,
                                      @ModelAttribute("puntoInteres") PuntoInteresDTO puntoInteresDTO,
                                      @RequestParam(value = "imagenFile", required = false) org.springframework.web.multipart.MultipartFile imagenFile,
                                      Model model,
                                      RedirectAttributes redirectAttributes) {
        try {
            PuntoInteresDTO puntoGuardado = provinciaService.crearPuntoInteres(provinciaId, puntoInteresDTO);

            if (imagenFile != null && !imagenFile.isEmpty()) {
                try {
                    String urlImagen = imagenService.subirImagenPuntoInteres(imagenFile, puntoGuardado.getId());
                    puntoInteresDTO.setImagenUrl(urlImagen);
                    provinciaService.actualizarPuntoInteres(puntoGuardado.getId(), puntoInteresDTO);
                } catch (Exception e) {
                    model.addAttribute("warning", "Punto creado pero error al subir imagen: " + e.getMessage());
                }
            }

            redirectAttributes.addFlashAttribute("success", "Punto de interés creado exitosamente");
            return "redirect:/admin/provincias/" + provinciaId + "/puntos-interes";
        } catch (Exception e) {
            model.addAttribute("error", "Error al crear punto de interés: " + e.getMessage());
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/puntos-interes/formulario";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/editar', 'ACCESS')")
    @GetMapping("/{provinciaId}/puntos-interes/editar/{id}")
    public String mostrarFormularioEditarPuntoInteres(@PathVariable Long provinciaId,
                                                      @PathVariable Long id,
                                                      Model model,
                                                      RedirectAttributes redirectAttributes) {
        try {
            PuntoInteresDTO puntoInteresDTO = provinciaService.obtenerPuntoInteresPorId(id);
            model.addAttribute("puntoInteres", puntoInteresDTO);
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/puntos-interes/editar";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Punto de interés no encontrado");
            return "redirect:/admin/provincias/" + provinciaId + "/puntos-interes";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/actualizar', 'ACCESS')")
    @PostMapping("/{provinciaId}/puntos-interes/actualizar/{id}")
    public String actualizarPuntoInteres(@PathVariable Long provinciaId,
                                         @PathVariable Long id,
                                         @ModelAttribute("puntoInteres") PuntoInteresDTO puntoInteresDTO,
                                         @RequestParam(value = "imagenFile", required = false) org.springframework.web.multipart.MultipartFile imagenFile,
                                         Model model,
                                         RedirectAttributes redirectAttributes) {
        try {
            PuntoInteresDTO puntoActualizado = provinciaService.actualizarPuntoInteres(id, puntoInteresDTO);

            if (imagenFile != null && !imagenFile.isEmpty()) {
                try {
                    String urlImagen = imagenService.subirImagenPuntoInteres(imagenFile, puntoActualizado.getId());
                    puntoActualizado.setImagenUrl(urlImagen);
                    provinciaService.actualizarPuntoInteres(puntoActualizado.getId(), puntoActualizado);
                } catch (Exception e) {
                    model.addAttribute("warning", "Punto actualizado pero error al subir imagen: " + e.getMessage());
                }
            }

            redirectAttributes.addFlashAttribute("success", "Punto de interés actualizado exitosamente");
            return "redirect:/admin/provincias/" + provinciaId + "/puntos-interes";
        } catch (Exception e) {
            model.addAttribute("error", "Error al actualizar punto de interés: " + e.getMessage());
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/puntos-interes/editar";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/eliminar', 'ACCESS')")
    @PostMapping("/{provinciaId}/puntos-interes/eliminar/{id}")
    public String eliminarPuntoInteres(@PathVariable Long provinciaId,
                                      @PathVariable Long id,
                                      RedirectAttributes redirectAttributes) {
        try {
            provinciaService.eliminarPuntoInteres(id);
            redirectAttributes.addFlashAttribute("success", "Punto de interés eliminado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar punto de interés: " + e.getMessage());
        }
        return "redirect:/admin/provincias/" + provinciaId + "/puntos-interes";
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/activar', 'ACCESS')")
    @PostMapping("/{provinciaId}/puntos-interes/activar/{id}")
    public String activarPuntoInteres(@PathVariable Long provinciaId,
                                     @PathVariable Long id,
                                     RedirectAttributes redirectAttributes) {
        try {
            provinciaService.activarPuntoInteres(id);
            redirectAttributes.addFlashAttribute("success", "Punto de interés activado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al activar punto de interés: " + e.getMessage());
        }
        return "redirect:/admin/provincias/" + provinciaId + "/puntos-interes";
    }

    @PreAuthorize("hasPermission('/admin/provincias/puntos-interes/desactivar', 'ACCESS')")
    @PostMapping("/{provinciaId}/puntos-interes/desactivar/{id}")
    public String desactivarPuntoInteres(@PathVariable Long provinciaId,
                                        @PathVariable Long id,
                                        RedirectAttributes redirectAttributes) {
        try {
            provinciaService.desactivarPuntoInteres(id);
            redirectAttributes.addFlashAttribute("success", "Punto de interés desactivado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al desactivar punto de interés: " + e.getMessage());
        }
        return "redirect:/admin/provincias/" + provinciaId + "/puntos-interes";
    }

    // Estadisticas management
    @PreAuthorize("hasPermission('/admin/provincias/estadisticas', 'ACCESS')")
    @GetMapping("/{provinciaId}/estadisticas")
    public String listarEstadisticas(@PathVariable Long provinciaId,
                                    @RequestParam(defaultValue = "0") int page,
                                    @RequestParam(defaultValue = "10") int size,
                                    Model model) {
        provinciaService.obtenerPorId(provinciaId).ifPresent(provincia -> model.addAttribute("provincia", provincia));
        Pageable pageable = PageRequest.of(page, size);
        var estadisticasPage = provinciaService.obtenerEstadisticasPaginadas(provinciaId, pageable);
        model.addAttribute("estadisticasPage", estadisticasPage);
        model.addAttribute("estadisticas", estadisticasPage.getContent());
        model.addAttribute("provinciaId", provinciaId);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", estadisticasPage.getTotalPages());
        return "admin/provincias/estadisticas/list";
    }

    @PreAuthorize("hasPermission('/admin/provincias/estadisticas/nuevo', 'ACCESS')")
    @GetMapping("/{provinciaId}/estadisticas/nuevo")
    public String mostrarFormularioNuevaEstadistica(@PathVariable Long provinciaId, Model model) {
        model.addAttribute("estadistica", new EstadisticaProvinciaDTO());
        model.addAttribute("provinciaId", provinciaId);
        return "admin/provincias/estadisticas/formulario";
    }

    @PreAuthorize("hasPermission('/admin/provincias/estadisticas/nuevo', 'ACCESS')")
    @PostMapping("/{provinciaId}/estadisticas/guardar")
    public String guardarEstadistica(@PathVariable Long provinciaId,
                                    @ModelAttribute("estadistica") EstadisticaProvinciaDTO estadisticaDTO,
                                    Model model,
                                    RedirectAttributes redirectAttributes) {
        try {
            EstadisticaProvinciaDTO estadisticaGuardada = provinciaService.crearEstadistica(provinciaId, estadisticaDTO);
            redirectAttributes.addFlashAttribute("success", "Estadística creada exitosamente");
            return "redirect:/admin/provincias/" + provinciaId + "/estadisticas";
        } catch (Exception e) {
            model.addAttribute("error", "Error al crear estadística: " + e.getMessage());
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/estadisticas/formulario";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/estadisticas/editar', 'ACCESS')")
    @GetMapping("/{provinciaId}/estadisticas/editar/{id}")
    public String mostrarFormularioEditarEstadistica(@PathVariable Long provinciaId,
                                                     @PathVariable Long id,
                                                     Model model,
                                                     RedirectAttributes redirectAttributes) {
        try {
            EstadisticaProvinciaDTO estadisticaDTO = provinciaService.obtenerEstadisticasPaginadas(provinciaId, null)
                    .stream()
                    .filter(e -> e.getId().equals(id))
                    .findFirst()
                    .orElseThrow(() -> new IllegalArgumentException("Estadística no encontrada"));
            model.addAttribute("estadistica", estadisticaDTO);
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/estadisticas/editar";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Estadística no encontrada");
            return "redirect:/admin/provincias/" + provinciaId + "/estadisticas";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/estadisticas/actualizar', 'ACCESS')")
    @PostMapping("/{provinciaId}/estadisticas/actualizar/{id}")
    public String actualizarEstadistica(@PathVariable Long provinciaId,
                                        @PathVariable Long id,
                                        @ModelAttribute("estadistica") EstadisticaProvinciaDTO estadisticaDTO,
                                        Model model,
                                        RedirectAttributes redirectAttributes) {
        try {
            provinciaService.actualizarEstadistica(id, estadisticaDTO);
            redirectAttributes.addFlashAttribute("success", "Estadística actualizada exitosamente");
            return "redirect:/admin/provincias/" + provinciaId + "/estadisticas";
        } catch (Exception e) {
            model.addAttribute("error", "Error al actualizar estadística: " + e.getMessage());
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/estadisticas/editar";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/estadisticas/eliminar', 'ACCESS')")
    @PostMapping("/{provinciaId}/estadisticas/eliminar/{id}")
    public String eliminarEstadistica(@PathVariable Long provinciaId,
                                     @PathVariable Long id,
                                     RedirectAttributes redirectAttributes) {
        try {
            provinciaService.eliminarEstadistica(id);
            redirectAttributes.addFlashAttribute("success", "Estadística eliminada exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar estadística: " + e.getMessage());
        }
        return "redirect:/admin/provincias/" + provinciaId + "/estadisticas";
    }

    // Gestión general de provincia
@PreAuthorize("hasPermission('/admin/provincias/gestion', 'ACCESS')")
    @GetMapping("/gestion/{provinciaId}")
    public String gestionarProvincia(@PathVariable Long provinciaId, Model model) {
        log.debug("Accediendo a la gestión de provincia ID: {}", provinciaId);
        return provinciaService.obtenerPorId(provinciaId)
                .map(provincia -> {
                    model.addAttribute("provincia", provincia);
                    return "admin/provincias/gestion";
                })
                .orElse("redirect:/admin/provincias");
    }

    // Historia management
    @PreAuthorize("hasPermission('/admin/provincias/historia', 'ACCESS')")
    @GetMapping("/{provinciaId}/historia")
    public String listarHistoria(@PathVariable Long provinciaId,
                                 @RequestParam(defaultValue = "0") int page,
                                 @RequestParam(defaultValue = "10") int size,
                                 Model model) {
        Pageable pageable = PageRequest.of(page, size);
        var historiaPage = provinciaService.obtenerHistoriaPorProvinciaPaginada(provinciaId, pageable);
        model.addAttribute("historiaPage", historiaPage);
        model.addAttribute("historia", historiaPage.getContent());
        model.addAttribute("provinciaId", provinciaId);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", historiaPage.getTotalPages());
        return "admin/provincias/historia/list";
    }

    @PreAuthorize("hasPermission('/admin/provincias/historia/nuevo', 'ACCESS')")
    @GetMapping("/{provinciaId}/historia/nuevo")
    public String mostrarFormularioNuevoEventoHistorico(@PathVariable Long provinciaId, Model model) {
        model.addAttribute("eventoHistorico", new HistoriaProvinciaDTO());
        model.addAttribute("provinciaId", provinciaId);
        return "admin/provincias/historia/formulario";
    }

    @PreAuthorize("hasPermission('/admin/provincias/historia/guardar', 'ACCESS')")
    @PostMapping("/{provinciaId}/historia/guardar")
    public String guardarEventoHistorico(@PathVariable Long provinciaId,
                                        @Valid @ModelAttribute("eventoHistorico") HistoriaProvinciaDTO historiaProvinciaDTO,
                                        BindingResult bindingResult,
                                        Model model,
                                        RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/historia/formulario";
        }
        try {
            if (provinciaService.existeEventoHistoricoConTitulo(provinciaId, historiaProvinciaDTO.getTitulo())) {
                bindingResult.rejectValue("titulo", "error.eventoHistorico.titulo.exists",
                        "Ya existe un evento histórico con este título");
                model.addAttribute("provinciaId", provinciaId);
                return "admin/provincias/historia/formulario";
            }
            provinciaService.crearEventoHistorico(provinciaId, historiaProvinciaDTO);
            redirectAttributes.addFlashAttribute("success", "Evento histórico creado exitosamente");
            return "redirect:/admin/provincias/" + provinciaId + "/historia";
        } catch (Exception e) {
            model.addAttribute("error", "Error al crear evento histórico: " + e.getMessage());
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/historia/formulario";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/historia/editar', 'ACCESS')")
    @GetMapping("/{provinciaId}/historia/editar/{id}")
    public String mostrarFormularioEditarEventoHistorico(@PathVariable Long provinciaId,
                                                         @PathVariable Long id,
                                                         Model model,
                                                         RedirectAttributes redirectAttributes) {
        try {
            HistoriaProvinciaDTO eventoHistoricoDTO = provinciaService.obtenerEventoHistoricoPorId(id);
            model.addAttribute("eventoHistorico", eventoHistoricoDTO);
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/historia/editar";
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Evento histórico no encontrado");
            return "redirect:/admin/provincias/" + provinciaId + "/historia";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/historia/actualizar', 'ACCESS')")
    @PostMapping("/{provinciaId}/historia/actualizar/{id}")
    public String actualizarEventoHistorico(@PathVariable Long provinciaId,
                                            @PathVariable Long id,
                                            @Valid @ModelAttribute("eventoHistorico") HistoriaProvinciaDTO historiaProvinciaDTO,
                                            BindingResult bindingResult,
                                            Model model,
                                            RedirectAttributes redirectAttributes) {
        if (bindingResult.hasErrors()) {
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/historia/editar";
        }
        try {
            if (provinciaService.existeEventoHistoricoConTituloExceptoId(provinciaId, historiaProvinciaDTO.getTitulo(), id)) {
                bindingResult.rejectValue("titulo", "error.eventoHistorico.titulo.exists",
                        "Ya existe otro evento histórico con este título");
                model.addAttribute("provinciaId", provinciaId);
                return "admin/provincias/historia/editar";
            }
            provinciaService.actualizarEventoHistorico(id, historiaProvinciaDTO);
            redirectAttributes.addFlashAttribute("success", "Evento histórico actualizado exitosamente");
            return "redirect:/admin/provincias/" + provinciaId + "/historia";
        } catch (Exception e) {
            model.addAttribute("error", "Error al actualizar evento histórico: " + e.getMessage());
            model.addAttribute("provinciaId", provinciaId);
            return "admin/provincias/historia/editar";
        }
    }

    @PreAuthorize("hasPermission('/admin/provincias/historia/eliminar', 'ACCESS')")
    @PostMapping("/{provinciaId}/historia/eliminar/{id}")
    public String eliminarEventoHistorico(@PathVariable Long provinciaId,
                                          @PathVariable Long id,
                                          RedirectAttributes redirectAttributes) {
        try {
            provinciaService.eliminarEventoHistorico(id);
            redirectAttributes.addFlashAttribute("success", "Evento histórico eliminado exitosamente");
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", "Error al eliminar evento histórico: " + e.getMessage());
        }
        return "redirect:/admin/provincias/" + provinciaId + "/historia";
    }
}
