package com.piuraexpressa.controller.admin;

import com.piuraexpressa.dto.PublicacionDTO;
import com.piuraexpressa.service.PublicacionService;
import com.piuraexpressa.service.UsuarioService;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
@RequestMapping("/admin/publicaciones")
public class PublicacionAdminController {

    private final PublicacionService publicacionService;
    private final UsuarioService usuarioService;

    public PublicacionAdminController(PublicacionService publicacionService, UsuarioService usuarioService) {
        this.publicacionService = publicacionService;
        this.usuarioService = usuarioService;
    }

    @PreAuthorize("hasPermission('/admin/publicaciones', 'ACCESS')")
    @GetMapping
    public String listarPublicaciones(@RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            Model model) {
        Pageable pageable = PageRequest.of(page, size);
        // Corregido para pasar usuarioId null
        Page<PublicacionDTO> publicaciones = publicacionService.obtenerTodasPaginadas(pageable, null);

        model.addAttribute("publicaciones", publicaciones);
        return "admin/publicaciones/list";
    }
}
