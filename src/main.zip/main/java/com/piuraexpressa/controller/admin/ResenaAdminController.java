package com.piuraexpressa.controller.admin;

import com.piuraexpressa.model.Resena;
import com.piuraexpressa.service.EventoService;
import com.piuraexpressa.service.ResenaService;
import com.piuraexpressa.service.UsuarioService;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/admin/resenas")
public class ResenaAdminController {

    private final ResenaService resenaService;
    private final EventoService eventoService;
    private final UsuarioService usuarioService;

    public ResenaAdminController(ResenaService resenaService, EventoService eventoService, UsuarioService usuarioService) {
        this.resenaService = resenaService;
        this.eventoService = eventoService;
        this.usuarioService = usuarioService;
    }

    @PreAuthorize("hasPermission('/admin/resenas', 'ACCESS')")
    @GetMapping
    public String listarResenas(@RequestParam(defaultValue = "0") int page,
                               @RequestParam(defaultValue = "10") int size,
                               Model model) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Resena> resenas = resenaService.obtenerTodosPaginados(pageable);
        model.addAttribute("resenas", resenas);
        return "admin/resenas/list";
    }

    @PreAuthorize("hasPermission('/admin/resenas/nuevo', 'ACCESS')")
    @GetMapping("/nuevo")
    public String mostrarFormularioNuevo(Model model) {
        model.addAttribute("resena", new Resena());
        model.addAttribute("eventos", eventoService.obtenerTodosActivos());
        model.addAttribute("usuarios", usuarioService.obtenerTodos());
        return "admin/resenas/form";
    }

    @PreAuthorize("hasPermission('/admin/resenas/guardar', 'ACCESS')")
    @PostMapping("/guardar")
    public String guardarResena(@Valid @ModelAttribute("resena") Resena resena,
                               BindingResult result,
                               RedirectAttributes redirectAttributes,
                               Model model) {
        if (result.hasErrors()) {
            model.addAttribute("eventos", eventoService.obtenerTodosActivos());
            model.addAttribute("usuarios", usuarioService.obtenerTodos());
            return "admin/resenas/form";
        }

        resenaService.guardar(resena);
        redirectAttributes.addFlashAttribute("success", "Reseña guardada correctamente");
        return "redirect:/admin/resenas";
    }

    @PreAuthorize("hasPermission('/admin/resenas/editar', 'ACCESS')")
    @GetMapping("/editar/{id}")
    public String mostrarFormularioEditar(@PathVariable Long id, Model model, RedirectAttributes redirectAttributes) {
        Resena resena = resenaService.obtenerPorId(id).orElse(null);
        if (resena == null) {
            redirectAttributes.addFlashAttribute("error", "Reseña no encontrada");
            return "redirect:/admin/resenas";
        }
        model.addAttribute("resena", resena);
        model.addAttribute("eventos", eventoService.obtenerTodosActivos());
        model.addAttribute("usuarios", usuarioService.obtenerTodos());
        return "admin/resenas/form";
    }

    @PreAuthorize("hasPermission('/admin/resenas/eliminar', 'ACCESS')")
    @PostMapping("/eliminar/{id}")
    public String eliminarResena(@PathVariable Long id, RedirectAttributes redirectAttributes) {
        resenaService.eliminar(id);
        redirectAttributes.addFlashAttribute("success", "Reseña eliminada correctamente");
        return "redirect:/admin/resenas";
    }
}
