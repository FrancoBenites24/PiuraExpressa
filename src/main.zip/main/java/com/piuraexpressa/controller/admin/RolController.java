package com.piuraexpressa.controller.admin;

import com.piuraexpressa.model.Permiso;
import com.piuraexpressa.model.Rol;
import com.piuraexpressa.service.PermisoService;
import com.piuraexpressa.service.RolService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

import org.springframework.security.access.prepost.PreAuthorize;

@Controller
@RequestMapping("/admin/roles")
@RequiredArgsConstructor
public class RolController {

    private final RolService rolService;
    private final PermisoService permisoService;

    @PreAuthorize("hasPermission('/admin/roles', 'ACCESS')")
    @GetMapping
    public String listRoles(Model model,
                            @RequestParam(defaultValue = "0") int page,
                            @RequestParam(defaultValue = "10") int size) {
        Page<Rol> rolesPage = rolService.findAll(PageRequest.of(page, size));
        model.addAttribute("rolesPage", rolesPage);
        return "admin/roles/list";
    }

    @PreAuthorize("hasPermission('/admin/roles/nuevo', 'ACCESS')")
    @GetMapping("/nuevo")
    public String newRoleForm(Model model) {
        model.addAttribute("rol", new Rol());
        List<Permiso> permisos = permisoService.findAll(PageRequest.of(0, 100)).getContent();
        model.addAttribute("permisos", permisos);
        return "admin/roles/form";
    }

    @PreAuthorize("hasPermission('/admin/roles/editar', 'ACCESS')")
    @GetMapping("/editar/{id}")
    public String editRoleForm(@PathVariable Long id, Model model) {
        Optional<Rol> rolOpt = rolService.findById(id);
        if (rolOpt.isEmpty()) {
            return "redirect:/admin/roles";
        }
        model.addAttribute("rol", rolOpt.get());
        List<Permiso> permisos = permisoService.findAll(PageRequest.of(0, 100)).getContent();
        model.addAttribute("permisos", permisos);
        return "admin/roles/form";
    }

    @PreAuthorize("hasPermission('/admin/roles/guardar', 'ACCESS')")
    @PostMapping("/guardar")
    public String saveRole(@Valid @ModelAttribute("rol") Rol rol,
                           BindingResult bindingResult,
                           Model model) {
        if (bindingResult.hasErrors()) {
            List<Permiso> permisos = permisoService.findAll(PageRequest.of(0, 100)).getContent();
            model.addAttribute("permisos", permisos);
            return "admin/roles/form";
        }
        rolService.save(rol);
        return "redirect:/admin/roles";
    }

    @PreAuthorize("hasPermission('/admin/roles/eliminar', 'ACCESS')")
    @GetMapping("/eliminar/{id}")
    public String deleteRole(@PathVariable Long id) {
        rolService.deleteById(id);
        return "redirect:/admin/roles";
    }
}
