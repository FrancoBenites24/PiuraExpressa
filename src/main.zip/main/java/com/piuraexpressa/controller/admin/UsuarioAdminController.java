package com.piuraexpressa.controller.admin;

import com.piuraexpressa.service.ProvinciaService;
import com.piuraexpressa.service.RolService;
import com.piuraexpressa.service.UsuarioService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.piuraexpressa.dto.UsuarioDTO;

@Controller
@RequestMapping("/admin/usuarios")
@RequiredArgsConstructor
@Slf4j
public class UsuarioAdminController {

    private final UsuarioService usuarioService;
    private final ProvinciaService provinciaService;
    private final RolService rolService;

    @PreAuthorize("hasPermission('/admin/usuarios', 'ACCESS')")
    @GetMapping
    public String listUsuarios(
            @RequestParam(value = "search", required = false) String search,
            @RequestParam(value = "provinciaName", required = false) String provinciaName,
            Pageable pageable,
            Model model) {
        try {
            Page<UsuarioDTO> usuarios = usuarioService.buscarUsuariosPaginados(search, provinciaName, pageable);
            model.addAttribute("usuarios", usuarios);

            // Provincias para filtro
            model.addAttribute("provincias", provinciaService.obtenerTodasActivas());

            // Roles para cambio de rol
            model.addAttribute("roles", rolService.obtenerTodosLosRoles());

            return "admin/usuarios/list";
        } catch (Exception e) {
            log.error("Error al listar usuarios: {}", e.getMessage(), e);
            model.addAttribute("error", "Error al cargar la lista de usuarios");
            return "admin/usuarios/list";
        }
    }

    @PreAuthorize("hasPermission('/admin/usuarios/desactivar', 'ACCESS')")
    @PostMapping("/desactivar/{id}")
    public String desactivarUsuario(@PathVariable Long id) {
        try {
            usuarioService.desactivar(id);
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            log.error("Error al desactivar usuario: {}", e.getMessage(), e);
            return "redirect:/admin/usuarios?error=Error al desactivar usuario";
        }
    }

    @PreAuthorize("hasPermission('/admin/usuarios/activar', 'ACCESS')")
    @PostMapping("/activar/{id}")
    public String activarUsuario(@PathVariable Long id) {
        try {
            usuarioService.activar(id);
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            log.error("Error al activar usuario: {}", e.getMessage(), e);
            return "redirect:/admin/usuarios?error=Error al activar usuario";
        }
    }

    @PreAuthorize("hasPermission('/admin/usuarios/cambiar-rol', 'ACCESS')")
    @PostMapping("/cambiar-rol/{userId}/{roleId}")
    public String cambiarRolUsuario(@PathVariable Long userId, @PathVariable Long roleId) {
        try {
            usuarioService.cambiarRolUsuario(userId, roleId);
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            log.error("Error al cambiar rol de usuario: {}", e.getMessage(), e);
            return "redirect:/admin/usuarios?error=Error al cambiar rol de usuario";
        }
    }

    @PreAuthorize("hasPermission('/admin/usuarios/eliminar', 'ACCESS')")
    @PostMapping("/eliminar/{id}")
    public String eliminarUsuario(@PathVariable Long id) {
        try {
            usuarioService.eliminar(id);
            return "redirect:/admin/usuarios";
        } catch (Exception e) {
            log.error("Error al eliminar usuario: {}", e.getMessage(), e);
            return "redirect:/admin/usuarios?error=Error al eliminar usuario";
        }
    }
}
