package com.piuraexpressa.dto;

import com.piuraexpressa.model.Asistencia;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class AsistenciaDTO {

    private Long id;

    @NotNull(message = "El usuario es obligatorio")
    private Long usuarioId;
    private String usuarioNombre;
    private String usuarioUsername;

    @NotNull(message = "El evento es obligatorio")
    private Long eventoId;
    private String eventoTitulo;
    private LocalDateTime eventoFechaInicio;

    @NotNull(message = "El estado es obligatorio")
    private Asistencia.EstadoAsistencia estado;

    @Size(max = 500, message = "Las observaciones no pueden exceder 500 caracteres")
    private String observaciones;

    private LocalDateTime fechaRegistro;
    private LocalDateTime fechaActualizacion;

    // Campos calculados
    private String estadoDescripcion;
    private boolean puedeModificar;
    private boolean eventoYaOcurrio;
}
