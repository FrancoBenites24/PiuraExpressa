package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClimaProvinciaDTO {

    private Long id;
    private Long provinciaId;
    private String provinciaNombre;

    private BigDecimal temperaturaActual;
    private BigDecimal temperaturaMaxima;
    private BigDecimal temperaturaMinima;

    @Min(value = 0, message = "La humedad debe estar entre 0 y 100")
    @Max(value = 100, message = "La humedad debe estar entre 0 y 100")
    private Integer humedad;

    private BigDecimal presionAtmosferica;

    @DecimalMin(value = "0.0", message = "La velocidad del viento debe ser mayor o igual a 0")
    private BigDecimal velocidadViento;

    @Size(max = 100, message = "La descripción del clima no puede exceder 100 caracteres")
    private String descripcionClima;

    @Size(max = 20, message = "El icono del clima no puede exceder 20 caracteres")
    private String iconoClima;

    private LocalDateTime fechaActualizacion;

    // Campos formateados
    private String temperaturaFormateada;
    private String rangoTemperatura;
}
