package com.piuraexpressa.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ComentarioDTO {
    private Long id;
    private String contenido;
    private String usuarioNombre;
    private String tiempoTranscurrido;
    private Long publicacionId;

    private String publicacionTitulo;
    private Long usuarioId;
    private String usuarioUsername;
    private boolean puedeEditar;
    private boolean puedeEliminar;
}
