package com.piuraexpressa.dto;

import lombok.Data;

import java.math.BigDecimal;
import java.time.Year;

@Data
public class EstadisticaProvinciaDTO {
    private Long id;
    private Year anoActualizacion;
    
    // Campos principales que coinciden con la entidad
    private Integer poblacionTotal;
    private BigDecimal superficieKm2;
    private BigDecimal densidadPoblacional;
    private Integer altitudPromedio;
    private BigDecimal temperaturaPromedio;
    private BigDecimal precipitacionAnual;
    private BigDecimal pibPerCapita;
    private BigDecimal tasaAlfabetizacion;
    private Integer establecimientosSalud;
    private Integer centrosEducativos;
    private Integer hotelesRegistrados;
    private Integer restaurantesRegistrados;
    private Integer atractivosTuristicos;
    private Integer festivalesAnuales;
    
    private BigDecimal valor;
    
    // Campos derivados
    private Long provinciaId;
    private String provinciaNombre;
    private String poblacionFormateada;
    private String superficieFormateada;
    private String densidadFormateada;
    
    public BigDecimal getValor() {
        return valor;
    }
    
    public void setValor(BigDecimal valor) {
        this.valor = valor;
    }
}
