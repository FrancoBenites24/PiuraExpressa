package com.piuraexpressa.dto;

import com.piuraexpressa.model.GaleriaProvincia;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GaleriaProvinciaDTO {

    private Long id;
    private Long provinciaId;
    private String provinciaNombre;

    @NotBlank(message = "El título es obligatorio")
    @Size(max = 100, message = "El título no puede exceder 100 caracteres")
    private String titulo;

    private String descripcion;

    @NotBlank(message = "La URL de la imagen es obligatoria")
    @Size(max = 255, message = "La URL de la imagen no puede exceder 255 caracteres")
    private String urlImagen;

    @NotNull(message = "La categoría es obligatoria")
    private GaleriaProvincia.CategoriaGaleria categoria;

    private boolean esPortada;
    private Integer ordenVisualizacion;

    @Size(max = 100, message = "El nombre del fotógrafo no puede exceder 100 caracteres")
    private String fotografo;

    private LocalDate fechaToma;
    private boolean activa;
    private LocalDateTime fechaCreacion;

    // Campos calculados
    private String categoriaDescripcion;
}
