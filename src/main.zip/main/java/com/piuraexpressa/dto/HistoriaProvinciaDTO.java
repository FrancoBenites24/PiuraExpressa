package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.time.Year;

@Data
public class HistoriaProvinciaDTO {
    private Long id;

    @NotNull(message = "El año es obligatorio")
    @Min(value = 1000, message = "El año debe ser válido")
    @Max(value = Year.MAX_VALUE, message = "El año es inválido")
    private Integer ano;

    @NotBlank(message = "El título es obligatorio")
    private String titulo;

    @NotBlank(message = "La descripción es obligatoria")
    private String descripcion;

    @NotNull(message = "El orden cronológico es obligatorio")
    @Min(value = 1, message = "El orden cronológico debe ser mayor o igual a 1")
    private Integer ordenCronologico;

    private Boolean activo;
}
