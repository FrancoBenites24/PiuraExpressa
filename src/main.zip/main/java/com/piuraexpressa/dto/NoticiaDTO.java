package com.piuraexpressa.dto;

import com.piuraexpressa.model.Noticia;
import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class NoticiaDTO {

    private Long id;

    @NotBlank(message = "El título es obligatorio")
    @Size(min = 10, max = 200, message = "El título debe tener entre 10 y 200 caracteres")
    private String titulo;

    @Size(max = 300, message = "El subtítulo no puede exceder 300 caracteres")
    private String subtitulo;

    @NotBlank(message = "El contenido es obligatorio")
    @Size(min = 50, message = "El contenido debe tener al menos 50 caracteres")
    private String contenido;

    @Size(max = 500, message = "El resumen no puede exceder 500 caracteres")
    private String resumen;

    private String imagenUrl;

    @NotNull(message = "El autor es obligatorio")
    private Long autorId;
    private String autorNombre;
    private String autorUsername;

    @NotNull(message = "La categoría es obligatoria")
    private Noticia.CategoriaNoticia categoria;

    private boolean destacada;
    private boolean activa;
    private LocalDateTime fechaPublicacion;
    private LocalDateTime fechaActualizacion;

    @Pattern(regexp = "^[a-z0-9-]+$", message = "El slug solo puede contener letras minúsculas, números y guiones")
    private String slug;

    @Size(max = 160, message = "La meta descripción no puede exceder 160 caracteres")
    private String metaDescripcion;

    @Size(max = 500, message = "Los tags no pueden exceder 500 caracteres")
    private String tags;

    private int vistas;

    // Campos calculados
    private String categoriaDescripcion;
    private String resumenCorto;
    private String[] tagsArray;
    private String tiempoPublicacion;
    private String urlCompleta;
}
