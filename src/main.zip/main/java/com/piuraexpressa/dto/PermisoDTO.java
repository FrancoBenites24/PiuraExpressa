package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class PermisoDTO {

    private Long id;

    @NotBlank(message = "El recurso es obligatorio.")
    private String recurso;

    @NotBlank(message = "La acción es obligatoria.")
    private String accion;

    @NotBlank(message = "El nombre del permiso es obligatorio.")
    private String nombre;
}
