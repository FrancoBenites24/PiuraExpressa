package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProvinciaDTO {

    private Long id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 50, message = "El nombre no puede exceder 50 caracteres")
    private String nombre;

    @Size(max = 255, message = "El subtítulo no puede exceder 255 caracteres")
    private String subtitulo;

    private String descripcion;
    private String imagenPrincipal;

    @DecimalMin(value = "-90.0", message = "La latitud debe estar entre -90 y 90")
    @DecimalMax(value = "90.0", message = "La latitud debe estar entre -90 y 90")
    private BigDecimal latitud;

    @DecimalMin(value = "-180.0", message = "La longitud debe estar entre -180 y 180")
    @DecimalMax(value = "180.0", message = "La longitud debe estar entre -180 y 180")
    private BigDecimal longitud;

    private Integer altitudPromedio;
    private String climaDescripcion;
    private String mejorEpocaVisita;
    private boolean activa;
    private LocalDateTime fechaCreacion;
    private LocalDateTime fechaActualizacion;

    // Datos relacionados
    private EstadisticaProvinciaDTO estadisticaActual;
    private ClimaProvinciaDTO clima;
    private List<PuntoInteresDTO> puntosInteres;
    private List<GaleriaProvinciaDTO> galeria;
    private List<HistoriaProvinciaDTO> historia;
    private List<EventoDTO> eventos;
    private List<PlatoDTO> platos;

    // Campos calculados
    private int totalEventos;
    private int totalPlatos;
    private int totalPuntosInteres;
    private int totalImagenes;
}
