package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PublicacionDTO {

    private Long id;

    @NotNull(message = "El usuario es obligatorio")
    private Long usuarioId;
    private String usuarioNombre;
    private String usuarioUsername;

    @NotBlank(message = "El título es obligatorio")
    @Size(min = 5, max = 200, message = "El título debe tener entre 5 y 200 caracteres")
    private String titulo;

    @NotBlank(message = "El contenido es obligatorio")
    @Size(min = 10, message = "El contenido debe tener al menos 10 caracteres")
    private String contenido;

    private String imagen;
    private boolean activa;
    private LocalDateTime fechaCreacion;
    private LocalDateTime fechaActualizacion;

    // Relaciones
    private List<ComentarioDTO> comentarios;

    // Campos calculados
    private int totalComentarios;
    private int totalLikes;
    private boolean usuarioHaDadoLike;
    private String tiempoTranscurrido;
    private String contenidoResumen;
    private boolean puedeEditar;
    private boolean puedeEliminar;
}
