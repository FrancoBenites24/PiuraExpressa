package com.piuraexpressa.dto;

import lombok.Data;

import java.time.LocalDateTime;

@Data
public class PuntoInteresDTO {
    private Long id;
    private String nombre;
    private String descripcion;
    private String tipo;
    private String imagenUrl;
    private Double calificacion;
    private Integer numeroResenas;
    private Double precioPromedio;
    private Boolean activo;

    private String direccion;
    private String email;
    private LocalDateTime fechaCreacion;
    private String horarioAtencion;
    private Double latitud;
    private Double longitud;
    private Long provinciaId;
    private String sitioWeb;
    private String telefono;
}
