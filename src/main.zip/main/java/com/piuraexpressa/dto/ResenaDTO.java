package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

import java.time.LocalDateTime;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ResenaDTO {

    private Long id;

    @NotNull(message = "El usuario es obligatorio")
    private Long usuarioId;
    private String usuarioNombre;
    private String usuarioUsername;

    @NotNull(message = "El evento es obligatorio")
    private Long eventoId;
    private String eventoTitulo;

    @Size(max = 100, message = "El título no puede exceder 100 caracteres")
    private String titulo;

    @NotBlank(message = "El contenido es obligatorio")
    @Size(min = 10, max = 1000, message = "El contenido debe tener entre 10 y 1000 caracteres")
    private String contenido;

    @NotNull(message = "La calificación es obligatoria")
    @Min(value = 1, message = "La calificación mínima es 1")
    @Max(value = 5, message = "La calificación máxima es 5")
    private Integer calificacion;

    private boolean activa;
    private LocalDateTime fechaCreacion;
    private LocalDateTime fechaActualizacion;

    // Campos calculados
    private String calificacionEstrellas;
    private String tiempoTranscurrido;
    private boolean puedeEditar;
    private boolean puedeEliminar;
}
