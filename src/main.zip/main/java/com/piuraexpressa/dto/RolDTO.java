package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class RolDTO {

    private Long id;

    @NotBlank(message = "El nombre del rol es obligatorio.")
    @Size(max = 50, message = "El nombre no debe exceder los 50 caracteres.")
    private String nombre;

    @Size(max = 200, message = "La descripción no debe exceder los 200 caracteres.")
    private String descripcion;
}
