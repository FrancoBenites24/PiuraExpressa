package com.piuraexpressa.dto;

import jakarta.validation.constraints.*;
import lombok.*;

@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class UsuarioDTO {

    private Long id;

    @NotBlank(message = "El email es obligatorio.")
    @Email(message = "Debe proporcionar un email válido.")
    @Size(max = 100, message = "El email no debe exceder los 100 caracteres.")
    private String email;

    @NotBlank(message = "El nombre de usuario es obligatorio.")
    @Size(max = 50, message = "El nombre de usuario no debe exceder los 50 caracteres.")
    private String username;

    @NotBlank(message = "Los nombres son obligatorios.")
    private String nombres;

    @NotBlank(message = "Los apellidos son obligatorios.")
    private String apellidos;

    @Size(max = 15, message = "El teléfono no debe exceder los 15 caracteres.")
    private String telefono;

    @Size(max = 50, message = "La provincia no debe exceder los 50 caracteres.")
    private String provincia;

    @Size(max = 50, message = "El distrito no debe exceder los 50 caracteres.")
    private String distrito;

    @Size(max = 200, message = "La dirección no debe exceder los 200 caracteres.")
    private String direccion;
}
