package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.AsistenciaDTO;
import com.piuraexpressa.model.Asistencia;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring")
public interface AsistenciaMapper {

    @Mapping(target = "usuarioId", source = "usuario.id")
    @Mapping(target = "usuarioNombre", source = "usuario.nombres")
    @Mapping(target = "usuarioUsername", source = "usuario.username")
    @Mapping(target = "eventoId", source = "evento.id")
    @Mapping(target = "eventoTitulo", source = "evento.titulo")
    @Mapping(target = "eventoFechaInicio", source = "evento.fechaInicio")
    @Mapping(target = "estadoDescripcion", expression = "java(asistencia.getEstado().getDescripcion())")
    @Mapping(target = "puedeModificar", expression = "java(asistencia.puedeModificar())")
    @Mapping(target = "eventoYaOcurrio", expression = "java(asistencia.eventoYaOcurrio())")
    AsistenciaDTO toDTO(Asistencia asistencia);

    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "evento", ignore = true)
    @Mapping(target = "fechaRegistro", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    Asistencia toEntity(AsistenciaDTO asistenciaDTO);

    List<AsistenciaDTO> toDTOList(List<Asistencia> asistencias);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "evento", ignore = true)
    @Mapping(target = "fechaRegistro", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(AsistenciaDTO asistenciaDTO, @MappingTarget Asistencia asistencia);
}
