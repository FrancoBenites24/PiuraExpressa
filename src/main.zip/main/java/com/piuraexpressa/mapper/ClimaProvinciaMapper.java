package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.ClimaProvinciaDTO;
import com.piuraexpressa.model.ClimaProvincia;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ClimaProvinciaMapper {

    @Mapping(target = "provinciaId", source = "provincia.id")
    @Mapping(target = "provinciaNombre", source = "provincia.nombre")
    @Mapping(target = "temperaturaFormateada", expression = "java(clima.getTemperaturaFormateada())")
    @Mapping(target = "rangoTemperatura", expression = "java(clima.getRangoTemperatura())")
    ClimaProvinciaDTO toDTO(ClimaProvincia clima);

    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    ClimaProvincia toEntity(ClimaProvinciaDTO climaDTO);

    List<ClimaProvinciaDTO> toDTOList(List<ClimaProvincia> climas);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(ClimaProvinciaDTO climaDTO, @MappingTarget ClimaProvincia clima);
}
