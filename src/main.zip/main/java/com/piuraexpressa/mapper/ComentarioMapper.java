package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.ComentarioDTO;
import com.piuraexpressa.model.Comentario;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring")
public interface ComentarioMapper {

    @Mapping(target = "publicacionId", source = "publicacion.id")
    @Mapping(target = "publicacionTitulo", source = "publicacion.titulo")
    @Mapping(target = "usuarioId", source = "usuario.id")
    @Mapping(target = "usuarioNombre", source = "usuario.nombres")
    @Mapping(target = "usuarioUsername", source = "usuario.username")
    @Mapping(target = "tiempoTranscurrido", expression = "java(calcularTiempoTranscurrido(comentario.getFechaCreacion()))")
    @Mapping(target = "puedeEditar", expression = "java(false)") // Se calculará en el servicio según el usuario actual
    @Mapping(target = "puedeEliminar", expression = "java(false)") // Se calculará en el servicio según el usuario actual
    ComentarioDTO toDTO(Comentario comentario);

    @Mapping(target = "publicacion", ignore = true)
    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    Comentario toEntity(ComentarioDTO comentarioDTO);

    List<ComentarioDTO> toDTOList(List<Comentario> comentarios);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "publicacion", ignore = true)
    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    void updateEntityFromDTO(ComentarioDTO comentarioDTO, @MappingTarget Comentario comentario);

    default String calcularTiempoTranscurrido(LocalDateTime fechaCreacion) {
        if (fechaCreacion == null) return "";
        
        LocalDateTime ahora = LocalDateTime.now();
        long minutos = ChronoUnit.MINUTES.between(fechaCreacion, ahora);
        
        if (minutos < 1) return "Hace un momento";
        if (minutos < 60) return "Hace " + minutos + " minuto" + (minutos > 1 ? "s" : "");
        
        long horas = ChronoUnit.HOURS.between(fechaCreacion, ahora);
        if (horas < 24) return "Hace " + horas + " hora" + (horas > 1 ? "s" : "");
        
        long dias = ChronoUnit.DAYS.between(fechaCreacion, ahora);
        if (dias < 30) return "Hace " + dias + " día" + (dias > 1 ? "s" : "");
        
        long meses = ChronoUnit.MONTHS.between(fechaCreacion, ahora);
        if (meses < 12) return "Hace " + meses + " mes" + (meses > 1 ? "es" : "");
        
        long anios = ChronoUnit.YEARS.between(fechaCreacion, ahora);
        return "Hace " + anios + " año" + (anios > 1 ? "s" : "");
    }
}
