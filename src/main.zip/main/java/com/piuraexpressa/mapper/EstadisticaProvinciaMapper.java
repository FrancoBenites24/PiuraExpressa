package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.EstadisticaProvinciaDTO;
import com.piuraexpressa.model.EstadisticaProvincia;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EstadisticaProvinciaMapper {

    @Mapping(target = "provinciaId", source = "provincia.id")
    @Mapping(target = "provinciaNombre", source = "provincia.nombre")
    @Mapping(target = "poblacionFormateada", expression = "java(estadistica.getPoblacionFormateada())")
    @Mapping(target = "superficieFormateada", expression = "java(estadistica.getSuperficieFormateada())")
    @Mapping(target = "densidadFormateada", expression = "java(estadistica.getDensidadFormateada())")
    @Mapping(target = "poblacionTotal", source = "poblacionTotal")
    EstadisticaProvinciaDTO toDTO(EstadisticaProvincia estadistica);

    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    EstadisticaProvincia toEntity(EstadisticaProvinciaDTO estadisticaDTO);

    List<EstadisticaProvinciaDTO> toDTOList(List<EstadisticaProvincia> estadisticas);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(EstadisticaProvinciaDTO estadisticaDTO, @MappingTarget EstadisticaProvincia estadistica);
}
