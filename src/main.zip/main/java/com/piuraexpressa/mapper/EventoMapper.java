package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.EventoDTO;
import com.piuraexpressa.model.Evento;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring")
public interface EventoMapper {

    @Mapping(target = "provinciaId", source = "provincia.id")
    @Mapping(target = "provinciaNombre", source = "provincia.nombre")
    @Mapping(target = "esGratuito", expression = "java(esGratuito(evento))")
    @Mapping(target = "estaDisponible", expression = "java(estaDisponible(evento))")
    @Mapping(target = "diasRestantes", expression = "java(calcularDiasRestantes(evento.getFechaInicio()))")
    @Mapping(target = "estadoEvento", expression = "java(determinarEstadoEvento(evento))")
    @Mapping(target = "precioFormateado", expression = "java(formatearPrecio(evento.getPrecio()))")
    EventoDTO toDTO(Evento evento);

    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    @Mapping(target = "asistencias", ignore = true)
    @Mapping(target = "resenas", ignore = true)
    Evento toEntity(EventoDTO eventoDTO);

    List<EventoDTO> toDTOList(List<Evento> eventos);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    @Mapping(target = "asistencias", ignore = true)
    @Mapping(target = "resenas", ignore = true)
    void updateEntityFromDTO(EventoDTO eventoDTO, @MappingTarget Evento evento);

    // Métodos de utilidad
    default boolean esGratuito(Evento evento) {
        return evento.getPrecio() == null || evento.getPrecio().compareTo(java.math.BigDecimal.ZERO) == 0;
    }

    default boolean estaDisponible(Evento evento) {
        LocalDateTime ahora = LocalDateTime.now();
        return evento.isActivo() && 
               evento.getFechaInicio().isAfter(ahora) &&
               (evento.getCapacidad() == null || evento.getCapacidad() > 0);
    }

    default long calcularDiasRestantes(LocalDateTime fechaInicio) {
        if (fechaInicio == null) return 0;
        LocalDateTime ahora = LocalDateTime.now();
        return ahora.isBefore(fechaInicio) ? ChronoUnit.DAYS.between(ahora, fechaInicio) : 0;
    }

    default String determinarEstadoEvento(Evento evento) {
        LocalDateTime ahora = LocalDateTime.now();
        if (evento.getFechaInicio().isAfter(ahora)) {
            return "PROXIMO";
        } else if (evento.getFechaFin() != null && evento.getFechaFin().isBefore(ahora)) {
            return "FINALIZADO";
        } else {
            return "EN_CURSO";
        }
    }

    default String formatearPrecio(java.math.BigDecimal precio) {
        if (precio == null || precio.compareTo(java.math.BigDecimal.ZERO) == 0) {
            return "Gratis";
        }
        return "S/ " + precio.toString();
    }
}
