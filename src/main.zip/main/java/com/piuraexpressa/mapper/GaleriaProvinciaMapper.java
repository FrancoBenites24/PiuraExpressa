package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.GaleriaProvinciaDTO;
import com.piuraexpressa.model.GaleriaProvincia;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring")
public interface GaleriaProvinciaMapper {

    @Mapping(target = "provinciaId", source = "provincia.id")
    @Mapping(target = "provinciaNombre", source = "provincia.nombre")
    @Mapping(target = "categoriaDescripcion", expression = "java(galeria.getCategoria().getDescripcion())")
    GaleriaProvinciaDTO toDTO(GaleriaProvincia galeria);

    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    GaleriaProvincia toEntity(GaleriaProvinciaDTO galeriaDTO);

    List<GaleriaProvinciaDTO> toDTOList(List<GaleriaProvincia> galerias);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "provincia", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    void updateEntityFromDTO(GaleriaProvinciaDTO galeriaDTO, @MappingTarget GaleriaProvincia galeria);
}
