package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.HistoriaProvinciaDTO;
import com.piuraexpressa.model.HistoriaProvincia;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;
import org.mapstruct.factory.Mappers;

import java.util.List;

import java.time.Year;

@Mapper(componentModel = "spring")
public interface HistoriaProvinciaMapper {

    HistoriaProvinciaMapper INSTANCE = Mappers.getMapper(HistoriaProvinciaMapper.class);

    HistoriaProvinciaDTO toDTO(HistoriaProvincia entity);

    HistoriaProvincia toEntity(HistoriaProvinciaDTO dto);

    List<HistoriaProvinciaDTO> toDTOList(List<HistoriaProvincia> entities);

    HistoriaProvincia updateEntityFromDTO(HistoriaProvinciaDTO dto, @MappingTarget HistoriaProvincia entity);

    default Year map(Integer value) {
        return value == null ? null : Year.of(value);
    }

    default Integer map(Year value) {
        return value == null ? null : value.getValue();
    }
}
