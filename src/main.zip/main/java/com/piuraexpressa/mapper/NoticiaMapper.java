package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.NoticiaDTO;
import com.piuraexpressa.model.Noticia;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring")
public interface NoticiaMapper {

    @Mapping(target = "autorId", source = "autor.id")
    @Mapping(target = "autorNombre", source = "autor.nombres")
    @Mapping(target = "autorUsername", source = "autor.username")
    @Mapping(target = "categoriaDescripcion", expression = "java(noticia.getCategoria().getDescripcion())")
    @Mapping(target = "resumenCorto", expression = "java(noticia.getResumenCorto())")
    @Mapping(target = "tagsArray", expression = "java(noticia.getTagsArray())")
    @Mapping(target = "tiempoPublicacion", expression = "java(calcularTiempoPublicacion(noticia.getFechaPublicacion()))")
    @Mapping(target = "urlCompleta", expression = "java(generarUrlCompleta(noticia.getSlug()))")
    NoticiaDTO toDTO(Noticia noticia);

    @Mapping(target = "autor", ignore = true)
    @Mapping(target = "fechaPublicacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    Noticia toEntity(NoticiaDTO noticiaDTO);

    List<NoticiaDTO> toDTOList(List<Noticia> noticias);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "autor", ignore = true)
    @Mapping(target = "fechaPublicacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(NoticiaDTO noticiaDTO, @MappingTarget Noticia noticia);

    default String calcularTiempoPublicacion(LocalDateTime fechaPublicacion) {
        if (fechaPublicacion == null) return "";
        
        LocalDateTime ahora = LocalDateTime.now();
        long minutos = ChronoUnit.MINUTES.between(fechaPublicacion, ahora);
        
        if (minutos < 1) return "Hace un momento";
        if (minutos < 60) return "Hace " + minutos + " minuto" + (minutos > 1 ? "s" : "");
        
        long horas = ChronoUnit.HOURS.between(fechaPublicacion, ahora);
        if (horas < 24) return "Hace " + horas + " hora" + (horas > 1 ? "s" : "");
        
        long dias = ChronoUnit.DAYS.between(fechaPublicacion, ahora);
        if (dias < 30) return "Hace " + dias + " día" + (dias > 1 ? "s" : "");
        
        return fechaPublicacion.toLocalDate().toString();
    }

    default String generarUrlCompleta(String slug) {
        return "/noticias/" + slug;
    }
}
