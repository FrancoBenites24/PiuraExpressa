package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.PermisoDTO;
import com.piuraexpressa.model.Permiso;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PermisoMapper {
    PermisoDTO toDto(Permiso permiso);
    Permiso toEntidad(PermisoDTO dto);
    List<PermisoDTO> toDtoLista(List<Permiso> permisos);
}
