package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.PlatoDTO;
import com.piuraexpressa.model.Plato;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.factory.Mappers;

@Mapper(componentModel = "spring")
public interface PlatoMapper {

    PlatoMapper INSTANCE = Mappers.getMapper(PlatoMapper.class);

    @Mapping(source = "provincia.id", target = "provinciaId")
    PlatoDTO toDto(Plato plato);

    @Mapping(source = "provinciaId", target = "provincia.id")
    Plato toEntity(PlatoDTO platoDTO);
}
