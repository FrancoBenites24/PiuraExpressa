package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.*;
import com.piuraexpressa.model.*;
import org.mapstruct.*;

import java.util.List;

@Mapper(componentModel = "spring", uses = {
    EstadisticaProvinciaMapper.class,
    ClimaProvinciaMapper.class,
    PuntoInteresMapper.class,
    GaleriaProvinciaMapper.class,
    HistoriaProvinciaMapper.class,
    EventoMapper.class,
    PlatoMapper.class
})
public interface ProvinciaMapper {

    @Mapping(target = "estadisticaActual", source = "estadisticaActual")
    @Mapping(target = "clima", source = "clima")
    @Mapping(target = "puntosInteres", source = "puntosInteres")
    @Mapping(target = "galeria", source = "galeria")
    @Mapping(target = "historia", source = "historia")
    @Mapping(target = "eventos", source = "eventos")
    @Mapping(target = "platos", source = "platos")
    @Mapping(target = "totalEventos", expression = "java(provincia.getEventos().size())")
    @Mapping(target = "totalPlatos", expression = "java(provincia.getPlatos().size())")
    @Mapping(target = "totalPuntosInteres", expression = "java(provincia.getPuntosInteres().size())")
    @Mapping(target = "totalImagenes", expression = "java(provincia.getGaleria().size())")
    ProvinciaDTO toDTO(Provincia provincia);

    @Mapping(target = "eventos", ignore = true)
    @Mapping(target = "platos", ignore = true)
    @Mapping(target = "galeria", ignore = true)
    @Mapping(target = "estadisticas", ignore = true)
    @Mapping(target = "clima", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    Provincia toEntity(ProvinciaDTO provinciaDTO);

    List<ProvinciaDTO> toDTOList(List<Provincia> provincias);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "eventos", ignore = true)
    @Mapping(target = "platos", ignore = true)
    @Mapping(target = "galeria", ignore = true)
    @Mapping(target = "estadisticas", ignore = true)
    @Mapping(target = "clima", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(ProvinciaDTO provinciaDTO, @MappingTarget Provincia provincia);

}
