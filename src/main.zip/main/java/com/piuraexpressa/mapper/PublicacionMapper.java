package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.PublicacionDTO;
import com.piuraexpressa.model.Publicacion;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring", uses = { ComentarioMapper.class })
public interface PublicacionMapper {

    @Mapping(target = "usuarioId", source = "usuario.id")
    @Mapping(target = "usuarioNombre", source = "usuario.nombres")
    @Mapping(target = "usuarioUsername", source = "usuario.username")
    @Mapping(target = "comentarios", source = "comentarios")
    @Mapping(target = "totalComentarios", expression = "java(publicacion.getComentarios().size())")
    @Mapping(target = "totalLikes", expression = "java(0)") // Se calculará en el servicio
    @Mapping(target = "usuarioHaDadoLike", expression = "java(false)") // Se calculará en el servicio
    @Mapping(target = "tiempoTranscurrido", expression = "java(calcularTiempoTranscurrido(publicacion.getFechaCreacion()))")
    @Mapping(target = "contenidoResumen", expression = "java(generarResumen(publicacion.getContenido()))")
    @Mapping(target = "puedeEditar", expression = "java(false)") // Se calculará en el servicio
    @Mapping(target = "puedeEliminar", expression = "java(false)") // Se calculará en el servicio
    PublicacionDTO toDTO(Publicacion publicacion);

    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "comentarios", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    Publicacion toEntity(PublicacionDTO publicacionDTO);

    List<PublicacionDTO> toDTOList(List<Publicacion> publicaciones);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "comentarios", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(PublicacionDTO publicacionDTO, @MappingTarget Publicacion publicacion);

    default String calcularTiempoTranscurrido(LocalDateTime fechaCreacion) {
        if (fechaCreacion == null)
            return "";

        LocalDateTime ahora = LocalDateTime.now();
        long minutos = ChronoUnit.MINUTES.between(fechaCreacion, ahora);

        if (minutos < 1)
            return "Hace un momento";
        if (minutos < 60)
            return "Hace " + minutos + " minuto" + (minutos > 1 ? "s" : "");

        long horas = ChronoUnit.HOURS.between(fechaCreacion, ahora);
        if (horas < 24)
            return "Hace " + horas + " hora" + (horas > 1 ? "s" : "");

        long dias = ChronoUnit.DAYS.between(fechaCreacion, ahora);
        if (dias < 30)
            return "Hace " + dias + " día" + (dias > 1 ? "s" : "");

        long meses = ChronoUnit.MONTHS.between(fechaCreacion, ahora);
        if (meses < 12)
            return "Hace " + meses + " mes" + (meses > 1 ? "es" : "");

        long años = ChronoUnit.YEARS.between(fechaCreacion, ahora);
        return "Hace " + años + " año" + (años > 1 ? "s" : "");
    }

    default String generarResumen(String contenido) {
        if (contenido == null || contenido.length() <= 150) {
            return contenido;
        }
        return contenido.substring(0, 147) + "...";
    }
}
