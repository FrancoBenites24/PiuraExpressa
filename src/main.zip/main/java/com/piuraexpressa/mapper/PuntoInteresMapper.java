package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.PuntoInteresDTO;
import com.piuraexpressa.model.PuntoInteres;
import org.mapstruct.Mapper;
import org.mapstruct.MappingTarget;

import java.util.List;

@Mapper(componentModel = "spring")
public interface PuntoInteresMapper {

    PuntoInteresDTO toDTO(PuntoInteres entity);

    PuntoInteres toEntity(PuntoInteresDTO dto);

    List<PuntoInteresDTO> toDTOList(List<PuntoInteres> entities);

    PuntoInteres updateEntityFromDTO(PuntoInteresDTO dto, @MappingTarget PuntoInteres entity);
}
