package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.ResenaDTO;
import com.piuraexpressa.model.Resena;
import org.mapstruct.*;

import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;

@Mapper(componentModel = "spring")
public interface ResenaMapper {

    @Mapping(target = "usuarioId", source = "usuario.id")
    @Mapping(target = "usuarioNombre", source = "usuario.nombres")
    @Mapping(target = "usuarioUsername", source = "usuario.username")
    @Mapping(target = "eventoId", source = "evento.id")
    @Mapping(target = "eventoTitulo", source = "evento.titulo")
    @Mapping(target = "calificacionEstrellas", expression = "java(generarEstrellas(resena.getCalificacion()))")
    @Mapping(target = "tiempoTranscurrido", expression = "java(calcularTiempoTranscurrido(resena.getFechaCreacion()))")
    @Mapping(target = "puedeEditar", expression = "java(false)") // Se calculará en el servicio
    @Mapping(target = "puedeEliminar", expression = "java(false)") // Se calculará en el servicio
    ResenaDTO toDTO(Resena resena);

    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "evento", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    Resena toEntity(ResenaDTO resenaDTO);

    List<ResenaDTO> toDTOList(List<Resena> resenas);

    @BeanMapping(nullValuePropertyMappingStrategy = NullValuePropertyMappingStrategy.IGNORE)
    @Mapping(target = "id", ignore = true)
    @Mapping(target = "usuario", ignore = true)
    @Mapping(target = "evento", ignore = true)
    @Mapping(target = "fechaCreacion", ignore = true)
    @Mapping(target = "fechaActualizacion", ignore = true)
    void updateEntityFromDTO(ResenaDTO resenaDTO, @MappingTarget Resena resena);

    default String generarEstrellas(Integer calificacion) {
        if (calificacion == null)
            return "☆☆☆☆☆";

        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 5; i++) {
            if (i <= calificacion) {
                sb.append("★");
            } else {
                sb.append("☆");
            }
        }
        return sb.toString();
    }

    default String calcularTiempoTranscurrido(LocalDateTime fechaCreacion) {
        if (fechaCreacion == null)
            return "";

        LocalDateTime ahora = LocalDateTime.now();
        long minutos = ChronoUnit.MINUTES.between(fechaCreacion, ahora);

        if (minutos < 1)
            return "Hace un momento";
        if (minutos < 60)
            return "Hace " + minutos + " minuto" + (minutos > 1 ? "s" : "");

        long horas = ChronoUnit.HOURS.between(fechaCreacion, ahora);
        if (horas < 24)
            return "Hace " + horas + " hora" + (horas > 1 ? "s" : "");

        long dias = ChronoUnit.DAYS.between(fechaCreacion, ahora);
        if (dias < 30)
            return "Hace " + dias + " día" + (dias > 1 ? "s" : "");

        return fechaCreacion.toLocalDate().toString();
    }
}
