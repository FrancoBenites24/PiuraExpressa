package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.RolDTO;
import com.piuraexpressa.model.Rol;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface RolMapper {
    RolDTO toDto(Rol rol);
    Rol toEntidad(RolDTO dto);
    List<RolDTO> toDtoLista(List<Rol> roles);
}
