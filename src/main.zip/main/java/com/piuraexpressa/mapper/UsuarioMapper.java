package com.piuraexpressa.mapper;

import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.model.Usuario;
import org.mapstruct.Mapper;

import java.util.List;

@Mapper(componentModel = "spring")
public interface UsuarioMapper {
    UsuarioDTO toDto(Usuario usuario);

    Usuario toEntidad(UsuarioDTO dto);

    List<UsuarioDTO> toDtoLista(List<Usuario> usuarios);
}