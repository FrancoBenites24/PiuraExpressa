package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "asistencias")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"usuario", "evento"})
@ToString(exclude = {"usuario", "evento"})
public class Asistencia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "evento_id", nullable = false)
    private Evento evento;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private EstadoAsistencia estado = EstadoAsistencia.CONFIRMADO;

    @Size(max = 500, message = "Las observaciones no pueden exceder 500 caracteres")
    @Column(columnDefinition = "TEXT")
    private String observaciones;

    @CreationTimestamp
    @Column(name = "fecha_registro", updatable = false)
    private LocalDateTime fechaRegistro;

    @UpdateTimestamp
    @Column(name = "fecha_actualizacion")
    private LocalDateTime fechaActualizacion;

    public enum EstadoAsistencia {
        PENDIENTE("Pendiente"),
        CONFIRMADO("Confirmado"),
        CANCELADO("Cancelado"),
        ASISTIO("Asistió"),
        NO_ASISTIO("No asistió");

        private final String descripcion;

        EstadoAsistencia(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }

    // Métodos de utilidad
    public boolean puedeModificar() {
        return estado == EstadoAsistencia.PENDIENTE || estado == EstadoAsistencia.CONFIRMADO;
    }

    public boolean eventoYaOcurrio() {
        return evento != null && evento.getFechaFin() != null && 
               evento.getFechaFin().isBefore(LocalDateTime.now());
    }
}
