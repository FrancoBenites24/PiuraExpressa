package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "clima_provincia")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ClimaProvincia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "provincia_id", nullable = false)
    private Provincia provincia;

    @Column(name = "temperatura_actual", precision = 4, scale = 1)
    private BigDecimal temperaturaActual;

    @Column(name = "temperatura_maxima", precision = 4, scale = 1)
    private BigDecimal temperaturaMaxima;

    @Column(name = "temperatura_minima", precision = 4, scale = 1)
    private BigDecimal temperaturaMinima;

    @Min(value = 0, message = "La humedad debe estar entre 0 y 100")
    @Max(value = 100, message = "La humedad debe estar entre 0 y 100")
    private Integer humedad;

    @Column(name = "presion_atmosferica", precision = 6, scale = 2)
    private BigDecimal presionAtmosferica;

    @DecimalMin(value = "0.0", message = "La velocidad del viento debe ser mayor o igual a 0")
    @Column(name = "velocidad_viento", precision = 4, scale = 1)
    private BigDecimal velocidadViento;

    @Size(max = 100, message = "La descripción del clima no puede exceder 100 caracteres")
    @Column(name = "descripcion_clima")
    private String descripcionClima;

    @Size(max = 20, message = "El icono del clima no puede exceder 20 caracteres")
    @Column(name = "icono_clima")
    private String iconoClima;

    @UpdateTimestamp
    @Column(name = "fecha_actualizacion")
    private LocalDateTime fechaActualizacion;

    // Métodos de utilidad
    public String getTemperaturaFormateada() {
        if (temperaturaActual == null)
            return "N/A";
        return temperaturaActual + "°C";
    }

    public String getRangoTemperatura() {
        if (temperaturaMinima == null || temperaturaMaxima == null)
            return "N/A";
        return temperaturaMinima + "°C - " + temperaturaMaxima + "°C";
    }
}
