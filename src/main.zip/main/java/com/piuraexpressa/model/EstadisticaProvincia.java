package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.Year;

@Entity
@Table(name = "estadisticas_provincia")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class EstadisticaProvincia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "provincia_id", nullable = false)
    private Provincia provincia;

    @Min(value = 0, message = "La población total debe ser mayor o igual a 0")
    @Column(name = "poblacion_total")
    private Integer poblacionTotal;

    @DecimalMin(value = "0.0", message = "La superficie debe ser mayor a 0")
    @Column(name = "superficie_km2", precision = 10, scale = 2)
    private BigDecimal superficieKm2;

    @DecimalMin(value = "0.0", message = "La densidad poblacional debe ser mayor o igual a 0")
    @Column(name = "densidad_poblacional", precision = 8, scale = 2)
    private BigDecimal densidadPoblacional;

    @Column(name = "altitud_promedio")
    private Integer altitudPromedio;

    @Column(name = "temperatura_promedio", precision = 4, scale = 2)
    private BigDecimal temperaturaPromedio;

    @DecimalMin(value = "0.0", message = "La precipitación anual debe ser mayor o igual a 0")
    @Column(name = "precipitacion_anual", precision = 6, scale = 2)
    private BigDecimal precipitacionAnual;

    @DecimalMin(value = "0.0", message = "El PIB per cápita debe ser mayor o igual a 0")
    @Column(name = "pib_per_capita", precision = 10, scale = 2)
    private BigDecimal pibPerCapita;

    @DecimalMin(value = "0.0", message = "La tasa de alfabetización debe estar entre 0 y 100")
    @DecimalMax(value = "100.0", message = "La tasa de alfabetización debe estar entre 0 y 100")
    @Column(name = "tasa_alfabetizacion", precision = 5, scale = 2)
    private BigDecimal tasaAlfabetizacion;

    @Min(value = 0, message = "Los establecimientos de salud deben ser mayor o igual a 0")
    @Column(name = "establecimientos_salud")
    private Integer establecimientosSalud;

    @Min(value = 0, message = "Los centros educativos deben ser mayor o igual a 0")
    @Column(name = "centros_educativos")
    private Integer centrosEducativos;

    @Min(value = 0, message = "Los hoteles registrados deben ser mayor o igual a 0")
    @Column(name = "hoteles_registrados")
    private Integer hotelesRegistrados;

    @Min(value = 0, message = "Los restaurantes registrados deben ser mayor o igual a 0")
    @Column(name = "restaurantes_registrados")
    private Integer restaurantesRegistrados;

    @Min(value = 0, message = "Los atractivos turísticos deben ser mayor o igual a 0")
    @Column(name = "atractivos_turisticos")
    private Integer atractivosTuristicos;

    @Min(value = 0, message = "Los festivales anuales deben ser mayor o igual a 0")
    @Column(name = "festivales_anuales")
    private Integer festivalesAnuales;

    @NotNull(message = "El año de actualización es obligatorio")
    @Column(name = "ano_actualizacion", nullable = false)
    private Year anoActualizacion;

    @UpdateTimestamp
    @Column(name = "fecha_actualizacion")
    private LocalDateTime fechaActualizacion;

    // Métodos de utilidad
    public String getPoblacionFormateada() {
        if (poblacionTotal == null)
            return "N/A";
        return String.format("%,d", poblacionTotal);
    }

    public String getSuperficieFormateada() {
        if (superficieKm2 == null)
            return "N/A";
        return String.format("%.2f km²", superficieKm2);
    }

    public String getDensidadFormateada() {
        if (densidadPoblacional == null)
            return "N/A";
        return String.format("%.2f hab/km²", densidadPoblacional);
    }
}
