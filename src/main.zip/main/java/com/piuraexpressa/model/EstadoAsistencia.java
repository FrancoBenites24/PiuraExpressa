package com.piuraexpressa.model;

public enum EstadoAsistencia {
    PENDIENTE,
    CONFIRMADO,
    CANCELADO,
    ASISTIO,
    NO_ASISTIO
}
