package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "eventos")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Evento {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "{evento.titulo.required}")
    @Size(min = 5, max = 100, message = "{evento.titulo.size}")
    private String titulo;

    @NotBlank(message = "{evento.descripcion.required}")
    @Size(min = 10, max = 1000, message = "{evento.descripcion.size}")
    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @NotNull(message = "{evento.fechaInicio.required}")
    @Future(message = "{evento.fechaInicio.future}")
    private LocalDateTime fechaInicio;

    @NotNull(message = "{evento.fechaFin.required}")
    private LocalDateTime fechaFin;

    @NotBlank(message = "{evento.ubicacion.required}")
    private String ubicacion;

    private String coordenadas;

    @Min(value = 1, message = "{evento.capacidad.min}")
    @Max(value = 10000, message = "{evento.capacidad.max}")
    private Integer capacidad;

    @DecimalMin(value = "0.0")
    private BigDecimal precio;

    private String imagen;

    @Column(nullable = false)
    @Builder.Default
    private boolean activo = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "provincia_id", nullable = false)
    private Provincia provincia;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @ManyToMany(mappedBy = "eventos")
    @Builder.Default
    private Set<Usuario> participantes = new HashSet<>();

    @OneToMany(mappedBy = "evento", cascade = CascadeType.ALL)
    @Builder.Default
    private Set<Asistencia> asistencias = new HashSet<>();

    @OneToMany(mappedBy = "evento", cascade = CascadeType.ALL)
    @Builder.Default
    private Set<Resena> resenas = new HashSet<>();

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime fechaCreacion;

    @UpdateTimestamp
    private LocalDateTime fechaActualizacion;

    @PrePersist
    protected void onCreate() {
        fechaCreacion = LocalDateTime.now();
        fechaActualizacion = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        fechaActualizacion = LocalDateTime.now();
    }

    @AssertTrue(message = "{evento.fechaFin.after}")
    private boolean isFechaFinAfterFechaInicio() {
        if (fechaInicio == null || fechaFin == null) {
            return true;
        }
        return fechaFin.isAfter(fechaInicio);
    }
}
