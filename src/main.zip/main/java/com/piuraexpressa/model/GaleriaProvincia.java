package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "galeria_provincia")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class GaleriaProvincia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "provincia_id", nullable = false)
    private Provincia provincia;

    @NotBlank(message = "El título es obligatorio")
    @Size(max = 100, message = "El título no puede exceder 100 caracteres")
    @Column(nullable = false)
    private String titulo;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @NotBlank(message = "La URL de la imagen es obligatoria")
    @Size(max = 255, message = "La URL de la imagen no puede exceder 255 caracteres")
    @Column(name = "url_imagen", nullable = false)
    private String urlImagen;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private CategoriaGaleria categoria;

    @Column(name = "es_portada", nullable = false)
    @Builder.Default
    private boolean esPortada = false;

    @Column(name = "orden_visualizacion")
    @Builder.Default
    private Integer ordenVisualizacion = 0;

    @Size(max = 100, message = "El nombre del fotógrafo no puede exceder 100 caracteres")
    private String fotografo;

    @Column(name = "fecha_toma")
    private LocalDate fechaToma;

    @Column(nullable = false)
    @Builder.Default
    private boolean activa = true;

    @CreationTimestamp
    @Column(name = "fecha_creacion", updatable = false)
    private LocalDateTime fechaCreacion;

    public enum CategoriaGaleria {
        PAISAJES("Paisajes"),
        GASTRONOMIA("Gastronomía"),
        CULTURA("Cultura"),
        ARQUITECTURA("Arquitectura"),
        EVENTOS("Eventos"),
        ARTESANIAS("Artesanías"),
        NATURALEZA("Naturaleza"),
        HISTORIA("Historia");

        private final String descripcion;

        CategoriaGaleria(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }
}
