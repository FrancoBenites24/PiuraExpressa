package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "imagenes")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Imagen {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre del archivo es obligatorio")
    @Size(max = 255, message = "El nombre del archivo no puede exceder 255 caracteres")
    @Column(name = "nombre_archivo", nullable = false)
    private String nombreArchivo;

    @NotBlank(message = "La URL es obligatoria")
    @Size(max = 255, message = "La URL no puede exceder 255 caracteres")
    @Column(nullable = false)
    private String url;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_referencia", nullable = false)
    private TipoReferencia tipoReferencia;

    @NotNull(message = "El ID de referencia es obligatorio")
    @Column(name = "referencia_id", nullable = false)
    private Long referenciaId;

    @Column(name = "tamaño_bytes")
    private Long tamañoBytes;

    @Size(max = 100, message = "El tipo MIME no puede exceder 100 caracteres")
    @Column(name = "tipo_mime")
    private String tipoMime;

    @CreationTimestamp
    @Column(name = "fecha_subida", updatable = false)
    private LocalDateTime fechaSubida;

    @Column(name = "entidad_tipo", length = 50, nullable = false)
    private String entidadTipo;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    public enum TipoReferencia {
        PERFIL("Perfil de usuario"),
        EVENTO("Evento"),
        PLATO("Plato típico"),
        RESENA("Reseña"),
        PUBLICACION("Publicación"),
        COMENTARIO("Comentario"),
        PROVINCIA("Provincia"),
        NOTICIA("Noticia"),
        POI("Punto de interés");

        private final String descripcion;

        TipoReferencia(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }

    // Métodos de utilidad
    public String getTamañoFormateado() {
        if (tamañoBytes == null)
            return "N/A";

        if (tamañoBytes < 1024)
            return tamañoBytes + " B";
        if (tamañoBytes < 1024 * 1024)
            return String.format("%.1f KB", tamañoBytes / 1024.0);
        if (tamañoBytes < 1024 * 1024 * 1024)
            return String.format("%.1f MB", tamañoBytes / (1024.0 * 1024.0));
        return String.format("%.1f GB", tamañoBytes / (1024.0 * 1024.0 * 1024.0));
    }

    public boolean esImagen() {
        return tipoMime != null && tipoMime.startsWith("image/");
    }
}
