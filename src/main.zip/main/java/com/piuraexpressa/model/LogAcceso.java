package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "log_acceso")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class LogAcceso {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @Size(max = 45, message = "La dirección IP no puede exceder 45 caracteres")
    @Column(name = "ip_address")
    private String ipAddress;

    @Column(name = "user_agent", columnDefinition = "TEXT")
    private String userAgent;

    @Enumerated(EnumType.STRING)
    @Column(name = "tipo_acceso", nullable = false)
    private TipoAcceso tipoAcceso;

    @Column(columnDefinition = "TEXT")
    private String detalles;

    @CreationTimestamp
    @Column(name = "fecha_acceso", updatable = false)
    private LocalDateTime fechaAcceso;

    public enum TipoAcceso {
        LOGIN_EXITOSO("Login exitoso"),
        LOGIN_FALLIDO("Login fallido"),
        LOGOUT("Logout"),
        CAMBIO_CONTRASENA("Cambio de contraseña"),
        ACCESO_DENEGADO("Acceso denegado");

        private final String descripcion;

        TipoAcceso(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }
}
