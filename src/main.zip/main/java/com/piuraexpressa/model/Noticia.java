package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "noticias")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Noticia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El título es obligatorio")
    @Size(min = 10, max = 200, message = "El título debe tener entre 10 y 200 caracteres")
    @Column(nullable = false)
    private String titulo;

    @Size(max = 300, message = "El subtítulo no puede exceder 300 caracteres")
    private String subtitulo;

    @NotBlank(message = "El contenido es obligatorio")
    @Size(min = 50, message = "El contenido debe tener al menos 50 caracteres")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String contenido;

    @Size(max = 500, message = "El resumen no puede exceder 500 caracteres")
    private String resumen;

    @Column(name = "imagen_url")
    private String imagenUrl;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "autor_id", nullable = false)
    private Usuario autor;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private CategoriaNoticia categoria = CategoriaNoticia.GENERAL;

    @Column(nullable = false)
    @Builder.Default
    private boolean destacada = false;

    @Column(nullable = false)
    @Builder.Default
    private boolean activa = true;

    @CreationTimestamp
    @Column(name = "fecha_publicacion", updatable = false)
    private LocalDateTime fechaPublicacion;

    @UpdateTimestamp
    @Column(name = "fecha_actualizacion")
    private LocalDateTime fechaActualizacion;

    @Column(unique = true)
    private String slug;

    @Size(max = 160, message = "La meta descripción no puede exceder 160 caracteres")
    @Column(name = "meta_descripcion")
    private String metaDescripcion;

    @Size(max = 500, message = "Los tags no pueden exceder 500 caracteres")
    private String tags;

    @Column(nullable = false)
    @Builder.Default
    private int vistas = 0;

    public enum CategoriaNoticia {
        CULTURA("Cultura"),
        GASTRONOMIA("Gastronomía"),
        TURISMO("Turismo"),
        EVENTOS("Eventos"),
        GENERAL("General");

        private final String descripcion;

        CategoriaNoticia(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }

    @PrePersist
    protected void onCreate() {
        if (slug == null || slug.isEmpty()) {
            slug = generateSlug(titulo);
        }
        fechaPublicacion = LocalDateTime.now();
        fechaActualizacion = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        fechaActualizacion = LocalDateTime.now();
    }

    private String generateSlug(String titulo) {
        return titulo.toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .replaceAll("\\s+", "-")
                .replaceAll("-+", "-")
                .replaceAll("^-|-$", "");
    }

    // Métodos de utilidad
    public String getResumenCorto() {
        if (resumen != null && resumen.length() > 150) {
            return resumen.substring(0, 147) + "...";
        }
        return resumen;
    }

    public String[] getTagsArray() {
        if (tags == null || tags.isEmpty()) {
            return new String[0];
        }
        return tags.split(",");
    }
}
