package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "platos")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Plato {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "{plato.nombre.required}")
    @Size(min = 2, max = 100, message = "{plato.nombre.size}")
    private String nombre;

    @NotBlank(message = "{plato.descripcion.required}")
    @Size(min = 10, max = 500, message = "{plato.descripcion.size}")
    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @NotNull(message = "{plato.precio.required}")
    @DecimalMin(value = "0.0", message = "{plato.precio.min}")
    @DecimalMax(value = "1000.0", message = "{plato.precio.max}")
    private BigDecimal precio;

    private String imagen;

    @Column(nullable = false)
    @Builder.Default
    private boolean activo = true;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "provincia_id", nullable = false)
    private Provincia provincia;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime fechaCreacion;

    @UpdateTimestamp
    private LocalDateTime fechaActualizacion;

    @PrePersist
    protected void onCreate() {
        fechaCreacion = LocalDateTime.now();
        fechaActualizacion = LocalDateTime.now();
    }

    @PreUpdate
    protected void onUpdate() {
        fechaActualizacion = LocalDateTime.now();
    }
}
