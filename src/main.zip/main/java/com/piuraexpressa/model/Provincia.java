package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "provincias")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"eventos", "platos", "puntosInteres", "galeria", "historia", "estadisticas", "clima"})
@ToString(exclude = {"eventos", "platos", "puntosInteres", "galeria", "historia", "estadisticas", "clima"})
public class Provincia {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 50, message = "El nombre no puede exceder 50 caracteres")
    @Column(nullable = false, unique = true)
    private String nombre;

    @Size(max = 255, message = "El subtítulo no puede exceder 255 caracteres")
    private String subtitulo;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @Column(name = "imagen_principal")
    private String imagenPrincipal;

    @DecimalMin(value = "-90.0", message = "La latitud debe estar entre -90 y 90")
    @DecimalMax(value = "90.0", message = "La latitud debe estar entre -90 y 90")
    @Column(precision = 10, scale = 8)
    private BigDecimal latitud;

    @DecimalMin(value = "-180.0", message = "La longitud debe estar entre -180 y 180")
    @DecimalMax(value = "180.0", message = "La longitud debe estar entre -180 y 180")
    @Column(precision = 11, scale = 8)
    private BigDecimal longitud;

    @Column(name = "altitud_promedio")
    private Integer altitudPromedio;

    @Size(max = 200, message = "La descripción del clima no puede exceder 200 caracteres")
    @Column(name = "clima_descripcion")
    private String climaDescripcion;

    @Size(max = 100, message = "La mejor época de visita no puede exceder 100 caracteres")
    @Column(name = "mejor_epoca_visita")
    private String mejorEpocaVisita;

    @Column(nullable = false)
    @Builder.Default
    private boolean activa = true;

    @CreationTimestamp
    @Column(name = "fecha_creacion", updatable = false)
    private LocalDateTime fechaCreacion;

    @UpdateTimestamp
    @Column(name = "fecha_actualizacion")
    private LocalDateTime fechaActualizacion;

    // Relaciones
    @OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private Set<Evento> eventos = new HashSet<>();

    @OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private Set<Plato> platos = new HashSet<>();

    @OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private Set<PuntoInteres> puntosInteres = new HashSet<>();

    @OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private Set<GaleriaProvincia> galeria = new HashSet<>();

    @OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @OrderBy("orden_cronologico ASC")
    @Builder.Default
    private Set<HistoriaProvincia> historia = new HashSet<>();

    @OneToMany(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private Set<EstadisticaProvincia> estadisticas = new HashSet<>();

    @OneToOne(mappedBy = "provincia", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private ClimaProvincia clima;

    // Métodos de utilidad
    public EstadisticaProvincia getEstadisticaActual() {
        return estadisticas.stream()
                .max((e1, e2) -> e1.getAnoActualizacion().compareTo(e2.getAnoActualizacion()))
                .orElse(null);
    }

    public Set<GaleriaProvincia> getImagenesPortada() {
        return galeria.stream()
                .filter(GaleriaProvincia::isEsPortada)
                .collect(java.util.stream.Collectors.toSet());
    }
}
