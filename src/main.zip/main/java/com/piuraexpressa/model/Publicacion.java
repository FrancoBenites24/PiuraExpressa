package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "publicaciones")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = { "usuario", "comentarios" })
@ToString(exclude = { "usuario", "comentarios" })
public class Publicacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "usuario_id", nullable = false)
    private Usuario usuario;

    @NotBlank(message = "El título es obligatorio")
    @Size(min = 5, max = 200, message = "El título debe tener entre 5 y 200 caracteres")
    @Column(nullable = false)
    private String titulo;

    @NotBlank(message = "El contenido es obligatorio")
    @Size(min = 10, message = "El contenido debe tener al menos 10 caracteres")
    @Column(columnDefinition = "TEXT", nullable = false)
    private String contenido;

    private String imagen;

    @Builder.Default
    @Column(nullable = false)
    private boolean activa = true;

    @CreationTimestamp
    @Column(name = "fecha_creacion", updatable = false)
    private LocalDateTime fechaCreacion;

    @UpdateTimestamp
    @Column(name = "fecha_actualizacion")
    private LocalDateTime fechaActualizacion;

    // Relaciones
    @OneToMany(mappedBy = "publicacion", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    @Builder.Default
    private Set<Comentario> comentarios = new HashSet<>();

    // Métodos de utilidad
    public String getContenidoResumen() {
        if (contenido == null || contenido.length() <= 150) {
            return contenido;
        }
        return contenido.substring(0, 147) + "...";
    }

    public int getTotalComentarios() {
        return comentarios != null ? comentarios.size() : 0;
    }

    // CONSTRUCTOR SOLO PARA ID
    public Publicacion(Long id) {
        this.id = id;
    }
}
