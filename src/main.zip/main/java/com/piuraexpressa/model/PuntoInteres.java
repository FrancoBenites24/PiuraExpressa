package com.piuraexpressa.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "puntos_interes")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class PuntoInteres {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "provincia_id", nullable = false)
    private Provincia provincia;

    @NotBlank(message = "El nombre es obligatorio")
    @Size(max = 100, message = "El nombre no puede exceder 100 caracteres")
    @Column(nullable = false)
    private String nombre;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TipoPuntoInteres tipo;

    @NotNull(message = "La latitud es obligatoria")
    @DecimalMin(value = "-90.0", message = "La latitud debe estar entre -90 y 90")
    @DecimalMax(value = "90.0", message = "La latitud debe estar entre -90 y 90")
    @Column(nullable = false, precision = 10, scale = 8)
    private BigDecimal latitud;

    @NotNull(message = "La longitud es obligatoria")
    @DecimalMin(value = "-180.0", message = "La longitud debe estar entre -180 y 180")
    @DecimalMax(value = "180.0", message = "La longitud debe estar entre -180 y 180")
    @Column(nullable = false, precision = 11, scale = 8)
    private BigDecimal longitud;

    @Size(max = 200, message = "La dirección no puede exceder 200 caracteres")
    private String direccion;

    @Size(max = 15, message = "El teléfono no puede exceder 15 caracteres")
    private String telefono;

    @Email(message = "El email debe tener un formato válido")
    @Size(max = 100, message = "El email no puede exceder 100 caracteres")
    private String email;

    @Size(max = 255, message = "El sitio web no puede exceder 255 caracteres")
    @Column(name = "sitio_web")
    private String sitioWeb;

    @Size(max = 100, message = "El horario de atención no puede exceder 100 caracteres")
    @Column(name = "horario_atencion")
    private String horarioAtencion;

    @DecimalMin(value = "0.0", message = "El precio promedio debe ser mayor o igual a 0")
    @Column(name = "precio_promedio", precision = 8, scale = 2)
    private BigDecimal precioPromedio;

    @DecimalMin(value = "0.0", message = "La calificación debe estar entre 0 y 5")
    @DecimalMax(value = "5.0", message = "La calificación debe estar entre 0 y 5")
    @Column(precision = 2, scale = 1)
    @Builder.Default
    private BigDecimal calificacion = BigDecimal.ZERO;

    @Min(value = 0, message = "El número de reseñas debe ser mayor o igual a 0")
    @Column(name = "numero_resenas")
    @Builder.Default
    private Integer numeroResenas = 0;

    @Column(name = "imagen_url")
    private String imagenUrl;

    @Column(nullable = false)
    @Builder.Default
    private boolean activo = true;

    @CreationTimestamp
    @Column(name = "fecha_creacion", updatable = false)
    private LocalDateTime fechaCreacion;

    public enum TipoPuntoInteres {
        RESTAURANTE("Restaurante"),
        HOTEL("Hotel"),
        ATRACTIVO_TURISTICO("Atractivo Turístico"),
        MUSEO("Museo"),
        IGLESIA("Iglesia"),
        PLAZA("Plaza"),
        HOSPITAL("Hospital"),
        BANCO("Banco"),
        CENTRO_COMERCIAL("Centro Comercial"),
        PARQUE("Parque");

        private final String descripcion;

        TipoPuntoInteres(String descripcion) {
            this.descripcion = descripcion;
        }

        public String getDescripcion() {
            return descripcion;
        }
    }

    // Métodos de utilidad
    public String getCalificacionEstrellas() {
        if (calificacion == null)
            return "☆☆☆☆☆";

        int estrellas = calificacion.intValue();
        StringBuilder sb = new StringBuilder();
        for (int i = 1; i <= 5; i++) {
            if (i <= estrellas) {
                sb.append("★");
            } else {
                sb.append("☆");
            }
        }
        return sb.toString();
    }

    public String getTipoIcono() {
        return switch (tipo) {
            case RESTAURANTE -> "🍽️";
            case HOTEL -> "🏨";
            case ATRACTIVO_TURISTICO -> "📸";
            case MUSEO -> "🏛️";
            case IGLESIA -> "⛪";
            case PLAZA -> "🏛️";
            case HOSPITAL -> "🏥";
            case BANCO -> "🏦";
            case CENTRO_COMERCIAL -> "🏬";
            case PARQUE -> "🌳";
        };
    }
}
