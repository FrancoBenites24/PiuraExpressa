package com.piuraexpressa.model;

public enum TipoDocumento {
    DNI,
    CARNET_EXTRANJERIA,
    PASAPORTE
}
