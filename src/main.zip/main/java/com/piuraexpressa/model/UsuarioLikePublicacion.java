
package com.piuraexpressa.model;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

import com.piuraexpressa.model.Usuario;

@Entity
@Table(name = "usuario_like_publicacion")
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(exclude = {"usuario", "publicacion"})
@ToString(exclude = {"usuario", "publicacion"})
public class UsuarioLikePublicacion {

    @EmbeddedId
    private UsuarioLikePublicacionId id;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("usuarioId")
    @JoinColumn(name = "usuario_id")
    private Usuario usuario;

    @ManyToOne(fetch = FetchType.LAZY)
    @MapsId("publicacionId")
    @JoinColumn(name = "publicacion_id")
    private Publicacion publicacion;

    @Column(name = "tipo_reaccion")
    private String tipoReaccion;

    @CreationTimestamp
    @Column(name = "fecha_like", updatable = false)
    private LocalDateTime fechaLike;

    @Embeddable
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class UsuarioLikePublicacionId implements java.io.Serializable {
        private Long usuarioId;
        private Long publicacionId;
    }
}
