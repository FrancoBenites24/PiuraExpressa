package com.piuraexpressa.model;

import jakarta.persistence.Embeddable;
import lombok.*;

@Embeddable
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class UsuarioRolId implements java.io.Serializable {
    private Long usuarioId;
    private Long rolId;
}
