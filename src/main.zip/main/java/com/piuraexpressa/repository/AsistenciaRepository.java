package com.piuraexpressa.repository;

import com.piuraexpressa.model.Asistencia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface AsistenciaRepository extends JpaRepository<Asistencia, Long> {

       // Búsquedas por evento
       List<Asistencia> findByEventoIdOrderByFechaRegistroDesc(Long eventoId);

       Page<Asistencia> findByEventoIdOrderByFechaRegistroDesc(Long eventoId, Pageable pageable);

       List<Asistencia> findByEventoIdAndEstadoOrderByFechaRegistroDesc(Long eventoId,
                     Asistencia.EstadoAsistencia estado);

       // Búsquedas por usuario
       List<Asistencia> findByUsuarioIdOrderByFechaRegistroDesc(Long usuarioId);

       Page<Asistencia> findByUsuarioIdOrderByFechaRegistroDesc(Long usuarioId, Pageable pageable);

       List<Asistencia> findByUsuarioIdAndEstadoOrderByFechaRegistroDesc(Long usuarioId,
                     Asistencia.EstadoAsistencia estado);

       // Búsqueda específica usuario-evento
       Optional<Asistencia> findByUsuarioIdAndEventoId(Long usuarioId, Long eventoId);

       // Asistencias confirmadas
       @Query("SELECT a FROM Asistencia a WHERE a.estado IN ('CONFIRMADO', 'ASISTIO') " +
                     "ORDER BY a.fechaRegistro DESC")
       List<Asistencia> findConfirmedAttendances(Pageable pageable);

       // Asistencias por estado
       List<Asistencia> findByEstadoOrderByFechaRegistroDesc(Asistencia.EstadoAsistencia estado);

       // Contadores
       long countByEventoId(Long eventoId);

       long countByEventoIdAndEstado(Long eventoId, Asistencia.EstadoAsistencia estado);

       long countByUsuarioId(Long usuarioId);

       long countByUsuarioIdAndEstado(Long usuarioId, Asistencia.EstadoAsistencia estado);

       // Verificar si usuario ya se registró al evento
       boolean existsByUsuarioIdAndEventoId(Long usuarioId, Long eventoId);

       // Estadísticas de asistencia
       @Query("SELECT COUNT(a) FROM Asistencia a WHERE a.evento.id = :eventoId AND a.estado = 'ASISTIO'")
       long countActualAttendancesByEvento(@Param("eventoId") Long eventoId);

       @Query("SELECT COUNT(a) FROM Asistencia a WHERE a.evento.id = :eventoId AND a.estado = 'NO_ASISTIO'")
       long countNoShowsByEvento(@Param("eventoId") Long eventoId);
}
