package com.piuraexpressa.repository;

import com.piuraexpressa.model.ClimaProvincia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ClimaProvinciaRepository extends JpaRepository<ClimaProvincia, Long> {

    // Buscar por provincia
    Optional<ClimaProvincia> findByProvinciaId(Long provinciaId);

    // Buscar climas actualizados recientemente
    @Query("SELECT c FROM ClimaProvincia c WHERE c.fechaActualizacion >= :fechaLimite")
    List<ClimaProvincia> findRecentlyUpdated(@Param("fechaLimite") LocalDateTime fechaLimite);

    // Buscar climas que necesitan actualización
    @Query("SELECT c FROM ClimaProvincia c WHERE c.fechaActualizacion < :fechaLimite")
    List<ClimaProvincia> findNeedingUpdate(@Param("fechaLimite") LocalDateTime fechaLimite);

    // Actualizar temperatura
    @Modifying
    @Query("UPDATE ClimaProvincia c SET c.temperaturaActual = :temperatura, " +
           "c.fechaActualizacion = CURRENT_TIMESTAMP WHERE c.provincia.id = :provinciaId")
    int updateTemperatura(@Param("provinciaId") Long provinciaId, 
                         @Param("temperatura") BigDecimal temperatura);

    // Buscar por rango de temperatura
    @Query("SELECT c FROM ClimaProvincia c WHERE c.temperaturaActual BETWEEN :tempMin AND :tempMax")
    List<ClimaProvincia> findByTemperaturaRange(@Param("tempMin") BigDecimal tempMin, 
                                               @Param("tempMax") BigDecimal tempMax);

    // Estadísticas climáticas
    @Query("SELECT AVG(c.temperaturaActual) FROM ClimaProvincia c")
    Double getTemperaturaPromedio();

    @Query("SELECT MAX(c.temperaturaActual) FROM ClimaProvincia c")
    BigDecimal getTemperaturaMaxima();

    @Query("SELECT MIN(c.temperaturaActual) FROM ClimaProvincia c")
    BigDecimal getTemperaturaMinima();
}
