package com.piuraexpressa.repository;

import com.piuraexpressa.model.EstadisticaProvincia;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Year;
import java.util.List;
import java.util.Optional;

@Repository
public interface EstadisticaProvinciaRepository extends JpaRepository<EstadisticaProvincia, Long> {

       // Buscar por provincia
       List<EstadisticaProvincia> findByProvinciaIdOrderByAnoActualizacionDesc(Long provinciaId);

       // Buscar por provincia paginada
       Page<EstadisticaProvincia> findByProvinciaIdOrderByAnoActualizacionDesc(Long provinciaId, Pageable pageable);

       // Buscar la más reciente por provincia
       Optional<EstadisticaProvincia> findFirstByProvinciaIdOrderByAnoActualizacionDesc(Long provinciaId);

       // Buscar por año
       List<EstadisticaProvincia> findByAnoActualizacionOrderByProvinciaIdAsc(Year ano);

       // Buscar por provincia y año
       Optional<EstadisticaProvincia> findByProvinciaIdAndAnoActualizacion(Long provinciaId, Year ano);

       // Verificar existencia
       boolean existsByProvinciaIdAndAnoActualizacion(Long provinciaId, Year ano);

       // Estadísticas comparativas
       @Query("SELECT e FROM EstadisticaProvincia e WHERE e.anoActualizacion = :ano " +
                     "ORDER BY e.poblacionTotal DESC")
       List<EstadisticaProvincia> findByAnoOrderByPoblacion(@Param("ano") Year ano);

       @Query("SELECT e FROM EstadisticaProvincia e WHERE e.anoActualizacion = :ano " +
                     "ORDER BY e.pibPerCapita DESC")
       List<EstadisticaProvincia> findByAnoOrderByPib(@Param("ano") Year ano);

       // Promedio regional
       @Query("SELECT AVG(e.poblacionTotal) FROM EstadisticaProvincia e WHERE e.anoActualizacion = :ano")
       Double getPromedioPoblacion(@Param("ano") Year ano);

       @Query("SELECT AVG(e.pibPerCapita) FROM EstadisticaProvincia e WHERE e.anoActualizacion = :ano")
       Double getPromedioPib(@Param("ano") Year ano);
}
