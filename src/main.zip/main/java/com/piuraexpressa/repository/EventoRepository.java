package com.piuraexpressa.repository;

import com.piuraexpressa.model.Evento;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface EventoRepository extends JpaRepository<Evento, Long> {

       // ✅ Agregar métodos faltantes
       List<Evento> findByActivoTrueOrderByFechaInicioAsc();

       List<Evento> findByUsuarioId(Long usuarioId);

       Page<Evento> findByUsuarioId(Long usuarioId, Pageable pageable);

       // Búsquedas por provincia
       List<Evento> findByProvinciaIdOrderByFechaInicioAsc(Long provinciaId);

       Page<Evento> findByProvinciaIdOrderByFechaInicioAsc(Long provinciaId, Pageable pageable);

       List<Evento> findByProvinciaIdAndActivoTrueOrderByFechaInicioAsc(Long provinciaId);

       // Búsquedas por fecha
       List<Evento> findByFechaInicioBetweenAndActivoTrueOrderByFechaInicioAsc(LocalDateTime fechaInicio,
                     LocalDateTime fechaFin);

       List<Evento> findByProvinciaIdAndFechaInicioBetween(Long provinciaId, LocalDateTime fechaInicio,
                     LocalDateTime fechaFin);

       // Eventos próximos
       @Query("SELECT e FROM Evento e WHERE e.activo = true AND e.fechaInicio > :fechaActual " +
                     "ORDER BY e.fechaInicio ASC")
       List<Evento> findProximosEventos(@Param("fechaActual") LocalDateTime fechaActual, Pageable pageable);

       // Eventos destacados
       @Query("SELECT e FROM Evento e WHERE e.activo = true AND " +
                     "(e.precio IS NULL OR e.precio = 0 OR e.capacidad > 100) " +
                     "ORDER BY e.fechaInicio ASC")
       List<Evento> findDestacados();

       // Eventos gratuitos
       @Query("SELECT e FROM Evento e WHERE e.activo = true AND " +
                     "(e.precio IS NULL OR e.precio = 0) " +
                     "ORDER BY e.fechaInicio ASC")
       List<Evento> findGratuitos();

       // Búsqueda por texto
       @Query("SELECT e FROM Evento e WHERE e.activo = true AND " +
                     "(LOWER(e.titulo) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
                     "LOWER(e.descripcion) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
                     "LOWER(e.ubicacion) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
                     "ORDER BY e.fechaInicio ASC")
       Page<Evento> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);

       // Contadores
       long countByProvinciaId(Long provinciaId);

       long countByProvinciaIdAndActivoTrue(Long provinciaId);

       @Query("SELECT COUNT(e) FROM Evento e WHERE e.activo = true AND e.fechaInicio > :fechaActual")
       long countProximosEventos(@Param("fechaActual") LocalDateTime fechaActual);

       // Contar asistencias confirmadas
       @Query("SELECT COUNT(a) FROM Asistencia a WHERE a.evento.id = :eventoId AND " +
                     "a.estado IN ('CONFIRMADO', 'ASISTIO')")
       long countAsistenciasConfirmadas(@Param("eventoId") Long eventoId);
}
