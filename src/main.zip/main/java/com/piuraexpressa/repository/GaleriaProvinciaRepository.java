package com.piuraexpressa.repository;

import com.piuraexpressa.model.GaleriaProvincia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface GaleriaProvinciaRepository extends JpaRepository<GaleriaProvincia, Long> {

    // Buscar por provincia
    List<GaleriaProvincia> findByProvinciaIdAndActivaTrueOrderByOrdenVisualizacionAsc(Long provinciaId);
    Page<GaleriaProvincia> findByProvinciaIdAndActivaTrueOrderByOrdenVisualizacionAsc(Long provinciaId, Pageable pageable);

    // Buscar por categoría
    List<GaleriaProvincia> findByProvinciaIdAndCategoriaAndActivaTrueOrderByOrdenVisualizacionAsc(
            Long provinciaId, GaleriaProvincia.CategoriaGaleria categoria);

    // Buscar imágenes de portada
    List<GaleriaProvincia> findByProvinciaIdAndEsPortadaTrueAndActivaTrueOrderByOrdenVisualizacionAsc(Long provinciaId);

    // Buscar todas las portadas
    List<GaleriaProvincia> findByEsPortadaTrueAndActivaTrueOrderByProvinciaIdAsc();

    // Contar por provincia y categoría
    long countByProvinciaIdAndCategoriaAndActivaTrue(Long provinciaId, GaleriaProvincia.CategoriaGaleria categoria);

    // Buscar imágenes recientes
    @Query("SELECT g FROM GaleriaProvincia g WHERE g.provincia.id = :provinciaId " +
           "AND g.activa = true ORDER BY g.fechaCreacion DESC")
    List<GaleriaProvincia> findRecentByProvincia(@Param("provinciaId") Long provinciaId, Pageable pageable);

    // Verificar si ya existe una portada para la provincia
    boolean existsByProvinciaIdAndEsPortadaTrueAndActivaTrue(Long provinciaId);
}
