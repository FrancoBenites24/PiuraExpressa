package com.piuraexpressa.repository;

import com.piuraexpressa.model.HistoriaProvincia;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Year;
import java.util.List;

@Repository
public interface HistoriaProvinciaRepository extends JpaRepository<HistoriaProvincia, Long> {

    // Buscar por provincia ordenado cronológicamente
    List<HistoriaProvincia> findByProvinciaIdAndActivoTrueOrderByOrdenCronologicoAsc(Long provinciaId);
    List<HistoriaProvincia> findByProvinciaIdAndActivoTrueOrderByAnoAsc(Long provinciaId);

    // Buscar por rango de años
    @Query("SELECT h FROM HistoriaProvincia h WHERE h.provincia.id = :provinciaId " +
           "AND h.activo = true AND h.ano BETWEEN :anoInicio AND :anoFin " +
           "ORDER BY h.ano ASC")
    List<HistoriaProvincia> findByProvinciaAndAnoRange(
            @Param("provinciaId") Long provinciaId,
            @Param("anoInicio") Year anoInicio,
            @Param("anoFin") Year anoFin);

    // Buscar eventos históricos más antiguos
    @Query("SELECT h FROM HistoriaProvincia h WHERE h.provincia.id = :provinciaId " +
           "AND h.activo = true ORDER BY h.ano ASC")
    List<HistoriaProvincia> findOldestByProvincia(@Param("provinciaId") Long provinciaId, 
                                                  org.springframework.data.domain.Pageable pageable);

    // Buscar eventos históricos más recientes
    @Query("SELECT h FROM HistoriaProvincia h WHERE h.provincia.id = :provinciaId " +
           "AND h.activo = true ORDER BY h.ano DESC")
    List<HistoriaProvincia> findNewestByProvincia(@Param("provinciaId") Long provinciaId, 
                                                  org.springframework.data.domain.Pageable pageable);

    // Contar eventos por provincia
    long countByProvinciaIdAndActivoTrue(Long provinciaId);

    // Verificar si existe evento en año específico
    boolean existsByProvinciaIdAndAnoAndActivoTrue(Long provinciaId, Year ano);
}
