package com.piuraexpressa.repository;

import com.piuraexpressa.model.Imagen;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface ImagenRepository extends JpaRepository<Imagen, Long> {

    // Paginación por referencia
    Page<Imagen> findByReferenciaId(Long referenciaId, Pageable pageable);

    // Paginación por tipo de entidad
    Page<Imagen> findByEntidadTipo(String entidadTipo, Pageable pageable);

    // Listado por tipo de entidad + referencia
    List<Imagen> findByEntidadTipoAndReferenciaId(String entidadTipo, Long referenciaId);

    // Búsqueda por nombre de archivo
    Page<Imagen> findBynombreArchivoContainingIgnoreCase(String nombreArchivo, Pageable pageable);

    // Búsqueda por tipo MIME
    Page<Imagen> findByTipoMime(String tipoMime, Pageable pageable);

    // Rango de fechas
    @Query("SELECT i FROM Imagen i WHERE i.fechaSubida BETWEEN :startDate AND :endDate ORDER BY i.fechaSubida DESC")
    Page<Imagen> findByDateRange(
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate,
            Pageable pageable);

    // Rango de tamaños
    @Query("SELECT i FROM Imagen i WHERE i.tamañoBytes BETWEEN :minSize AND :maxSize")
    Page<Imagen> findBySizeRange(
            @Param("minSize") Long minSize,
            @Param("maxSize") Long maxSize,
            Pageable pageable);

    // Imágenes más recientes
    Page<Imagen> findAllByOrderByFechaSubidaDesc(Pageable pageable);

    // Imágenes por referencia (usuario o entidad) y tipo
    @Query("SELECT i FROM Imagen i WHERE i.referenciaId = :referenciaId AND i.entidadTipo = :entidadTipo ORDER BY i.fechaSubida DESC")
    List<Imagen> findByReferenciaIdAndEntidadTipo(
            @Param("referenciaId") Long referenciaId,
            @Param("entidadTipo") String entidadTipo);

    // Contadores
    long countByReferenciaId(Long referenciaId);

    long countByEntidadTipo(String entidadTipo);

    // Tamaño total por usuario (por relación ManyToOne)
    @Query("SELECT SUM(i.tamañoBytes) FROM Imagen i WHERE i.usuario.id = :usuarioId")
    Long getTotalSizeByUsuario(@Param("usuarioId") Long usuarioId);

    @Query("SELECT i FROM Imagen i WHERE i.referenciaId = :usuarioId AND i.tipoReferencia = 'PERFIL' ORDER BY i.fechaSubida DESC")
    List<Imagen> findPerfilByUsuarioId(@Param("usuarioId") Long usuarioId);

    Optional<Imagen> findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(Long referenciaId,
            Imagen.TipoReferencia tipoReferencia);

    // Estadísticas por tipo MIME
    @Query("SELECT i.tipoMime, COUNT(i), SUM(i.tamañoBytes) FROM Imagen i GROUP BY i.tipoMime ORDER BY COUNT(i) DESC")
    List<Object[]> getUsageStatsByContentType();

    // Imágenes sin relación clara
    @Query("SELECT i FROM Imagen i WHERE i.entidadTipo IS NULL OR i.referenciaId IS NULL")
    List<Imagen> findOrphanedImages();

    // Eliminar imágenes antiguas
    @Query("DELETE FROM Imagen i WHERE i.fechaSubida < :cutoffDate")
    void deleteOldImages(@Param("cutoffDate") LocalDateTime cutoffDate);
}
