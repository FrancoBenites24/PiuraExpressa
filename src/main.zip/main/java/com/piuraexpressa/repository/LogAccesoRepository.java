package com.piuraexpressa.repository;

import com.piuraexpressa.model.LogAcceso;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface LogAccesoRepository extends JpaRepository<LogAcceso, Long> {

    Page<LogAcceso> findByUsuarioId(Long usuarioId, Pageable pageable);
    
    Page<LogAcceso> findByTipoAcceso(LogAcceso.TipoAcceso tipoAcceso, Pageable pageable);
    
    Page<LogAcceso> findByUsuarioIdAndTipoAcceso(Long usuarioId, LogAcceso.TipoAcceso tipoAcceso, Pageable pageable);

    // Logs por rango de fechas
    @Query("SELECT l FROM LogAcceso l WHERE " +
           "l.fechaAcceso BETWEEN :startDate AND :endDate " +
           "ORDER BY l.fechaAcceso DESC")
    Page<LogAcceso> findByDateRange(
            @Param("startDate") LocalDateTime startDate,
            @Param("endDate") LocalDateTime endDate,
            Pageable pageable);

    // Logs por IP
    Page<LogAcceso> findByIpAddress(String ipAddress, Pageable pageable);

    // Últimos accesos de un usuario
    @Query("SELECT l FROM LogAcceso l WHERE l.usuario.id = :usuarioId " +
           "ORDER BY l.fechaAcceso DESC")
    List<LogAcceso> findLatestByUsuario(@Param("usuarioId") Long usuarioId, Pageable pageable);

    // Intentos de login fallidos por usuario
    @Query("SELECT l FROM LogAcceso l WHERE l.usuario.id = :usuarioId " +
           "AND l.tipoAcceso = 'LOGIN_FALLIDO' " +
           "AND l.fechaAcceso > :since " +
           "ORDER BY l.fechaAcceso DESC")
    List<LogAcceso> findFailedLoginAttempts(@Param("usuarioId") Long usuarioId, 
                                          @Param("since") LocalDateTime since);

    // Contar intentos fallidos por usuario en un período
    @Query("SELECT COUNT(l) FROM LogAcceso l WHERE l.usuario.id = :usuarioId " +
           "AND l.tipoAcceso = 'LOGIN_FALLIDO' " +
           "AND l.fechaAcceso > :since")
    long countFailedLoginAttempts(@Param("usuarioId") Long usuarioId, 
                                 @Param("since") LocalDateTime since);

    // Estadísticas de acceso por tipo
    @Query("SELECT l.tipoAcceso, COUNT(l) FROM LogAcceso l " +
           "WHERE l.fechaAcceso BETWEEN :startDate AND :endDate " +
           "GROUP BY l.tipoAcceso")
    List<Object[]> findAccessStatsByType(@Param("startDate") LocalDateTime startDate,
                                        @Param("endDate") LocalDateTime endDate);

    // IPs más activas
    @Query("SELECT l.ipAddress, COUNT(l) as accessCount FROM LogAcceso l " +
           "WHERE l.fechaAcceso BETWEEN :startDate AND :endDate " +
           "GROUP BY l.ipAddress " +
           "ORDER BY accessCount DESC")
    List<Object[]> findMostActiveIPs(@Param("startDate") LocalDateTime startDate,
                                    @Param("endDate") LocalDateTime endDate,
                                    Pageable pageable);

    // Usuarios más activos
    @Query("SELECT l.usuario, COUNT(l) as accessCount FROM LogAcceso l " +
           "WHERE l.fechaAcceso BETWEEN :startDate AND :endDate " +
           "AND l.tipoAcceso = 'LOGIN_EXITOSO' " +
           "GROUP BY l.usuario " +
           "ORDER BY accessCount DESC")
    List<Object[]> findMostActiveUsers(@Param("startDate") LocalDateTime startDate,
                                      @Param("endDate") LocalDateTime endDate,
                                      Pageable pageable);

    // Accesos sospechosos (múltiples IPs para un usuario)
    @Query("SELECT l.usuario, COUNT(DISTINCT l.ipAddress) as ipCount FROM LogAcceso l " +
           "WHERE l.fechaAcceso BETWEEN :startDate AND :endDate " +
           "GROUP BY l.usuario " +
           "HAVING COUNT(DISTINCT l.ipAddress) > :maxIPs " +
           "ORDER BY ipCount DESC")
    List<Object[]> findSuspiciousAccess(@Param("startDate") LocalDateTime startDate,
                                       @Param("endDate") LocalDateTime endDate,
                                       @Param("maxIPs") long maxIPs);

    // Limpiar logs antiguos
    @Query("DELETE FROM LogAcceso l WHERE l.fechaAcceso < :cutoffDate")
    void deleteOldLogs(@Param("cutoffDate") LocalDateTime cutoffDate);
}
