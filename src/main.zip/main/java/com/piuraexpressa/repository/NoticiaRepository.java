package com.piuraexpressa.repository;

import com.piuraexpressa.model.Noticia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface NoticiaRepository extends JpaRepository<Noticia, Long> {

    // Búsquedas básicas
    Optional<Noticia> findBySlugAndActivaTrue(String slug);

    List<Noticia> findByActivaTrueOrderByFechaPublicacionDesc();

    Page<Noticia> findByActivaTrueOrderByFechaPublicacionDesc(Pageable pageable);

    // Noticias destacadas
    List<Noticia> findByDestacadaTrueAndActivaTrueOrderByFechaPublicacionDesc();

    Page<Noticia> findByDestacadaTrueAndActivaTrueOrderByFechaPublicacionDesc(Pageable pageable);

    // Búsquedas por categoría
    List<Noticia> findByCategoriaAndActivaTrueOrderByFechaPublicacionDesc(Noticia.CategoriaNoticia categoria);

    Page<Noticia> findByCategoriaAndActivaTrueOrderByFechaPublicacionDesc(Noticia.CategoriaNoticia categoria,
            Pageable pageable);

    // Búsquedas por autor
    List<Noticia> findByAutorIdOrderByFechaPublicacionDesc(Long autorId);

    Page<Noticia> findByAutorIdOrderByFechaPublicacionDesc(Long autorId, Pageable pageable);

    // Búsqueda por título
    Page<Noticia> findByTituloContainingIgnoreCaseAndActivaTrue(String titulo, Pageable pageable);

    // Búsqueda por texto completo
    @Query("SELECT n FROM Noticia n WHERE n.activa = true AND " +
            "(LOWER(n.titulo) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(n.contenido) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(n.resumen) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(n.tags) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
            "ORDER BY n.fechaPublicacion DESC")
    Page<Noticia> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);

    // Noticias relacionadas
    @Query("SELECT n FROM Noticia n WHERE n.categoria = :categoria AND n.id != :excludeId " +
            "AND n.activa = true ORDER BY n.fechaPublicacion DESC")
    List<Noticia> findRelatedNews(@Param("categoria") Noticia.CategoriaNoticia categoria,
            @Param("excludeId") Long excludeId,
            Pageable pageable);

    // Noticias recientes
    @Query("SELECT n FROM Noticia n WHERE n.activa = true ORDER BY n.fechaPublicacion DESC")
    List<Noticia> findRecentNews(Pageable pageable);

    // Noticias más vistas
    @Query("SELECT n FROM Noticia n WHERE n.activa = true ORDER BY n.vistas DESC")
    List<Noticia> findMostViewed(Pageable pageable);

    // Contadores
    long countByActivaTrue();

    long countByCategoriaAndActivaTrue(Noticia.CategoriaNoticia categoria);

    long countByAutorId(Long autorId);

    // Validaciones de slug
    boolean existsBySlug(String slug);

    boolean existsBySlugAndIdNot(String slug, Long id);
}
