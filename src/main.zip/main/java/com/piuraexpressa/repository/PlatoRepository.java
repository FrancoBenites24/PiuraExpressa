package com.piuraexpressa.repository;

import com.piuraexpressa.model.Plato;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;

@Repository
public interface PlatoRepository extends JpaRepository<Plato, Long> {

    Page<Plato> findByActivoTrue(Pageable pageable);
    
    Page<Plato> findByProvinciaId(Long provinciaId, Pageable pageable);
    
    Page<Plato> findByProvinciaIdAndActivoTrue(Long provinciaId, Pageable pageable);

    // Búsqueda por término
    @Query("SELECT p FROM Plato p WHERE " +
           "LOWER(p.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.descripcion) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    Page<Plato> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);

    // Platos activos por término de búsqueda
    @Query("SELECT p FROM Plato p WHERE p.activo = true AND (" +
           "LOWER(p.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.descripcion) LIKE LOWER(CONCAT('%', :searchTerm, '%')))")
    Page<Plato> findActiveBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);

    // Platos por rango de precios
    @Query("SELECT p FROM Plato p WHERE p.activo = true " +
           "AND p.precio BETWEEN :minPrice AND :maxPrice")
    Page<Plato> findByPriceRange(
            @Param("minPrice") BigDecimal minPrice,
            @Param("maxPrice") BigDecimal maxPrice,
            Pageable pageable);

    // Platos más baratos
    Page<Plato> findByActivoTrueOrderByPrecioAsc(Pageable pageable);

    // Platos más caros
    Page<Plato> findByActivoTrueOrderByPrecioDesc(Pageable pageable);

    // Platos por provincia ordenados por precio
    @Query("SELECT p FROM Plato p WHERE p.activo = true AND p.provincia.id = :provinciaId " +
           "ORDER BY p.precio ASC")
    Page<Plato> findByProvinciaOrderByPrecio(@Param("provinciaId") Long provinciaId, Pageable pageable);

    // Contar platos por provincia
    long countByProvinciaIdAndActivoTrue(Long provinciaId);

    // Precio promedio por provincia
    @Query("SELECT AVG(p.precio) FROM Plato p WHERE p.provincia.id = :provinciaId AND p.activo = true")
    BigDecimal findAveragePriceByProvincia(@Param("provinciaId") Long provinciaId);
}
