package com.piuraexpressa.repository;

import com.piuraexpressa.model.Provincia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProvinciaRepository extends JpaRepository<Provincia, Long> {

       // Buscar provincias activas
       List<Provincia> findByActivaTrueOrderByNombreAsc();

       Page<Provincia> findByActivaTrueOrderByNombreAsc(Pageable pageable);

       // Buscar por nombre
       Optional<Provincia> findByNombreAndActivaTrue(String nombre);

       @EntityGraph(attributePaths = {
                     "eventos", "platos", "puntosInteres", "galeria", "historia"
       })
       Optional<Provincia> findByNombreIgnoreCaseAndActivaTrue(String nombre);

       // Buscar con estadísticas
       @Query("SELECT p FROM Provincia p LEFT JOIN FETCH p.estadisticas e " +
                     "WHERE p.activa = true AND (e.anoActualizacion = " +
                     "(SELECT MAX(e2.anoActualizacion) FROM EstadisticaProvincia e2 WHERE e2.provincia = p) OR e IS NULL)")
       List<Provincia> findActivasWithLatestStats();

       // Buscar con clima
       @Query("SELECT p FROM Provincia p LEFT JOIN FETCH p.clima WHERE p.activa = true")
       List<Provincia> findActivasWithClima();

       // Buscar con galería
       @Query("SELECT p FROM Provincia p LEFT JOIN FETCH p.galeria g " +
                     "WHERE p.activa = true AND g.activa = true")
       List<Provincia> findActivasWithGaleria();

       // Buscar con puntos de interés
       @Query("SELECT p FROM Provincia p LEFT JOIN FETCH p.puntosInteres pi " +
                     "WHERE p.activa = true AND pi.activo = true")
       List<Provincia> findActivasWithPuntosInteres();

       // Contar provincias activas
       long countByActivaTrue();

       // Buscar por coordenadas cercanas
       @Query("SELECT p FROM Provincia p WHERE p.activa = true AND " +
                     "p.latitud BETWEEN :latMin AND :latMax AND " +
                     "p.longitud BETWEEN :lngMin AND :lngMax")
       List<Provincia> findByCoordinatesRange(
                     @Param("latMin") java.math.BigDecimal latMin,
                     @Param("latMax") java.math.BigDecimal latMax,
                     @Param("lngMin") java.math.BigDecimal lngMin,
                     @Param("lngMax") java.math.BigDecimal lngMax);

       // Verificar nombre único
       boolean existsByNombreIgnoreCaseAndIdNot(String nombre, Long id);

       // Métodos de búsqueda para admin
       Page<Provincia> findByNombreContainingIgnoreCase(String nombre, Pageable pageable);
       Page<Provincia> findByActiva(Boolean activa, Pageable pageable);
       Page<Provincia> findByNombreContainingIgnoreCaseAndActiva(String nombre, Boolean activa, Pageable pageable);
}
