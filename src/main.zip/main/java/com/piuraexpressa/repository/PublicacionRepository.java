package com.piuraexpressa.repository;

import com.piuraexpressa.model.Publicacion;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PublicacionRepository extends JpaRepository<Publicacion, Long> {

    // Búsquedas básicas
    Page<Publicacion> findByActivaTrueOrderByFechaCreacionDesc(Pageable pageable);

    // Búsquedas por usuario
    List<Publicacion> findByUsuarioIdOrderByFechaCreacionDesc(Long usuarioId);
    Page<Publicacion> findByUsuarioIdOrderByFechaCreacionDesc(Long usuarioId, Pageable pageable);
    List<Publicacion> findByUsuarioIdAndActivaTrueOrderByFechaCreacionDesc(Long usuarioId);

    // Búsqueda por texto
    @Query("SELECT p FROM Publicacion p WHERE p.activa = true AND " +
           "(LOWER(p.titulo) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(p.contenido) LIKE LOWER(CONCAT('%', :searchTerm, '%'))) " +
           "ORDER BY p.fechaCreacion DESC")
    Page<Publicacion> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);

    // Publicaciones con más comentarios
    @Query("SELECT p FROM Publicacion p LEFT JOIN p.comentarios c " +
           "WHERE p.activa = true GROUP BY p ORDER BY COUNT(c) DESC")
    List<Publicacion> findMostCommented(Pageable pageable);

    // Publicaciones con más likes
    @Query("SELECT p FROM Publicacion p WHERE p.activa = true " +
           "ORDER BY (SELECT COUNT(l) FROM UsuarioLikePublicacion l WHERE l.publicacion = p) DESC")
    List<Publicacion> findMostLiked(Pageable pageable);

    // Contadores
    long countByUsuarioId(Long usuarioId);
    long countByUsuarioIdAndActivaTrue(Long usuarioId);
    long countByActivaTrue();
}
