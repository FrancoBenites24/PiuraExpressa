package com.piuraexpressa.repository;

import com.piuraexpressa.model.PuntoInteres;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.math.BigDecimal;
import java.util.List;

@Repository
public interface PuntoInteresRepository extends JpaRepository<PuntoInteres, Long> {

    // Buscar por provincia
    List<PuntoInteres> findByProvinciaIdAndActivoTrueOrderByNombreAsc(Long provinciaId);
    Page<PuntoInteres> findByProvinciaIdAndActivoTrueOrderByNombreAsc(Long provinciaId, Pageable pageable);

    // Buscar por tipo
    List<PuntoInteres> findByProvinciaIdAndTipoAndActivoTrueOrderByCalificacionDesc(
            Long provinciaId, PuntoInteres.TipoPuntoInteres tipo);

    // Buscar por calificación
    List<PuntoInteres> findByProvinciaIdAndActivoTrueAndCalificacionGreaterThanEqualOrderByCalificacionDesc(
            Long provinciaId, BigDecimal calificacionMinima);

    // Buscar por rango de precios
    List<PuntoInteres> findByProvinciaIdAndActivoTrueAndPrecioPromedioBetweenOrderByPrecioPromedioAsc(
            Long provinciaId, BigDecimal precioMin, BigDecimal precioMax);

    // Buscar por coordenadas cercanas
    @Query("SELECT pi FROM PuntoInteres pi WHERE pi.activo = true AND " +
           "pi.latitud BETWEEN :latMin AND :latMax AND " +
           "pi.longitud BETWEEN :lngMin AND :lngMax")
    List<PuntoInteres> findByCoordinatesRange(
            @Param("latMin") BigDecimal latMin,
            @Param("latMax") BigDecimal latMax,
            @Param("lngMin") BigDecimal lngMin,
            @Param("lngMax") BigDecimal lngMax);

    // Buscar mejores calificados por tipo
    @Query("SELECT pi FROM PuntoInteres pi WHERE pi.provincia.id = :provinciaId " +
           "AND pi.tipo = :tipo AND pi.activo = true " +
           "ORDER BY pi.calificacion DESC, pi.numeroResenas DESC")
    List<PuntoInteres> findTopByProvinciaAndTipo(@Param("provinciaId") Long provinciaId, 
                                                 @Param("tipo") PuntoInteres.TipoPuntoInteres tipo, 
                                                 Pageable pageable);

    // Contar por provincia y tipo
    long countByProvinciaIdAndTipoAndActivoTrue(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo);

    // Buscar por texto
    @Query("SELECT pi FROM PuntoInteres pi WHERE pi.activo = true AND " +
           "(LOWER(pi.nombre) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
           "LOWER(pi.descripcion) LIKE LOWER(CONCAT('%', :searchTerm, '%')))")
    Page<PuntoInteres> findBySearchTerm(@Param("searchTerm") String searchTerm, Pageable pageable);
}
            