package com.piuraexpressa.repository;

import com.piuraexpressa.model.Resena;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ResenaRepository extends JpaRepository<Resena, Long> {

       // Búsquedas por evento
       List<Resena> findByEventoIdAndActivoTrueOrderByFechaCreacionDesc(Long eventoId);

       Page<Resena> findByEventoIdAndActivoTrueOrderByFechaCreacionDesc(Long eventoId, Pageable pageable);

       // Búsquedas por usuario
       List<Resena> findByUsuarioIdOrderByFechaCreacionDesc(Long usuarioId);

       Page<Resena> findByUsuarioIdOrderByFechaCreacionDesc(Long usuarioId, Pageable pageable);

       // Búsquedas por calificación
       List<Resena> findByEventoIdAndCalificacionAndActivoTrueOrderByFechaCreacionDesc(Long eventoId,
                     Integer calificacion);

       List<Resena> findByEventoIdAndCalificacionGreaterThanEqualAndActivoTrueOrderByCalificacionDesc(Long eventoId,
                     Integer calificacionMinima);

       // Reseñas recientes
       @Query("SELECT r FROM Resena r WHERE r.activo = true ORDER BY r.fechaCreacion DESC")
       List<Resena> findRecentReviews(Pageable pageable);

       // Mejores reseñas
       @Query("SELECT r FROM Resena r WHERE r.activo = true ORDER BY r.calificacion DESC, r.fechaCreacion DESC")
       List<Resena> findBestReviews(Pageable pageable);

       // Promedio de calificación por evento
       @Query("SELECT AVG(r.calificacion) FROM Resena r WHERE r.evento.id = :eventoId AND r.activo = true")
       Double getAverageRatingByEvento(@Param("eventoId") Long eventoId);

       // Contadores
       long countByEventoIdAndActivoTrue(Long eventoId);

       long countByUsuarioId(Long usuarioId);

       long countByEventoIdAndCalificacionAndActivoTrue(Long eventoId, Integer calificacion);
}
