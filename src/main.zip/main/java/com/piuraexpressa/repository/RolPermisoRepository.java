package com.piuraexpressa.repository;

import com.piuraexpressa.model.RolPermiso;
import com.piuraexpressa.model.RolPermisoId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RolPermisoRepository extends JpaRepository<RolPermiso, RolPermisoId> {
}