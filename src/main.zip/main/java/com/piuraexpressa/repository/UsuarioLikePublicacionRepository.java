package com.piuraexpressa.repository;

import com.piuraexpressa.model.UsuarioLikePublicacion;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface UsuarioLikePublicacionRepository extends JpaRepository<UsuarioLikePublicacion, UsuarioLikePublicacion.UsuarioLikePublicacionId> {

    // Contar likes por publicación
    long countByPublicacionId(Long publicacionId);

    // Contar likes por usuario
    long countByUsuarioId(Long usuarioId);

    // Obtener likes de un usuario
    List<UsuarioLikePublicacion> findByUsuarioIdOrderByFechaLikeDesc(Long usuarioId);

    // Obtener likes de una publicación
    List<UsuarioLikePublicacion> findByPublicacionIdOrderByFechaLikeDesc(Long publicacionId);

    // Verificar si existe like específico
    boolean existsByUsuarioIdAndPublicacionId(Long usuarioId, Long publicacionId);

    // Verificar si existe reacción específica
    boolean existsByUsuarioIdAndPublicacionIdAndTipoReaccion(Long usuarioId, Long publicacionId, String tipoReaccion);

    // Eliminar like específico
    void deleteByUsuarioIdAndPublicacionId(Long usuarioId, Long publicacionId);

    // Eliminar reacción específica
    void deleteByUsuarioIdAndPublicacionIdAndTipoReaccion(Long usuarioId, Long publicacionId, String tipoReaccion);

    // Obtener publicaciones más likeadas
    @Query("SELECT ul.publicacion.id, COUNT(ul) as likes FROM UsuarioLikePublicacion ul " +
           "GROUP BY ul.publicacion.id ORDER BY likes DESC")
    List<Object[]> findMostLikedPublications();
}
