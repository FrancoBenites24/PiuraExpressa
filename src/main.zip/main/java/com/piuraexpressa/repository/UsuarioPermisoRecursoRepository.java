package com.piuraexpressa.repository;

import com.piuraexpressa.model.UsuarioPermisoRecurso;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioPermisoRecursoRepository extends JpaRepository<UsuarioPermisoRecurso, Long> {
}
