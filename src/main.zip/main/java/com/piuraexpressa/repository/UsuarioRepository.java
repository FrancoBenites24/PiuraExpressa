package com.piuraexpressa.repository;

import com.piuraexpressa.model.Usuario;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface UsuarioRepository extends JpaRepository<Usuario, Long> {
    Optional<Usuario> buscarPorEmail(String email);
    Optional<Usuario> buscarPorUsername(String username);
    boolean existePorEmail(String email);
    boolean existePorUsername(String username);
}
