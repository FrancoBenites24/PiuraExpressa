package com.piuraexpressa.repository;

import com.piuraexpressa.model.UsuarioRol;
import com.piuraexpressa.model.UsuarioRolId;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UsuarioRolRepository extends JpaRepository<UsuarioRol, UsuarioRolId> {
}
