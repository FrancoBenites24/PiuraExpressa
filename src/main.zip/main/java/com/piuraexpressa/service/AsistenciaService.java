package com.piuraexpressa.service;

import com.piuraexpressa.dto.AsistenciaDTO;
import com.piuraexpressa.model.Asistencia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface AsistenciaService {

    // CRUD básico
    List<AsistenciaDTO> obtenerTodas();
    Page<AsistenciaDTO> obtenerTodasPaginadas(Pageable pageable);
    Optional<AsistenciaDTO> obtenerPorId(Long id);
    AsistenciaDTO guardar(AsistenciaDTO asistenciaDTO);
    AsistenciaDTO actualizar(Long id, AsistenciaDTO asistenciaDTO);
    void eliminar(Long id);

    // Búsquedas por evento
    List<AsistenciaDTO> obtenerPorEvento(Long eventoId);
    Page<AsistenciaDTO> obtenerPorEventoPaginadas(Long eventoId, Pageable pageable);
    List<AsistenciaDTO> obtenerPorEventoYEstado(Long eventoId, Asistencia.EstadoAsistencia estado);

    // Búsquedas por usuario
    List<AsistenciaDTO> obtenerPorUsuario(Long usuarioId);
    Page<AsistenciaDTO> obtenerPorUsuarioPaginadas(Long usuarioId, Pageable pageable);
    List<AsistenciaDTO> obtenerPorUsuarioYEstado(Long usuarioId, Asistencia.EstadoAsistencia estado);

    // Gestión de asistencias
    AsistenciaDTO registrarAsistencia(Long usuarioId, Long eventoId, String observaciones);
    void confirmarAsistencia(Long id);
    void cancelarAsistencia(Long id);
    void marcarComoAsistio(Long id);
    void marcarComoNoAsistio(Long id);

    // Validaciones
    boolean yaEstaRegistrado(Long usuarioId, Long eventoId);
    boolean puedeRegistrarse(Long usuarioId, Long eventoId);

    // Estadísticas
    long contarPorEvento(Long eventoId);
    long contarPorEventoYEstado(Long eventoId, Asistencia.EstadoAsistencia estado);
    long contarPorUsuario(Long usuarioId);
    double calcularPorcentajeAsistencia(Long eventoId);
}
