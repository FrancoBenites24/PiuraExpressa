package com.piuraexpressa.service;

import com.piuraexpressa.dto.LoginDTO;
import com.piuraexpressa.dto.RegistroDTO;
import com.piuraexpressa.dto.UsuarioDTO;

public interface AuthService {

    // Autenticación
    UsuarioDTO login(LoginDTO loginDTO);
    void logout();
    
    // Registro
    UsuarioDTO registrar(RegistroDTO registroDTO);
    
    // Validaciones
    boolean existeEmail(String email);
    boolean existeUsername(String username);
    boolean existeDocumento(String numeroDocumento);
    
    // Gestión de contraseñas
    void cambiarContrasena(Long usuarioId, String contrasenaActual, String nuevaContrasena);
    void solicitarRecuperacionContrasena(String email);
    void recuperarContrasena(String token, String nuevaContrasena);
    
    // Activación de cuenta
    void enviarEmailActivacion(String email);
    void activarCuenta(String token);
    
    // Usuario actual
    UsuarioDTO obtenerUsuarioActual();
    boolean estaAutenticado();
    boolean tieneRol(String rol);
}
