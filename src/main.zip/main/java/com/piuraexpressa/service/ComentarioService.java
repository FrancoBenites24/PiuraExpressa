package com.piuraexpressa.service;

import com.piuraexpressa.dto.ComentarioDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;

public interface ComentarioService {
    List<ComentarioDTO> obtenerComentariosPorPublicacion(Long publicacionId);
    ComentarioDTO crearComentario(Long publicacionId, String contenido, String username);
    Page<ComentarioDTO> obtenerTodosPaginados(Pageable pageable);
}
