package com.piuraexpressa.service;

import com.piuraexpressa.dto.EstadisticaProvinciaDTO;

import java.time.Year;
import java.util.List;
import java.util.Optional;

public interface EstadisticaProvinciaService {

    // CRUD básico
    List<EstadisticaProvinciaDTO> obtenerTodas();
    Optional<EstadisticaProvinciaDTO> obtenerPorId(Long id);
    EstadisticaProvinciaDTO guardar(EstadisticaProvinciaDTO estadisticaDTO);
    EstadisticaProvinciaDTO actualizar(Long id, EstadisticaProvinciaDTO estadisticaDTO);
    void eliminar(Long id);

    // Búsquedas por provincia
    List<EstadisticaProvinciaDTO> obtenerPorProvincia(Long provinciaId);
    Optional<EstadisticaProvinciaDTO> obtenerMasRecientePorProvincia(Long provinciaId);

    // Búsquedas por año
    List<EstadisticaProvinciaDTO> obtenerPorAno(Year ano);
    Optional<EstadisticaProvinciaDTO> obtenerPorProvinciaYAno(Long provinciaId, Year ano);

    // Comparativas y estadísticas
    List<EstadisticaProvinciaDTO> obtenerRankingPorPoblacion(Year ano);
    List<EstadisticaProvinciaDTO> obtenerRankingPorPib(Year ano);
    
    // Promedios regionales
    Double obtenerPromedioPoblacion(Year ano);
    Double obtenerPromedioPib(Year ano);

    // Validaciones
    boolean existePorProvinciaYAno(Long provinciaId, Year ano);

    // Utilidades
    EstadisticaProvinciaDTO crearEstadisticaActual(Long provinciaId);
    void actualizarEstadisticasAutomaticas(Long provinciaId);
}
