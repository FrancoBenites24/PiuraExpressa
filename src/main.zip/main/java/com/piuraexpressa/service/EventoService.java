package com.piuraexpressa.service;

import com.piuraexpressa.dto.EventoDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

public interface EventoService {

    // CRUD básico
    List<EventoDTO> obtenerTodos();
    List<EventoDTO> obtenerTodosActivos(); // ✅ Método que falta
    Page<EventoDTO> obtenerTodosPaginados(Pageable pageable);
    Optional<EventoDTO> obtenerPorId(Long id);
    EventoDTO guardar(EventoDTO eventoDTO);
    EventoDTO actualizar(Long id, EventoDTO eventoDTO);
    void eliminar(Long id);
    void activar(Long id);
    void desactivar(Long id);

    // Búsquedas por provincia
    List<EventoDTO> obtenerPorProvincia(Long provinciaId);
    Page<EventoDTO> obtenerEventosPorUsuarioPaginadas(Long usuarioId, Pageable pageable);
    Page<EventoDTO> obtenerPorProvinciaPaginados(Long provinciaId, Pageable pageable);
    List<EventoDTO> obtenerActivosPorProvincia(Long provinciaId);

    // Búsquedas por fecha
    List<EventoDTO> obtenerProximos(int limite);
    List<EventoDTO> obtenerPorRangoFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin);
    List<EventoDTO> obtenerPorProvinciaYRangoFechas(Long provinciaId, LocalDateTime fechaInicio, LocalDateTime fechaFin);

    // Búsquedas especiales
    List<EventoDTO> obtenerDestacados();
    List<EventoDTO> obtenerGratuitos();
    Page<EventoDTO> buscarPorTexto(String searchTerm, Pageable pageable);

    // Estadísticas
    long contarPorProvincia(Long provinciaId);
    long contarActivosPorProvincia(Long provinciaId);
    long contarProximos();

    // Utilidades
    boolean estaDisponible(Long eventoId);
    int calcularCapacidadDisponible(Long eventoId);
}
