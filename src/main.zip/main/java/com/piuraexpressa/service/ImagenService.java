package com.piuraexpressa.service;

import com.piuraexpressa.model.Imagen;
import com.piuraexpressa.model.Imagen.TipoReferencia;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.ImagenRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
@RequiredArgsConstructor
@Slf4j
public class ImagenService {

    private final ImagenRepository imagenRepository;

    @Value("${app.upload.dir:uploads}")
    private String uploadDir;

    @Value("${app.upload.max-size:5242880}") // 5MB default
    private long maxFileSize;

    public String obtenerUrlImagenPerfil(Long usuarioId) {
        return imagenRepository
                .findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(usuarioId, TipoReferencia.PERFIL)
                .map(Imagen::getUrl)
                .orElse("/img/default-profile.png");
    }

    public String obtenerUrlImagenProvincia(Long provinciaId) {
        return imagenRepository
                .findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(provinciaId, TipoReferencia.PROVINCIA)
                .map(Imagen::getUrl)
                .orElse(null);
    }

    public String subirImagenProvincia(MultipartFile file, Long provinciaId, Usuario usuario) throws IOException {
        log.debug("Subiendo imagen para provincia ID: {}", provinciaId);
        
        // Validaciones
        if (file.isEmpty()) {
            throw new IllegalArgumentException("El archivo está vacío");
        }

        if (file.getSize() > maxFileSize) {
            throw new IllegalArgumentException("El archivo excede el tamaño máximo permitido");
        }

        if (!esImagenValida(file)) {
            throw new IllegalArgumentException("Tipo de archivo no válido. Solo se permiten imágenes JPG, PNG y GIF");
        }

        // Generar nombre único para el archivo
        String extension = obtenerExtension(file.getOriginalFilename());
        String nombreArchivo = "provincia_" + provinciaId + "_" + UUID.randomUUID().toString() + "." + extension;
        
        // Crear directorio si no existe
        Path uploadPath = Paths.get(uploadDir, "provincias");
        Files.createDirectories(uploadPath);
        
        // Guardar archivo
        Path filePath = uploadPath.resolve(nombreArchivo);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);
        
        // URL relativa para acceso web
        String url = "/uploads/provincias/" + nombreArchivo;
        
        // Eliminar imagen anterior si existe
        eliminarImagenAnteriorProvincia(provinciaId);
        
        // Guardar registro en base de datos
        Imagen imagen = Imagen.builder()
                .nombreArchivo(nombreArchivo)
                .url(url)
                .tipoReferencia(TipoReferencia.PROVINCIA)
                .referenciaId(provinciaId)
                .tamañoBytes(file.getSize())
                .tipoMime(file.getContentType())
                .entidadTipo("Provincia")
                .usuario(usuario)
                .build();
        
        imagenRepository.save(imagen);
        
        log.info("Imagen subida exitosamente para provincia ID: {} - URL: {}", provinciaId, url);
        return url;
    }

    public void eliminarImagenProvincia(Long provinciaId) {
        log.debug("Eliminando imagen de provincia ID: {}", provinciaId);
        
        imagenRepository.findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(provinciaId, TipoReferencia.PROVINCIA)
                .ifPresent(imagen -> {
                    try {
                        // Eliminar archivo físico
                        Path filePath = Paths.get(uploadDir, "provincias", imagen.getNombreArchivo());
                        Files.deleteIfExists(filePath);
                        
                        // Eliminar registro de base de datos
                        imagenRepository.delete(imagen);
                        
                        log.info("Imagen eliminada exitosamente para provincia ID: {}", provinciaId);
                    } catch (IOException e) {
                        log.error("Error al eliminar archivo de imagen: {}", e.getMessage());
                    }
                });
    }

    public String subirImagenPublicacion(MultipartFile file, Long publicacionId, Usuario usuario) throws IOException {
        log.debug("Subiendo imagen para publicación ID: {}", publicacionId);

        if (file.isEmpty()) {
            throw new IllegalArgumentException("El archivo está vacío");
        }

        if (file.getSize() > maxFileSize) {
            throw new IllegalArgumentException("El archivo excede el tamaño máximo permitido");
        }

        if (!esImagenValida(file)) {
            throw new IllegalArgumentException("Tipo de archivo no válido. Solo se permiten imágenes JPG, PNG y GIF");
        }

        String extension = obtenerExtension(file.getOriginalFilename());
        String nombreArchivo = "publicacion_" + publicacionId + "_" + UUID.randomUUID().toString() + "." + extension;

        Path uploadPath = Paths.get(uploadDir, "publicaciones");
        Files.createDirectories(uploadPath);

        Path filePath = uploadPath.resolve(nombreArchivo);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        String url = "/uploads/publicaciones/" + nombreArchivo;

        eliminarImagenAnteriorPublicacion(publicacionId);

        Imagen imagen = Imagen.builder()
                .nombreArchivo(nombreArchivo)
                .url(url)
                .tipoReferencia(TipoReferencia.PUBLICACION)
                .referenciaId(publicacionId)
                .tamañoBytes(file.getSize())
                .tipoMime(file.getContentType())
                .entidadTipo("Publicacion")
                .usuario(usuario)
                .build();

        imagenRepository.save(imagen);

        log.info("Imagen subida exitosamente para publicación ID: {} - URL: {}", publicacionId, url);
        return url;
    }

    private void eliminarImagenAnteriorPublicacion(Long publicacionId) {
        imagenRepository.findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(publicacionId, TipoReferencia.PUBLICACION)
                .ifPresent(imagenAnterior -> {
                    try {
                        Path filePath = Paths.get(uploadDir, "publicaciones", imagenAnterior.getNombreArchivo());
                        Files.deleteIfExists(filePath);
                        imagenRepository.delete(imagenAnterior);
                        log.debug("Imagen anterior eliminada para publicación ID: {}", publicacionId);
                    } catch (IOException e) {
                        log.warn("No se pudo eliminar la imagen anterior: {}", e.getMessage());
                    }
                });
    }

    private void eliminarImagenAnteriorProvincia(Long provinciaId) {
        imagenRepository.findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(provinciaId, TipoReferencia.PROVINCIA)
                .ifPresent(imagenAnterior -> {
                    try {
                        Path filePath = Paths.get(uploadDir, "provincias", imagenAnterior.getNombreArchivo());
                        Files.deleteIfExists(filePath);
                        imagenRepository.delete(imagenAnterior);
                        log.debug("Imagen anterior eliminada para provincia ID: {}", provinciaId);
                    } catch (IOException e) {
                        log.warn("No se pudo eliminar la imagen anterior: {}", e.getMessage());
                    }
                });
    }

    private boolean esImagenValida(MultipartFile file) {
        String contentType = file.getContentType();
        return contentType != null && (
                contentType.equals("image/jpeg") ||
                contentType.equals("image/jpg") ||
                contentType.equals("image/png") ||
                contentType.equals("image/gif")
        );
    }

    private String obtenerExtension(String nombreArchivo) {
        if (nombreArchivo == null || !nombreArchivo.contains(".")) {
            return "jpg";
        }
        return nombreArchivo.substring(nombreArchivo.lastIndexOf(".") + 1).toLowerCase();
    }

    public String subirImagenPuntoInteres(MultipartFile file, Long puntoInteresId) throws IOException {
        log.debug("Subiendo imagen para punto de interés ID: {}", puntoInteresId);

        if (file.isEmpty()) {
            throw new IllegalArgumentException("El archivo está vacío");
        }

        if (file.getSize() > maxFileSize) {
            throw new IllegalArgumentException("El archivo excede el tamaño máximo permitido");
        }

        if (!esImagenValida(file)) {
            throw new IllegalArgumentException("Tipo de archivo no válido. Solo se permiten imágenes JPG, PNG y GIF");
        }

        String extension = obtenerExtension(file.getOriginalFilename());
        String nombreArchivo = "punto_interes_" + puntoInteresId + "_" + UUID.randomUUID().toString() + "." + extension;

        Path uploadPath = Paths.get(uploadDir, "puntos-interes");
        Files.createDirectories(uploadPath);

        Path filePath = uploadPath.resolve(nombreArchivo);
        Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

        String url = "/uploads/puntos-interes/" + nombreArchivo;

        eliminarImagenAnteriorPuntoInteres(puntoInteresId);

        Imagen imagen = Imagen.builder()
                .nombreArchivo(nombreArchivo)
                .url(url)
                .tipoReferencia(TipoReferencia.POI)
                .referenciaId(puntoInteresId)
                .tamañoBytes(file.getSize())
                .tipoMime(file.getContentType())
                .entidadTipo("PuntoInteres")
                .build();

        imagenRepository.save(imagen);

        log.info("Imagen subida exitosamente para punto de interés ID: {} - URL: {}", puntoInteresId, url);
        return url;
    }

    private void eliminarImagenAnteriorPuntoInteres(Long puntoInteresId) {
        imagenRepository.findFirstByReferenciaIdAndTipoReferenciaOrderByFechaSubidaDesc(puntoInteresId, TipoReferencia.POI)
                .ifPresent(imagenAnterior -> {
                    try {
                        Path filePath = Paths.get(uploadDir, "puntos-interes", imagenAnterior.getNombreArchivo());
                        Files.deleteIfExists(filePath);
                        imagenRepository.delete(imagenAnterior);
                        log.debug("Imagen anterior eliminada para punto de interés ID: {}", puntoInteresId);
                    } catch (IOException e) {
                        log.warn("No se pudo eliminar la imagen anterior: {}", e.getMessage());
                    }
                });
    }
}
