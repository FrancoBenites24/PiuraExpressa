package com.piuraexpressa.service;

import com.piuraexpressa.dto.NoticiaDTO;
import com.piuraexpressa.model.Noticia;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface NoticiaService {

    // CRUD básico
    List<NoticiaDTO> obtenerTodas();
    Page<NoticiaDTO> obtenerTodasPaginadas(Pageable pageable);
    Optional<NoticiaDTO> obtenerPorId(Long id);
    Optional<NoticiaDTO> obtenerPorSlug(String slug);
    NoticiaDTO guardar(NoticiaDTO noticiaDTO);
    NoticiaDTO actualizar(Long id, NoticiaDTO noticiaDTO);
    void eliminar(Long id);
    void activar(Long id);
    void desactivar(Long id);

    // Búsquedas por estado
    List<NoticiaDTO> obtenerActivas();
    Page<NoticiaDTO> obtenerActivasPaginadas(Pageable pageable);
    List<NoticiaDTO> obtenerDestacadas();
    Page<NoticiaDTO> obtenerDestacadasPaginadas(Pageable pageable);

    // Búsquedas por categoría
    List<NoticiaDTO> obtenerPorCategoria(Noticia.CategoriaNoticia categoria);
    Page<NoticiaDTO> obtenerPorCategoriaPaginadas(Noticia.CategoriaNoticia categoria, Pageable pageable);

    // Búsquedas por autor
    List<NoticiaDTO> obtenerPorAutor(Long autorId);
    Page<NoticiaDTO> obtenerPorAutorPaginadas(Long autorId, Pageable pageable);

    // Búsquedas por texto
    Page<NoticiaDTO> buscarPorTexto(String searchTerm, Pageable pageable);
    Page<NoticiaDTO> buscarPorTitulo(String titulo, Pageable pageable);

    // Noticias relacionadas
    List<NoticiaDTO> obtenerRelacionadas(Long noticiaId, int limite);
    List<NoticiaDTO> obtenerRecientes(int limite);
    List<NoticiaDTO> obtenerMasVistas(int limite);

    // Estadísticas
    long contarActivas();
    long contarPorCategoria(Noticia.CategoriaNoticia categoria);
    long contarPorAutor(Long autorId);

    // Utilidades
    void incrementarVistas(Long id);
    void marcarComoDestacada(Long id);
    void quitarDestacada(Long id);
    String generarSlug(String titulo);
    boolean existeSlug(String slug);
    boolean existeSlug(String slug, Long excludeId);
}
