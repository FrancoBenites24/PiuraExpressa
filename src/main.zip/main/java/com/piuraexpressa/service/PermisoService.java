package com.piuraexpressa.service;

import com.piuraexpressa.model.Permiso;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface PermisoService {
    Page<Permiso> listarTodos(Pageable pageable);
    Optional<Permiso> buscarPorId(Long id);
    Optional<Permiso> buscarPorNombre(String nombre);
    Permiso guardar(Permiso permiso);
    void eliminar(Long id);
}
