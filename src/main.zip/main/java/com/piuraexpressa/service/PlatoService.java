package com.piuraexpressa.service;

import com.piuraexpressa.model.Plato;
import com.piuraexpressa.repository.PlatoRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PlatoService {

    private final PlatoRepository platoRepository;

    public PlatoService(PlatoRepository platoRepository) {
        this.platoRepository = platoRepository;
    }

    public Page<Plato> obtenerTodosPaginados(Pageable pageable) {
        return platoRepository.findAll(pageable);
    }

    public Optional<Plato> obtenerPorId(Long id) {
        return platoRepository.findById(id);
    }

    public Plato guardar(Plato plato) {
        return platoRepository.save(plato);
    }

    public void eliminar(Long id) {
        platoRepository.deleteById(id);
    }
}
