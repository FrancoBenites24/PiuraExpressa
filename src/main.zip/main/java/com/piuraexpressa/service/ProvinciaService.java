package com.piuraexpressa.service;

import com.piuraexpressa.dto.ProvinciaDTO;
import com.piuraexpressa.dto.PuntoInteresDTO;
import com.piuraexpressa.dto.HistoriaProvinciaDTO;
import com.piuraexpressa.dto.EstadisticaProvinciaDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

public interface ProvinciaService {


    // CRUD básico
    List<ProvinciaDTO> obtenerTodas();
    Page<ProvinciaDTO> obtenerTodasPaginadas(Pageable pageable);
    List<ProvinciaDTO> obtenerTodasActivas();
    Optional<ProvinciaDTO> obtenerPorId(Long id);
    Optional<ProvinciaDTO> obtenerPorNombre(String nombre);
    ProvinciaDTO guardar(ProvinciaDTO provinciaDTO);
    ProvinciaDTO actualizar(Long id, ProvinciaDTO provinciaDTO);
    void eliminar(Long id);
    void activar(Long id);
    void desactivar(Long id);

    // Métodos con datos relacionados
    Optional<ProvinciaDTO> obtenerConEstadisticas(Long id);
    Optional<ProvinciaDTO> obtenerConClima(Long id);
    Optional<ProvinciaDTO> obtenerConGaleria(Long id);
    Optional<ProvinciaDTO> obtenerConPuntosInteres(Long id);
    Optional<ProvinciaDTO> obtenerConHistoria(Long id);
    Optional<ProvinciaDTO> obtenerCompleta(Long id);

    // Métodos para puntos de interés
    List<PuntoInteresDTO> obtenerPuntosInteresPorProvincia(Long provinciaId);
    Page<PuntoInteresDTO> obtenerPuntosInteresPorProvinciaPaginados(Long provinciaId, org.springframework.data.domain.Pageable pageable);
    PuntoInteresDTO obtenerPuntoInteresPorId(Long id);
    PuntoInteresDTO crearPuntoInteres(Long provinciaId, PuntoInteresDTO puntoInteresDTO);
    PuntoInteresDTO actualizarPuntoInteres(Long id, PuntoInteresDTO puntoInteresDTO);
    void eliminarPuntoInteres(Long id);

    void activarPuntoInteres(Long id);
    void desactivarPuntoInteres(Long id);

    // Métodos para historia
    List<HistoriaProvinciaDTO> obtenerHistoriaPorProvincia(Long provinciaId);
    Page<HistoriaProvinciaDTO> obtenerHistoriaPorProvinciaPaginada(Long provinciaId, org.springframework.data.domain.Pageable pageable);
    HistoriaProvinciaDTO obtenerEventoHistoricoPorId(Long id);
    HistoriaProvinciaDTO crearEventoHistorico(Long provinciaId, HistoriaProvinciaDTO historiaProvinciaDTO);
    HistoriaProvinciaDTO actualizarEventoHistorico(Long id, HistoriaProvinciaDTO historiaProvinciaDTO);
    void eliminarEventoHistorico(Long id);

    boolean existeEventoHistoricoConTitulo(Long provinciaId, String titulo);
    boolean existeEventoHistoricoConTituloExceptoId(Long provinciaId, String titulo, Long id);

    Page<EstadisticaProvinciaDTO> obtenerEstadisticasPaginadas(Long provinciaId, org.springframework.data.domain.Pageable pageable);

    EstadisticaProvinciaDTO crearEstadistica(Long provinciaId, EstadisticaProvinciaDTO estadisticaDTO);
    EstadisticaProvinciaDTO actualizarEstadistica(Long id, EstadisticaProvinciaDTO estadisticaDTO);
    void eliminarEstadistica(Long id);

    // Búsquedas especiales
    List<ProvinciaDTO> obtenerConEstadisticasActuales();
    List<ProvinciaDTO> obtenerPorCoordenadasCercanas(
            java.math.BigDecimal latitud, 
            java.math.BigDecimal longitud, 
            double radioKm);

    // Nueva búsqueda paginada con filtros
    Page<ProvinciaDTO> buscarPaginadas(String search, String estado, Pageable pageable);

    // Validaciones
    boolean existePorNombre(String nombre);
    boolean existePorNombre(String nombre, Long excludeId);
    long contarActivas();

    // Utilidades
    void actualizarEstadisticas(Long provinciaId);
    void actualizarClima(Long provinciaId);
}
