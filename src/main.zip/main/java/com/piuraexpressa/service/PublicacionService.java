package com.piuraexpressa.service;

import com.piuraexpressa.dto.PublicacionDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

import org.springframework.transaction.annotation.Transactional;

public interface PublicacionService {
    // CRUD básico
    Page<PublicacionDTO> obtenerTodasPaginadas(Pageable pageable, Long usuarioId);
    Optional<PublicacionDTO> obtenerPorId(Long id, Long usuarioId);
    PublicacionDTO guardar(PublicacionDTO publicacionDTO);
    PublicacionDTO actualizar(Long id, PublicacionDTO publicacionDTO);
    void eliminar(Long id);
    void activar(Long id);
    void desactivar(Long id);

    // Búsquedas activas
    Page<PublicacionDTO> obtenerActivasPaginadas(Pageable pageable, Long usuarioId);

    // Búsquedas por usuario
    Page<PublicacionDTO> obtenerPorUsuarioPaginadas(Long usuarioId, Pageable pageable);
    Page<PublicacionDTO> obtenerActivasPorUsuario(Long usuarioId, Pageable pageable);

    // Búsquedas por texto
    Page<PublicacionDTO> buscarPorTexto(String searchTerm, Pageable pageable);

    // Publicaciones destacadas
    List<PublicacionDTO> obtenerMasComentadas(int limite);
    List<PublicacionDTO> obtenerMasLikeadas(int limite);
    List<PublicacionDTO> obtenerRecientes(int limite);

    // Contadores
    long contarTodas();
    long contarActivas();
    long contarPorUsuario(Long usuarioId);
    long contarActivasPorUsuario(Long usuarioId);

    // Gestión de likes
    void darLike(Long publicacionId, Long usuarioId);
    void quitarLike(Long publicacionId, Long usuarioId);
    boolean usuarioHaDadoLike(Long publicacionId, Long usuarioId);
    long contarLikes(Long publicacionId);

    // Nuevos métodos para reacciones múltiples
    void darReaccion(Long publicacionId, Long usuarioId, String tipoReaccion);
    void quitarReaccion(Long publicacionId, Long usuarioId, String tipoReaccion);
    boolean usuarioHaDadoReaccion(Long publicacionId, Long usuarioId, String tipoReaccion);
    long contarReacciones(Long publicacionId, String tipoReaccion);

    // Utilidades
    boolean puedeEditar(Long publicacionId, Long usuarioId);
    boolean puedeEliminar(Long publicacionId, Long usuarioId);

    // Nuevos métodos para reportar, guardar y compartir publicaciones
    boolean reportarPublicacion(Long publicacionId, String username);
    boolean guardarPublicacion(Long publicacionId, String username);
    boolean compartirPublicacion(Long publicacionId, String username);

    // Método para actualizar la ruta de la imagen
    @Transactional
    void actualizarImagen(Long id, String rutaImagen);

    // Método para eliminar con validación de permisos
    boolean eliminarConPermiso(Long id, Long usuarioId, boolean esAdmin);
}
