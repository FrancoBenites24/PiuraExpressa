package com.piuraexpressa.service;

import com.piuraexpressa.dto.PuntoInteresDTO;
import com.piuraexpressa.model.PuntoInteres;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

public interface PuntoInteresService {

    // CRUD básico
    List<PuntoInteresDTO> obtenerTodos();
    Page<PuntoInteresDTO> obtenerTodosPaginados(Pageable pageable);
    Optional<PuntoInteresDTO> obtenerPorId(Long id);
    PuntoInteresDTO guardar(PuntoInteresDTO puntoInteresDTO);
    PuntoInteresDTO actualizar(Long id, PuntoInteresDTO puntoInteresDTO);
    void eliminar(Long id);
    void activar(Long id);
    void desactivar(Long id);

    // Búsquedas por provincia
    List<PuntoInteresDTO> obtenerPorProvincia(Long provinciaId);
    Page<PuntoInteresDTO> obtenerPorProvinciaPaginados(Long provinciaId, Pageable pageable);

    // Búsquedas por tipo
    List<PuntoInteresDTO> obtenerPorProvinciaYTipo(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo);
    List<PuntoInteresDTO> obtenerMejoresPorTipo(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo, int limite);

    // Búsquedas por calificación y precio
    List<PuntoInteresDTO> obtenerPorCalificacionMinima(Long provinciaId, BigDecimal calificacionMinima);
    List<PuntoInteresDTO> obtenerPorRangoPrecios(Long provinciaId, BigDecimal precioMin, BigDecimal precioMax);

    // Búsquedas geográficas
    List<PuntoInteresDTO> obtenerCercanos(BigDecimal latitud, BigDecimal longitud, double radioKm);

    // Búsquedas por texto
    Page<PuntoInteresDTO> buscarPorTexto(String searchTerm, Pageable pageable);

    // Estadísticas
    long contarPorProvinciaYTipo(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo);
    
    // Utilidades
    void actualizarCalificacion(Long id, BigDecimal nuevaCalificacion);
    void incrementarResenas(Long id);
}
