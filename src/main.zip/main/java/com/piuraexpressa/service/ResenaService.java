package com.piuraexpressa.service;

import com.piuraexpressa.model.Resena;
import com.piuraexpressa.repository.ResenaRepository;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ResenaService {

    private final ResenaRepository resenaRepository;

    public ResenaService(ResenaRepository resenaRepository) {
        this.resenaRepository = resenaRepository;
    }

    public Page<Resena> obtenerTodosPaginados(Pageable pageable) {
        return resenaRepository.findAll(pageable);
    }

    public Optional<Resena> obtenerPorId(Long id) {
        return resenaRepository.findById(id);
    }

    public Resena guardar(Resena resena) {
        return resenaRepository.save(resena);
    }

    public void eliminar(Long id) {
        resenaRepository.deleteById(id);
    }
}
