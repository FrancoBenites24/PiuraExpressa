package com.piuraexpressa.service;

import com.piuraexpressa.model.Rol;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.Optional;

public interface RolService {
    Page<Rol> listarTodos(Pageable pageable);
    Optional<Rol> buscarPorId(Long id);
    Optional<Rol> buscarPorNombre(String nombre);
    Rol guardar(Rol rol);
    void eliminar(Long id);
}
