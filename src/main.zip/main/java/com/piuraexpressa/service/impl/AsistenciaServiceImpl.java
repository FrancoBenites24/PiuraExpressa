package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.AsistenciaDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.AsistenciaMapper;
import com.piuraexpressa.model.Asistencia;
import com.piuraexpressa.model.Evento;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.AsistenciaRepository;
import com.piuraexpressa.repository.EventoRepository;
import com.piuraexpressa.repository.UsuarioRepository;
import com.piuraexpressa.service.AsistenciaService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class AsistenciaServiceImpl implements AsistenciaService {

    private final AsistenciaRepository asistenciaRepository;
    private final EventoRepository eventoRepository;
    private final UsuarioRepository usuarioRepository;
    private final AsistenciaMapper asistenciaMapper;

    @Override
    @Transactional(readOnly = true)
    public List<AsistenciaDTO> obtenerTodas() {
        log.debug("Obteniendo todas las asistencias");
        List<Asistencia> asistencias = asistenciaRepository.findAll();
        return asistenciaMapper.toDTOList(asistencias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AsistenciaDTO> obtenerTodasPaginadas(Pageable pageable) {
        log.debug("Obteniendo asistencias paginadas: {}", pageable);
        Page<Asistencia> asistencias = asistenciaRepository.findAll(pageable);
        return asistencias.map(asistenciaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<AsistenciaDTO> obtenerPorId(Long id) {
        log.debug("Obteniendo asistencia por ID: {}", id);
        return asistenciaRepository.findById(id)
                .map(asistenciaMapper::toDTO);
    }

    @Override
    public AsistenciaDTO guardar(AsistenciaDTO asistenciaDTO) {
        log.debug("Guardando nueva asistencia para evento ID: {}", asistenciaDTO.getEventoId());

        Usuario usuario = usuarioRepository.findById(asistenciaDTO.getUsuarioId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Usuario no encontrado con ID: " + asistenciaDTO.getUsuarioId()));

        Evento evento = eventoRepository.findById(asistenciaDTO.getEventoId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Evento no encontrado con ID: " + asistenciaDTO.getEventoId()));

        // Validar que el usuario no esté ya registrado
        if (yaEstaRegistrado(asistenciaDTO.getUsuarioId(), asistenciaDTO.getEventoId())) {
            throw new IllegalArgumentException("El usuario ya está registrado para este evento");
        }

        // Validar que se pueda registrar
        if (!puedeRegistrarse(asistenciaDTO.getUsuarioId(), asistenciaDTO.getEventoId())) {
            throw new IllegalArgumentException("No se puede registrar para este evento");
        }

        Asistencia asistencia = asistenciaMapper.toEntity(asistenciaDTO);
        asistencia.setUsuario(usuario);
        asistencia.setEvento(evento);

        Asistencia asistenciaGuardada = asistenciaRepository.save(asistencia);

        log.info("Asistencia guardada exitosamente con ID: {}", asistenciaGuardada.getId());

        return asistenciaMapper.toDTO(asistenciaGuardada);
    }

    @Override
    public AsistenciaDTO actualizar(Long id, AsistenciaDTO asistenciaDTO) {
        log.debug("Actualizando asistencia ID: {}", id);

        Asistencia asistenciaExistente = asistenciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Asistencia no encontrada con ID: " + id));

        asistenciaMapper.updateEntityFromDTO(asistenciaDTO, asistenciaExistente);
        Asistencia asistenciaActualizada = asistenciaRepository.save(asistenciaExistente);

        log.info("Asistencia actualizada exitosamente con ID: {}", asistenciaActualizada.getId());

        return asistenciaMapper.toDTO(asistenciaActualizada);
    }

    @Override
    public void eliminar(Long id) {
        log.debug("Eliminando asistencia ID: {}", id);

        if (!asistenciaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Asistencia no encontrada con ID: " + id);
        }

        asistenciaRepository.deleteById(id);
        log.info("Asistencia eliminada exitosamente con ID: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsistenciaDTO> obtenerPorEvento(Long eventoId) {
        log.debug("Obteniendo asistencias por evento ID: {}", eventoId);

        List<Asistencia> asistencias = asistenciaRepository.findByEventoIdOrderByFechaRegistroDesc(eventoId);
        return asistenciaMapper.toDTOList(asistencias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AsistenciaDTO> obtenerPorEventoPaginadas(Long eventoId, Pageable pageable) {
        log.debug("Obteniendo asistencias por evento ID: {} paginadas: {}", eventoId, pageable);

        Page<Asistencia> asistencias = asistenciaRepository.findByEventoIdOrderByFechaRegistroDesc(eventoId, pageable);
        return asistencias.map(asistenciaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsistenciaDTO> obtenerPorEventoYEstado(Long eventoId, Asistencia.EstadoAsistencia estado) {
        log.debug("Obteniendo asistencias por evento ID: {} y estado: {}", eventoId, estado);

        List<Asistencia> asistencias = asistenciaRepository.findByEventoIdAndEstadoOrderByFechaRegistroDesc(eventoId,
                estado);
        return asistenciaMapper.toDTOList(asistencias);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsistenciaDTO> obtenerPorUsuario(Long usuarioId) {
        log.debug("Obteniendo asistencias por usuario ID: {}", usuarioId);

        List<Asistencia> asistencias = asistenciaRepository.findByUsuarioIdOrderByFechaRegistroDesc(usuarioId);
        return asistenciaMapper.toDTOList(asistencias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AsistenciaDTO> obtenerPorUsuarioPaginadas(Long usuarioId, Pageable pageable) {
        log.debug("Obteniendo asistencias por usuario ID: {} paginadas: {}", usuarioId, pageable);

        Page<Asistencia> asistencias = asistenciaRepository.findByUsuarioIdOrderByFechaRegistroDesc(usuarioId,
                pageable);
        return asistencias.map(asistenciaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AsistenciaDTO> obtenerPorUsuarioYEstado(Long usuarioId, Asistencia.EstadoAsistencia estado) {
        log.debug("Obteniendo asistencias por usuario ID: {} y estado: {}", usuarioId, estado);

        List<Asistencia> asistencias = asistenciaRepository.findByUsuarioIdAndEstadoOrderByFechaRegistroDesc(usuarioId,
                estado);
        return asistenciaMapper.toDTOList(asistencias);
    }

    @Override
    public AsistenciaDTO registrarAsistencia(Long usuarioId, Long eventoId, String observaciones) {
        log.debug("Registrando asistencia para usuario ID: {} en evento ID: {}", usuarioId, eventoId);

        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con ID: " + usuarioId));

        Evento evento = eventoRepository.findById(eventoId)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + eventoId));

        // Validaciones
        if (yaEstaRegistrado(usuarioId, eventoId)) {
            throw new IllegalArgumentException("El usuario ya está registrado para este evento");
        }

        if (!puedeRegistrarse(usuarioId, eventoId)) {
            throw new IllegalArgumentException("No se puede registrar para este evento");
        }

        Asistencia asistencia = Asistencia.builder()
                .usuario(usuario)
                .evento(evento)
                .estado(Asistencia.EstadoAsistencia.CONFIRMADO)
                .observaciones(observaciones)
                .build();

        Asistencia asistenciaGuardada = asistenciaRepository.save(asistencia);

        log.info("Asistencia registrada exitosamente para usuario: {} en evento: {}",
                usuario.getUsername(), evento.getTitulo());

        return asistenciaMapper.toDTO(asistenciaGuardada);
    }

    @Override
    public void confirmarAsistencia(Long id) {
        log.debug("Confirmando asistencia ID: {}", id);

        Asistencia asistencia = asistenciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Asistencia no encontrada con ID: " + id));

        asistencia.setEstado(Asistencia.EstadoAsistencia.CONFIRMADO);
        asistenciaRepository.save(asistencia);

        log.info("Asistencia confirmada exitosamente con ID: {}", id);
    }

    @Override
    public void cancelarAsistencia(Long id) {
        log.debug("Cancelando asistencia ID: {}", id);

        Asistencia asistencia = asistenciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Asistencia no encontrada con ID: " + id));

        asistencia.setEstado(Asistencia.EstadoAsistencia.CANCELADO);
        asistenciaRepository.save(asistencia);

        log.info("Asistencia cancelada exitosamente con ID: {}", id);
    }

    @Override
    public void marcarComoAsistio(Long id) {
        log.debug("Marcando como asistió la asistencia ID: {}", id);

        Asistencia asistencia = asistenciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Asistencia no encontrada con ID: " + id));

        asistencia.setEstado(Asistencia.EstadoAsistencia.ASISTIO);
        asistenciaRepository.save(asistencia);

        log.info("Asistencia marcada como asistió con ID: {}", id);
    }

    @Override
    public void marcarComoNoAsistio(Long id) {
        log.debug("Marcando como no asistió la asistencia ID: {}", id);

        Asistencia asistencia = asistenciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Asistencia no encontrada con ID: " + id));

        asistencia.setEstado(Asistencia.EstadoAsistencia.NO_ASISTIO);
        asistenciaRepository.save(asistencia);

        log.info("Asistencia marcada como no asistió con ID: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean yaEstaRegistrado(Long usuarioId, Long eventoId) {
        return asistenciaRepository.existsByUsuarioIdAndEventoId(usuarioId, eventoId);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean puedeRegistrarse(Long usuarioId, Long eventoId) {
        Evento evento = eventoRepository.findById(eventoId)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + eventoId));

        // Verificar que el evento esté activo
        if (!evento.isActivo()) {
            return false;
        }

        // Verificar que el evento no haya comenzado
        if (evento.getFechaInicio().isBefore(LocalDateTime.now())) {
            return false;
        }

        // Verificar capacidad disponible
        if (evento.getCapacidad() != null) {
            long asistenciasConfirmadas = contarPorEventoYEstado(eventoId, Asistencia.EstadoAsistencia.CONFIRMADO);
            if (asistenciasConfirmadas >= evento.getCapacidad()) {
                return false;
            }
        }

        return true;
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorEvento(Long eventoId) {
        return asistenciaRepository.countByEventoId(eventoId);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorEventoYEstado(Long eventoId, Asistencia.EstadoAsistencia estado) {
        return asistenciaRepository.countByEventoIdAndEstado(eventoId, estado);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorUsuario(Long usuarioId) {
        return asistenciaRepository.countByUsuarioId(usuarioId);
    }

    @Override
    @Transactional(readOnly = true)
    public double calcularPorcentajeAsistencia(Long eventoId) {
        long totalConfirmados = contarPorEventoYEstado(eventoId, Asistencia.EstadoAsistencia.CONFIRMADO);
        long totalAsistieron = asistenciaRepository.countActualAttendancesByEvento(eventoId);

        if (totalConfirmados == 0) {
            return 0.0;
        }

        return (double) totalAsistieron / totalConfirmados * 100.0;
    }
}
