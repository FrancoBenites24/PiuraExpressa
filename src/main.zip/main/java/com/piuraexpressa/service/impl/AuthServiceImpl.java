package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.LoginDTO;
import com.piuraexpressa.dto.RegistroDTO;
import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.UsuarioMapper;
import com.piuraexpressa.model.Rol;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.RolRepository;
import com.piuraexpressa.repository.UsuarioRepository;
import com.piuraexpressa.service.AuthService;
import com.piuraexpressa.service.ImagenService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Set;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class AuthServiceImpl implements AuthService {

    private final UsuarioRepository usuarioRepository;
    private final RolRepository rolRepository;
    private final UsuarioMapper usuarioMapper;
    private final PasswordEncoder passwordEncoder;
    private final AuthenticationManager authenticationManager;
    private final ImagenService imagenService;

    @Override
    public UsuarioDTO login(LoginDTO loginDTO) {
        log.debug("Intentando login para usuario: {}", loginDTO.getUsername());

        try {
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginDTO.getUsername(),
                            loginDTO.getPassword()));

            SecurityContextHolder.getContext().setAuthentication(authentication);

            Usuario usuario = usuarioRepository.findByUsernameAndActivoTrue(loginDTO.getUsername())
                    .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado"));

            log.info("Login exitoso para usuario: {}", usuario.getUsername());
            return usuarioMapper.toDTO(usuario);

        } catch (Exception e) {
            log.error("Error en login para usuario {}: {}", loginDTO.getUsername(), e.getMessage());
            throw new IllegalArgumentException("Credenciales inválidas");
        }
    }

    @Override
    public void logout() {
        log.debug("Cerrando sesión");
        SecurityContextHolder.clearContext();
    }

    @Override
    public UsuarioDTO registrar(RegistroDTO registroDTO) {
        log.debug("Registrando nuevo usuario: {}", registroDTO.getUsername());

        // Validaciones
        if (existeEmail(registroDTO.getEmail())) {
            throw new IllegalArgumentException("El email ya está registrado");
        }

        if (existeUsername(registroDTO.getUsername())) {
            throw new IllegalArgumentException("El username ya está en uso");
        }

        if (existeDocumento(registroDTO.getNumeroDocumento())) {
            throw new IllegalArgumentException("El número de documento ya está registrado");
        }

        // Obtener rol USER por defecto
        Rol rolUser = rolRepository.findByNombre("USER")
                .orElseThrow(() -> new ResourceNotFoundException("Rol USER no encontrado"));

        // Crear usuario
        Usuario usuario = Usuario.builder()
                .email(registroDTO.getEmail())
                .username(registroDTO.getUsername())
                .password(passwordEncoder.encode(registroDTO.getPassword()))
                .nombres(registroDTO.getNombres())
                .apellidos(registroDTO.getApellidos())
                .tipoDocumento(registroDTO.getTipoDocumento())
                .numeroDocumento(registroDTO.getNumeroDocumento())
                .telefono(registroDTO.getTelefono())
                .fechaNacimiento(registroDTO.getFechaNacimiento())
                .provincia(registroDTO.getProvincia())
                .distrito(registroDTO.getDistrito())
                .direccion(registroDTO.getDireccion())
                .activo(true)
                .roles(Set.of(rolUser))
                .build();

        Usuario usuarioGuardado = usuarioRepository.save(usuario);

        log.info("Usuario registrado exitosamente: {}", usuarioGuardado.getUsername());
        return usuarioMapper.toDTO(usuarioGuardado);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existeEmail(String email) {
        return usuarioRepository.existsByEmailIgnoreCase(email);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existeUsername(String username) {
        return usuarioRepository.existsByUsernameIgnoreCase(username);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existeDocumento(String numeroDocumento) {
        return usuarioRepository.existsByNumeroDocumento(numeroDocumento);
    }

    @Override
    public void cambiarContrasena(Long usuarioId, String contrasenaActual, String nuevaContrasena) {
        log.debug("Cambiando contraseña para usuario ID: {}", usuarioId);

        Usuario usuario = usuarioRepository.findById(usuarioId)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con ID: " + usuarioId));

        if (!passwordEncoder.matches(contrasenaActual, usuario.getPassword())) {
            throw new IllegalArgumentException("La contraseña actual es incorrecta");
        }

        usuario.setPassword(passwordEncoder.encode(nuevaContrasena));
        usuarioRepository.save(usuario);

        log.info("Contraseña cambiada exitosamente para usuario: {}", usuario.getUsername());
    }

    @Override
    public void solicitarRecuperacionContrasena(String email) {
        log.debug("Solicitando recuperación de contraseña para email: {}", email);

        Usuario usuario = usuarioRepository.findByEmailIgnoreCaseAndActivoTrue(email)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con email: " + email));

        // TODO: Implementar envío de email con token de recuperación
        // String token = generateRecoveryToken();
        // emailService.enviarEmailRecuperacion(usuario.getEmail(), token);

        log.info("Solicitud de recuperación enviada para: {}", email);
    }

    @Override
    public void recuperarContrasena(String token, String nuevaContrasena) {
        log.debug("Recuperando contraseña con token");

        // TODO: Implementar validación de token y recuperación
        // Usuario usuario = validateRecoveryToken(token);
        // usuario.setPassword(passwordEncoder.encode(nuevaContrasena));
        // usuarioRepository.save(usuario);

        log.info("Contraseña recuperada exitosamente");
    }

    @Override
    public void enviarEmailActivacion(String email) {
        log.debug("Enviando email de activación para: {}", email);

        Usuario usuario = usuarioRepository.findByEmailIgnoreCase(email)
                .orElseThrow(() -> new ResourceNotFoundException("Usuario no encontrado con email: " + email));

        // TODO: Implementar envío de email de activación
        // String token = generateActivationToken();
        // emailService.enviarEmailActivacion(usuario.getEmail(), token);

        log.info("Email de activación enviado para: {}", email);
    }

    @Override
    public void activarCuenta(String token) {
        log.debug("Activando cuenta con token");

        // TODO: Implementar validación de token y activación
        // Usuario usuario = validateActivationToken(token);
        // usuario.setActivo(true);
        // usuarioRepository.save(usuario);

        log.info("Cuenta activada exitosamente");
    }

    @Override
    @Transactional(readOnly = true)
    public UsuarioDTO obtenerUsuarioActual() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();

        // ✅ Debug para verificar autenticación
        log.debug("🔍 Authentication: {}", authentication);
        log.debug("🔍 Principal: {}", authentication != null ? authentication.getPrincipal() : "null");
        log.debug("🔍 Name: {}", authentication != null ? authentication.getName() : "null");
        log.debug("🔍 Is Authenticated: {}", authentication != null ? authentication.isAuthenticated() : false);

        if (authentication == null || !authentication.isAuthenticated() ||
                "anonymousUser".equals(authentication.getPrincipal())) {
            log.warn("⚠️ Usuario no autenticado o anónimo");
            return null;
        }

        String username = authentication.getName();
        log.debug("🔍 Buscando usuario con username: {}", username);

        Usuario usuario = usuarioRepository.findByUsernameAndActivoTrue(username)
                .orElse(null);

        if (usuario == null) {
            log.warn("⚠️ Usuario no encontrado en BD: {}", username);
            return null;
        }

        log.debug("✅ Usuario encontrado: ID={}, Username={}", usuario.getId(), usuario.getUsername());

        UsuarioDTO dto = usuarioMapper.toDTO(usuario);

        // 🔥 Agregar imagen de perfil
        String urlImagen = imagenService.obtenerUrlImagenPerfil(usuario.getId());
        dto.setImagenPerfil(urlImagen);

        return dto;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean estaAutenticado() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null &&
                authentication.isAuthenticated() &&
                !"anonymousUser".equals(authentication.getPrincipal());
    }

    @Override
    @Transactional(readOnly = true)
    public boolean tieneRol(String rol) {
        UsuarioDTO usuario = obtenerUsuarioActual();
        return usuario != null && usuario.getRoles().stream()
                .anyMatch(r -> r.getNombre().equals(rol));
    }
}
