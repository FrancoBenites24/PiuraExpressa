package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.ComentarioDTO;
import com.piuraexpressa.model.Comentario;
import com.piuraexpressa.model.Publicacion;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.ComentarioRepository;
import com.piuraexpressa.repository.PublicacionRepository;
import com.piuraexpressa.repository.UsuarioRepository;
import com.piuraexpressa.service.ComentarioService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class ComentarioServiceImpl implements ComentarioService {

    private final ComentarioRepository comentarioRepository;
    private final PublicacionRepository publicacionRepository;
    private final UsuarioRepository usuarioRepository;

    @Override
    public List<ComentarioDTO> obtenerComentariosPorPublicacion(Long publicacionId) {
        Publicacion publicacion = publicacionRepository.findById(publicacionId)
                .orElseThrow(() -> new RuntimeException("Publicación no encontrada"));
        List<Comentario> comentarios = comentarioRepository.findByPublicacionOrderByFechaCreacionAsc(publicacion);
        return comentarios.stream()
                .map(this::mapearConExtras)
                .collect(Collectors.toList());
    }

    @Override
    public ComentarioDTO crearComentario(Long publicacionId, String contenido, String username) {
        Publicacion publicacion = publicacionRepository.findById(publicacionId)
                .orElseThrow(() -> new RuntimeException("Publicación no encontrada"));
        Usuario usuario = usuarioRepository.findByUsernameAndActivoTrue(username)
                .orElseThrow(() -> new RuntimeException("Usuario no encontrado"));

        Comentario comentario = new Comentario();
        comentario.setContenido(contenido);
        comentario.setPublicacion(publicacion);
        comentario.setUsuario(usuario);
        comentario.setFechaCreacion(LocalDateTime.now());

        Comentario guardado = comentarioRepository.save(comentario);
        return mapearConExtras(guardado);
    }

    @Override
    public Page<ComentarioDTO> obtenerTodosPaginados(Pageable pageable) {
        Page<Comentario> comentariosPage = comentarioRepository.findAll(pageable);
        return comentariosPage.map(this::mapearConExtras);
    }

    private ComentarioDTO mapearConExtras(Comentario comentario) {
        return ComentarioDTO.builder()
                .id(comentario.getId())
                .contenido(comentario.getContenido())
                .usuarioNombre(comentario.getUsuario().getNombres())
                .tiempoTranscurrido(obtenerTiempoTranscurrido(comentario.getFechaCreacion()))
                .publicacionId(comentario.getPublicacion().getId())
                .build();
    }

    private String obtenerTiempoTranscurrido(LocalDateTime fecha) {
        Duration duracion = Duration.between(fecha, LocalDateTime.now());
        if (duracion.toMinutes() < 60)
            return duracion.toMinutes() + " min";
        if (duracion.toHours() < 24)
            return duracion.toHours() + " h";
        return duracion.toDays() + " d";
    }
}
