package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.EstadisticaProvinciaDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.EstadisticaProvinciaMapper;
import com.piuraexpressa.model.EstadisticaProvincia;
import com.piuraexpressa.model.Provincia;
import com.piuraexpressa.repository.EstadisticaProvinciaRepository;
import com.piuraexpressa.repository.ProvinciaRepository;
import com.piuraexpressa.service.EstadisticaProvinciaService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Year;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class EstadisticaProvinciaServiceImpl implements EstadisticaProvinciaService {

    private final EstadisticaProvinciaRepository estadisticaRepository;
    private final ProvinciaRepository provinciaRepository;
    private final EstadisticaProvinciaMapper estadisticaMapper;

    @Override
    @Transactional(readOnly = true)
    public List<EstadisticaProvinciaDTO> obtenerTodas() {
        log.debug("Obteniendo todas las estadísticas de provincias");
        List<EstadisticaProvincia> estadisticas = estadisticaRepository.findAll();
        return estadisticaMapper.toDTOList(estadisticas);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EstadisticaProvinciaDTO> obtenerPorId(Long id) {
        log.debug("Obteniendo estadística por ID: {}", id);
        return estadisticaRepository.findById(id)
                .map(estadisticaMapper::toDTO);
    }

    @Override
    public EstadisticaProvinciaDTO guardar(EstadisticaProvinciaDTO estadisticaDTO) {
        log.debug("Guardando nueva estadística para provincia ID: {}", estadisticaDTO.getProvinciaId());
        
        // Validar que la provincia existe
        Provincia provincia = provinciaRepository.findById(estadisticaDTO.getProvinciaId())
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + estadisticaDTO.getProvinciaId()));

        // Validar que no existe estadística para el mismo año
        if (existePorProvinciaYAno(estadisticaDTO.getProvinciaId(), estadisticaDTO.getAnoActualizacion())) {
            throw new IllegalArgumentException("Ya existe una estadística para la provincia " + 
                    provincia.getNombre() + " en el año " + estadisticaDTO.getAnoActualizacion());
        }

        EstadisticaProvincia estadistica = estadisticaMapper.toEntity(estadisticaDTO);
        estadistica.setProvincia(provincia);
        
        EstadisticaProvincia estadisticaGuardada = estadisticaRepository.save(estadistica);
        
        log.info("Estadística guardada exitosamente para provincia: {} año: {}", 
                provincia.getNombre(), estadisticaGuardada.getAnoActualizacion());
        
        return estadisticaMapper.toDTO(estadisticaGuardada);
    }

    @Override
    public EstadisticaProvinciaDTO actualizar(Long id, EstadisticaProvinciaDTO estadisticaDTO) {
        log.debug("Actualizando estadística ID: {}", id);
        
        EstadisticaProvincia estadisticaExistente = estadisticaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Estadística no encontrada con ID: " + id));

        // Validar provincia si cambió
        if (!estadisticaExistente.getProvincia().getId().equals(estadisticaDTO.getProvinciaId())) {
            Provincia nuevaProvincia = provinciaRepository.findById(estadisticaDTO.getProvinciaId())
                    .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + estadisticaDTO.getProvinciaId()));
            estadisticaExistente.setProvincia(nuevaProvincia);
        }

        estadisticaMapper.updateEntityFromDTO(estadisticaDTO, estadisticaExistente);
        EstadisticaProvincia estadisticaActualizada = estadisticaRepository.save(estadisticaExistente);
        
        log.info("Estadística actualizada exitosamente para provincia: {} año: {}", 
                estadisticaActualizada.getProvincia().getNombre(), estadisticaActualizada.getAnoActualizacion());
        
        return estadisticaMapper.toDTO(estadisticaActualizada);
    }

    @Override
    public void eliminar(Long id) {
        log.debug("Eliminando estadística ID: {}", id);
        
        if (!estadisticaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Estadística no encontrada con ID: " + id);
        }

        estadisticaRepository.deleteById(id);
        log.info("Estadística eliminada exitosamente con ID: {}", id);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadisticaProvinciaDTO> obtenerPorProvincia(Long provinciaId) {
        log.debug("Obteniendo estadísticas por provincia ID: {}", provinciaId);
        
        List<EstadisticaProvincia> estadisticas = estadisticaRepository
                .findByProvinciaIdOrderByAnoActualizacionDesc(provinciaId);
        return estadisticaMapper.toDTOList(estadisticas);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EstadisticaProvinciaDTO> obtenerMasRecientePorProvincia(Long provinciaId) {
        log.debug("Obteniendo estadística más reciente por provincia ID: {}", provinciaId);
        
        return estadisticaRepository.findFirstByProvinciaIdOrderByAnoActualizacionDesc(provinciaId)
                .map(estadisticaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadisticaProvinciaDTO> obtenerPorAno(Year ano) {
        log.debug("Obteniendo estadísticas por año: {}", ano);
        
        List<EstadisticaProvincia> estadisticas = estadisticaRepository
                .findByAnoActualizacionOrderByProvinciaIdAsc(ano);
        return estadisticaMapper.toDTOList(estadisticas);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EstadisticaProvinciaDTO> obtenerPorProvinciaYAno(Long provinciaId, Year ano) {
        log.debug("Obteniendo estadística por provincia ID: {} y año: {}", provinciaId, ano);
        
        return estadisticaRepository.findByProvinciaIdAndAnoActualizacion(provinciaId, ano)
                .map(estadisticaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadisticaProvinciaDTO> obtenerRankingPorPoblacion(Year ano) {
        log.debug("Obteniendo ranking por población para año: {}", ano);
        
        List<EstadisticaProvincia> estadisticas = estadisticaRepository.findByAnoOrderByPoblacion(ano);
        return estadisticaMapper.toDTOList(estadisticas);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EstadisticaProvinciaDTO> obtenerRankingPorPib(Year ano) {
        log.debug("Obteniendo ranking por PIB para año: {}", ano);
        
        List<EstadisticaProvincia> estadisticas = estadisticaRepository.findByAnoOrderByPib(ano);
        return estadisticaMapper.toDTOList(estadisticas);
    }

    @Override
    @Transactional(readOnly = true)
    public Double obtenerPromedioPoblacion(Year ano) {
        log.debug("Obteniendo promedio de población para año: {}", ano);
        
        return estadisticaRepository.getPromedioPoblacion(ano);
    }

    @Override
    @Transactional(readOnly = true)
    public Double obtenerPromedioPib(Year ano) {
        log.debug("Obteniendo promedio de PIB para año: {}", ano);
        
        return estadisticaRepository.getPromedioPib(ano);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existePorProvinciaYAno(Long provinciaId, Year ano) {
        return estadisticaRepository.existsByProvinciaIdAndAnoActualizacion(provinciaId, ano);
    }

    @Override
    public EstadisticaProvinciaDTO crearEstadisticaActual(Long provinciaId) {
        log.debug("Creando estadística actual para provincia ID: {}", provinciaId);
        
        Provincia provincia = provinciaRepository.findById(provinciaId)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + provinciaId));

        Year anoActual = Year.now();
        
        // Verificar si ya existe estadística para el año actual
        if (existePorProvinciaYAno(provinciaId, anoActual)) {
            throw new IllegalArgumentException("Ya existe una estadística para la provincia " + 
                    provincia.getNombre() + " en el año " + anoActual);
        }

        EstadisticaProvincia estadistica = EstadisticaProvincia.builder()
                .provincia(provincia)
                .anoActualizacion(anoActual)
                .build();

        // Calcular estadísticas automáticas
        actualizarDatosAutomaticos(estadistica);

        EstadisticaProvincia estadisticaGuardada = estadisticaRepository.save(estadistica);
        
        log.info("Estadística actual creada para provincia: {}", provincia.getNombre());
        
        return estadisticaMapper.toDTO(estadisticaGuardada);
    }

    @Override
    public void actualizarEstadisticasAutomaticas(Long provinciaId) {
        log.debug("Actualizando estadísticas automáticas para provincia ID: {}", provinciaId);
        
        Optional<EstadisticaProvincia> estadisticaOpt = estadisticaRepository
                .findFirstByProvinciaIdOrderByAnoActualizacionDesc(provinciaId);

        if (estadisticaOpt.isPresent()) {
            EstadisticaProvincia estadistica = estadisticaOpt.get();
            actualizarDatosAutomaticos(estadistica);
            estadisticaRepository.save(estadistica);
            
            log.info("Estadísticas automáticas actualizadas para provincia: {}", 
                    estadistica.getProvincia().getNombre());
        } else {
            log.warn("No se encontró estadística para actualizar en provincia ID: {}", provinciaId);
        }
    }

    private void actualizarDatosAutomaticos(EstadisticaProvincia estadistica) {
        Provincia provincia = estadistica.getProvincia();
        
        // Contar puntos de interés por tipo
        long hoteles = provincia.getPuntosInteres().stream()
                .filter(pi -> pi.getTipo() == com.piuraexpressa.model.PuntoInteres.TipoPuntoInteres.HOTEL && pi.isActivo())
                .count();
        
        long restaurantes = provincia.getPuntosInteres().stream()
                .filter(pi -> pi.getTipo() == com.piuraexpressa.model.PuntoInteres.TipoPuntoInteres.RESTAURANTE && pi.isActivo())
                .count();
        
        long atractivos = provincia.getPuntosInteres().stream()
                .filter(pi -> pi.getTipo() == com.piuraexpressa.model.PuntoInteres.TipoPuntoInteres.ATRACTIVO_TURISTICO && pi.isActivo())
                .count();

        // Contar eventos anuales (eventos activos)
        long eventos = provincia.getEventos().stream()
                .filter(e -> e.isActivo())
                .count();

        // Actualizar estadísticas
        estadistica.setHotelesRegistrados((int) hoteles);
        estadistica.setRestaurantesRegistrados((int) restaurantes);
        estadistica.setAtractivosTuristicos((int) atractivos);
        estadistica.setFestivalesAnuales((int) eventos);
        
        log.debug("Datos automáticos actualizados: hoteles={}, restaurantes={}, atractivos={}, eventos={}", 
                hoteles, restaurantes, atractivos, eventos);
    }
}
