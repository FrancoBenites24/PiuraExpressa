package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.EventoDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.EventoMapper;
import com.piuraexpressa.model.Asistencia;
import com.piuraexpressa.model.Evento;
import com.piuraexpressa.model.Provincia;
import com.piuraexpressa.repository.AsistenciaRepository;
import com.piuraexpressa.repository.EventoRepository;
import com.piuraexpressa.repository.ProvinciaRepository;
import com.piuraexpressa.service.EventoService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class EventoServiceImpl implements EventoService {

    private final EventoRepository eventoRepository;
    private final ProvinciaRepository provinciaRepository;
    private final EventoMapper eventoMapper;
    private final AsistenciaRepository asistenciaRepository;

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerTodos() {
        log.debug("Obteniendo todos los eventos");
        List<Evento> eventos = eventoRepository.findAll();
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EventoDTO> obtenerTodosPaginados(Pageable pageable) {
        log.debug("Obteniendo eventos paginados: {}", pageable);
        Page<Evento> eventos = eventoRepository.findAll(pageable);
        return eventos.map(eventoMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<EventoDTO> obtenerPorId(Long id) {
        log.debug("Obteniendo evento por ID: {}", id);
        return eventoRepository.findById(id)
                .map(eventoMapper::toDTO);
    }

    @Override
    public EventoDTO guardar(EventoDTO eventoDTO) {
        log.debug("Guardando nuevo evento: {}", eventoDTO.getTitulo());

        Provincia provincia = provinciaRepository.findById(eventoDTO.getProvinciaId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Provincia no encontrada con ID: " + eventoDTO.getProvinciaId()));

        Evento evento = eventoMapper.toEntity(eventoDTO);
        evento.setProvincia(provincia);

        Evento eventoGuardado = eventoRepository.save(evento);

        log.info("Evento guardado exitosamente: {} con ID: {}",
                eventoGuardado.getTitulo(), eventoGuardado.getId());

        return eventoMapper.toDTO(eventoGuardado);
    }

    @Override
    public EventoDTO actualizar(Long id, EventoDTO eventoDTO) {
        log.debug("Actualizando evento ID: {} con datos: {}", id, eventoDTO.getTitulo());

        Evento eventoExistente = eventoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + id));

        if (!eventoExistente.getProvincia().getId().equals(eventoDTO.getProvinciaId())) {
            Provincia nuevaProvincia = provinciaRepository.findById(eventoDTO.getProvinciaId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Provincia no encontrada con ID: " + eventoDTO.getProvinciaId()));
            eventoExistente.setProvincia(nuevaProvincia);
        }

        eventoMapper.updateEntityFromDTO(eventoDTO, eventoExistente);
        Evento eventoActualizado = eventoRepository.save(eventoExistente);

        log.info("Evento actualizado exitosamente: {} con ID: {}",
                eventoActualizado.getTitulo(), eventoActualizado.getId());

        return eventoMapper.toDTO(eventoActualizado);
    }

    @Override
    public void eliminar(Long id) {
        log.debug("Eliminando evento ID: {}", id);

        if (!eventoRepository.existsById(id)) {
            throw new ResourceNotFoundException("Evento no encontrado con ID: " + id);
        }

        eventoRepository.deleteById(id);
        log.info("Evento eliminado exitosamente con ID: {}", id);
    }

    @Override
    public void activar(Long id) {
        log.debug("Activando evento ID: {}", id);

        Evento evento = eventoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + id));

        evento.setActivo(true);
        eventoRepository.save(evento);

        log.info("Evento activado exitosamente: {}", evento.getTitulo());
    }

    @Override
    public void desactivar(Long id) {
        log.debug("Desactivando evento ID: {}", id);

        Evento evento = eventoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + id));

        evento.setActivo(false);
        eventoRepository.save(evento);

        log.info("Evento desactivado exitosamente: {}", evento.getTitulo());
    }

    // métodos faltantes en EventoServiceImpl

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerTodosActivos() {
        log.debug("Obteniendo todos los eventos activos");
        List<Evento> eventos = eventoRepository.findByActivoTrueOrderByFechaInicioAsc();
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EventoDTO> obtenerEventosPorUsuarioPaginadas(Long usuarioId, Pageable pageable) {
        log.debug("Obteniendo eventos por usuario ID: {}", usuarioId);

        // Obtener asistencias del usuario
        Page<Asistencia> asistencias = asistenciaRepository.findByUsuarioIdOrderByFechaRegistroDesc(usuarioId,
                pageable);

        // Obtener eventos a partir de las asistencias
        List<Evento> eventos = asistencias.stream()
                .map(Asistencia::getEvento) // Obtiene el evento de la asistencia
                .distinct() // Elimina eventos repetidos
                .collect(Collectors.toList());

        // Convertir la lista de eventos a un Page<Evento>
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), eventos.size());
        Page<Evento> eventoPage = new PageImpl<>(eventos.subList(start, end), pageable, eventos.size());

        return eventoPage.map(eventoMapper::toDTO);
    }

    // método obtenerPorProvincia
    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerPorProvincia(Long provinciaId) {
        log.debug("Obteniendo eventos por provincia ID: {}", provinciaId);
        // ✅ Usar el método sin Pageable
        List<Evento> eventos = eventoRepository.findByProvinciaIdOrderByFechaInicioAsc(provinciaId);
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EventoDTO> obtenerPorProvinciaPaginados(Long provinciaId, Pageable pageable) {
        log.debug("Obteniendo eventos por provincia ID: {} paginados: {}", provinciaId, pageable);

        Page<Evento> eventos = eventoRepository.findByProvinciaIdOrderByFechaInicioAsc(provinciaId, pageable);
        return eventos.map(eventoMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerActivosPorProvincia(Long provinciaId) {
        log.debug("Obteniendo eventos activos por provincia ID: {}", provinciaId);

        List<Evento> eventos = eventoRepository.findByProvinciaIdAndActivoTrueOrderByFechaInicioAsc(provinciaId);
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerProximos(int limite) {
        log.debug("Obteniendo próximos {} eventos", limite);

        Pageable pageable = PageRequest.of(0, limite);
        LocalDateTime ahora = LocalDateTime.now();
        List<Evento> eventos = eventoRepository.findProximosEventos(ahora, pageable);
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerPorRangoFechas(LocalDateTime fechaInicio, LocalDateTime fechaFin) {
        log.debug("Obteniendo eventos entre {} y {}", fechaInicio, fechaFin);

        List<Evento> eventos = eventoRepository.findByFechaInicioBetweenAndActivoTrueOrderByFechaInicioAsc(fechaInicio,
                fechaFin);
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerPorProvinciaYRangoFechas(Long provinciaId, LocalDateTime fechaInicio,
            LocalDateTime fechaFin) {
        log.debug("Obteniendo eventos por provincia ID: {} entre {} y {}", provinciaId, fechaInicio, fechaFin);

        List<Evento> eventos = eventoRepository.findByProvinciaIdAndFechaInicioBetween(provinciaId, fechaInicio,
                fechaFin);
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerDestacados() {
        log.debug("Obteniendo eventos destacados");

        List<Evento> eventos = eventoRepository.findDestacados();
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EventoDTO> obtenerGratuitos() {
        log.debug("Obteniendo eventos gratuitos");

        List<Evento> eventos = eventoRepository.findGratuitos();
        return eventoMapper.toDTOList(eventos);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<EventoDTO> buscarPorTexto(String searchTerm, Pageable pageable) {
        log.debug("Buscando eventos por texto: '{}' paginado: {}", searchTerm, pageable);

        Page<Evento> eventos = eventoRepository.findBySearchTerm(searchTerm, pageable);
        return eventos.map(eventoMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorProvincia(Long provinciaId) {
        return eventoRepository.countByProvinciaId(provinciaId);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarActivosPorProvincia(Long provinciaId) {
        return eventoRepository.countByProvinciaIdAndActivoTrue(provinciaId);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarProximos() {
        LocalDateTime ahora = LocalDateTime.now();
        return eventoRepository.countProximosEventos(ahora);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean estaDisponible(Long eventoId) {
        log.debug("Verificando disponibilidad del evento ID: {}", eventoId);

        Evento evento = eventoRepository.findById(eventoId)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + eventoId));

        LocalDateTime ahora = LocalDateTime.now();
        return evento.isActivo() &&
                evento.getFechaInicio().isAfter(ahora) &&
                (evento.getCapacidad() == null || calcularCapacidadDisponible(eventoId) > 0);
    }

    @Override
    @Transactional(readOnly = true)
    public int calcularCapacidadDisponible(Long eventoId) {
        log.debug("Calculando capacidad disponible para evento ID: {}", eventoId);

        Evento evento = eventoRepository.findById(eventoId)
                .orElseThrow(() -> new ResourceNotFoundException("Evento no encontrado con ID: " + eventoId));

        if (evento.getCapacidad() == null) {
            return Integer.MAX_VALUE; // Capacidad ilimitada
        }

        long asistenciasConfirmadas = eventoRepository.countAsistenciasConfirmadas(eventoId);
        return Math.max(0, evento.getCapacidad() - (int) asistenciasConfirmadas);
    }
}
