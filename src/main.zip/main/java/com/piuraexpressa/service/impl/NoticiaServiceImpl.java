package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.NoticiaDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.NoticiaMapper;
import com.piuraexpressa.model.Noticia;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.NoticiaRepository;
import com.piuraexpressa.repository.UsuarioRepository;
import com.piuraexpressa.service.NoticiaService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class NoticiaServiceImpl implements NoticiaService {

    private final NoticiaRepository noticiaRepository;
    private final UsuarioRepository usuarioRepository;
    private final NoticiaMapper noticiaMapper;

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerTodas() {
        log.debug("Obteniendo todas las noticias");
        List<Noticia> noticias = noticiaRepository.findAll();
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> obtenerTodasPaginadas(Pageable pageable) {
        log.debug("Obteniendo noticias paginadas: {}", pageable);
        Page<Noticia> noticias = noticiaRepository.findAll(pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<NoticiaDTO> obtenerPorId(Long id) {
        log.debug("Obteniendo noticia por ID: {}", id);
        return noticiaRepository.findById(id)
                .map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<NoticiaDTO> obtenerPorSlug(String slug) {
        log.debug("Obteniendo noticia por slug: {}", slug);
        return noticiaRepository.findBySlugAndActivaTrue(slug)
                .map(noticiaMapper::toDTO);
    }

    @Override
    public NoticiaDTO guardar(NoticiaDTO noticiaDTO) {
        log.debug("Guardando nueva noticia: {}", noticiaDTO.getTitulo());

        Usuario autor = usuarioRepository.findById(noticiaDTO.getAutorId())
                .orElseThrow(
                        () -> new ResourceNotFoundException("Autor no encontrado con ID: " + noticiaDTO.getAutorId()));

        // Generar slug si no existe
        if (noticiaDTO.getSlug() == null || noticiaDTO.getSlug().isEmpty()) {
            noticiaDTO.setSlug(generarSlug(noticiaDTO.getTitulo()));
        }

        // Validar slug único
        if (existeSlug(noticiaDTO.getSlug())) {
            noticiaDTO.setSlug(noticiaDTO.getSlug() + "-" + System.currentTimeMillis());
        }

        Noticia noticia = noticiaMapper.toEntity(noticiaDTO);
        noticia.setAutor(autor);

        Noticia noticiaGuardada = noticiaRepository.save(noticia);

        log.info("Noticia guardada exitosamente: {} con ID: {}",
                noticiaGuardada.getTitulo(), noticiaGuardada.getId());

        return noticiaMapper.toDTO(noticiaGuardada);
    }

    @Override
    public NoticiaDTO actualizar(Long id, NoticiaDTO noticiaDTO) {
        log.debug("Actualizando noticia ID: {} con datos: {}", id, noticiaDTO.getTitulo());

        Noticia noticiaExistente = noticiaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + id));

        // Validar autor si cambió
        if (!noticiaExistente.getAutor().getId().equals(noticiaDTO.getAutorId())) {
            Usuario nuevoAutor = usuarioRepository.findById(noticiaDTO.getAutorId())
                    .orElseThrow(() -> new ResourceNotFoundException(
                            "Autor no encontrado con ID: " + noticiaDTO.getAutorId()));
            noticiaExistente.setAutor(nuevoAutor);
        }

        // Validar slug único si cambió
        if (!noticiaExistente.getSlug().equals(noticiaDTO.getSlug())) {
            if (existeSlug(noticiaDTO.getSlug(), id)) {
                throw new IllegalArgumentException("Ya existe otra noticia con el slug: " + noticiaDTO.getSlug());
            }
        }

        noticiaMapper.updateEntityFromDTO(noticiaDTO, noticiaExistente);
        Noticia noticiaActualizada = noticiaRepository.save(noticiaExistente);

        log.info("Noticia actualizada exitosamente: {} con ID: {}",
                noticiaActualizada.getTitulo(), noticiaActualizada.getId());

        return noticiaMapper.toDTO(noticiaActualizada);
    }

    @Override
    public void eliminar(Long id) {
        log.debug("Eliminando noticia ID: {}", id);

        if (!noticiaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Noticia no encontrada con ID: " + id);
        }

        noticiaRepository.deleteById(id);
        log.info("Noticia eliminada exitosamente con ID: {}", id);
    }

    @Override
    public void activar(Long id) {
        log.debug("Activando noticia ID: {}", id);

        Noticia noticia = noticiaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + id));

        noticia.setActiva(true);
        noticiaRepository.save(noticia);

        log.info("Noticia activada exitosamente: {}", noticia.getTitulo());
    }

    @Override
    public void desactivar(Long id) {
        log.debug("Desactivando noticia ID: {}", id);

        Noticia noticia = noticiaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + id));

        noticia.setActiva(false);
        noticiaRepository.save(noticia);

        log.info("Noticia desactivada exitosamente: {}", noticia.getTitulo());
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerActivas() {
        log.debug("Obteniendo noticias activas");
        List<Noticia> noticias = noticiaRepository.findByActivaTrueOrderByFechaPublicacionDesc();
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> obtenerActivasPaginadas(Pageable pageable) {
        log.debug("Obteniendo noticias activas paginadas: {}", pageable);
        Page<Noticia> noticias = noticiaRepository.findByActivaTrueOrderByFechaPublicacionDesc(pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerDestacadas() {
        log.debug("Obteniendo noticias destacadas");
        List<Noticia> noticias = noticiaRepository.findByDestacadaTrueAndActivaTrueOrderByFechaPublicacionDesc();
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> obtenerDestacadasPaginadas(Pageable pageable) {
        log.debug("Obteniendo noticias destacadas paginadas: {}", pageable);
        Page<Noticia> noticias = noticiaRepository
                .findByDestacadaTrueAndActivaTrueOrderByFechaPublicacionDesc(pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerPorCategoria(Noticia.CategoriaNoticia categoria) {
        log.debug("Obteniendo noticias por categoría: {}", categoria);
        List<Noticia> noticias = noticiaRepository.findByCategoriaAndActivaTrueOrderByFechaPublicacionDesc(categoria);
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> obtenerPorCategoriaPaginadas(Noticia.CategoriaNoticia categoria, Pageable pageable) {
        log.debug("Obteniendo noticias por categoría: {} paginadas: {}", categoria, pageable);
        Page<Noticia> noticias = noticiaRepository.findByCategoriaAndActivaTrueOrderByFechaPublicacionDesc(categoria,
                pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerPorAutor(Long autorId) {
        log.debug("Obteniendo noticias por autor ID: {}", autorId);
        List<Noticia> noticias = noticiaRepository.findByAutorIdOrderByFechaPublicacionDesc(autorId);
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> obtenerPorAutorPaginadas(Long autorId, Pageable pageable) {
        log.debug("Obteniendo noticias por autor ID: {} paginadas: {}", autorId, pageable);
        Page<Noticia> noticias = noticiaRepository.findByAutorIdOrderByFechaPublicacionDesc(autorId, pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> buscarPorTexto(String searchTerm, Pageable pageable) {
        log.debug("Buscando noticias por texto: '{}' paginado: {}", searchTerm, pageable);
        Page<Noticia> noticias = noticiaRepository.findBySearchTerm(searchTerm, pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<NoticiaDTO> buscarPorTitulo(String titulo, Pageable pageable) {
        log.debug("Buscando noticias por título: '{}' paginado: {}", titulo, pageable);
        Page<Noticia> noticias = noticiaRepository.findByTituloContainingIgnoreCaseAndActivaTrue(titulo, pageable);
        return noticias.map(noticiaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerRelacionadas(Long noticiaId, int limite) {
        log.debug("Obteniendo noticias relacionadas para noticia ID: {}, límite: {}", noticiaId, limite);

        Noticia noticia = noticiaRepository.findById(noticiaId)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + noticiaId));

        Pageable pageable = PageRequest.of(0, limite);
        List<Noticia> noticias = noticiaRepository.findRelatedNews(noticia.getCategoria(), noticiaId, pageable);
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerRecientes(int limite) {
        log.debug("Obteniendo {} noticias recientes", limite);

        Pageable pageable = PageRequest.of(0, limite);
        List<Noticia> noticias = noticiaRepository.findRecentNews(pageable);
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public List<NoticiaDTO> obtenerMasVistas(int limite) {
        log.debug("Obteniendo {} noticias más vistas", limite);

        Pageable pageable = PageRequest.of(0, limite);
        List<Noticia> noticias = noticiaRepository.findMostViewed(pageable);
        return noticiaMapper.toDTOList(noticias);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarActivas() {
        return noticiaRepository.countByActivaTrue();
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorCategoria(Noticia.CategoriaNoticia categoria) {
        return noticiaRepository.countByCategoriaAndActivaTrue(categoria);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorAutor(Long autorId) {
        return noticiaRepository.countByAutorId(autorId);
    }

    @Override
    public void incrementarVistas(Long id) {
        log.debug("Incrementando vistas para noticia ID: {}", id);

        Noticia noticia = noticiaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + id));

        noticia.setVistas(noticia.getVistas() + 1);
        noticiaRepository.save(noticia);
    }

    @Override
    public void marcarComoDestacada(Long id) {
        log.debug("Marcando como destacada noticia ID: {}", id);

        Noticia noticia = noticiaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + id));

        noticia.setDestacada(true);
        noticiaRepository.save(noticia);

        log.info("Noticia marcada como destacada: {}", noticia.getTitulo());
    }

    @Override
    public void quitarDestacada(Long id) {
        log.debug("Quitando destacada de noticia ID: {}", id);

        Noticia noticia = noticiaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Noticia no encontrada con ID: " + id));

        noticia.setDestacada(false);
        noticiaRepository.save(noticia);

        log.info("Noticia ya no es destacada: {}", noticia.getTitulo());
    }

    @Override
    public String generarSlug(String titulo) {
        if (titulo == null || titulo.trim().isEmpty()) {
            return "noticia-" + System.currentTimeMillis();
        }

        return titulo.toLowerCase()
                .replaceAll("[^a-z0-9\\s-]", "")
                .replaceAll("\\s+", "-")
                .replaceAll("-+", "-")
                .replaceAll("^-|-$", "");
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existeSlug(String slug) {
        return noticiaRepository.existsBySlug(slug);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existeSlug(String slug, Long excludeId) {
        return noticiaRepository.existsBySlugAndIdNot(slug, excludeId);
    }
}
