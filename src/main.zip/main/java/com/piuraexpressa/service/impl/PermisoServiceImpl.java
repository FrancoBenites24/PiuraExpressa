package com.piuraexpressa.service.impl;

import com.piuraexpressa.model.Permiso;
import com.piuraexpressa.repository.PermisoRepository;
import com.piuraexpressa.service.PermisoService;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class PermisoServiceImpl implements PermisoService {

    private final PermisoRepository permisoRepositorio;

    @Override
    public Page<Permiso> listarTodos(Pageable pageable) {
        return permisoRepositorio.findAll(pageable);
    }

    @Override
    public Optional<Permiso> buscarPorId(Long id) {
        return permisoRepositorio.findById(id);
    }

    @Override
    public Optional<Permiso> buscarPorNombre(String nombre) {
        return permisoRepositorio.buscarPorNombre(nombre);
    }

    @Override
    public Permiso guardar(Permiso permiso) {
        return permisoRepositorio.save(permiso);
    }

    @Override
    public void eliminar(Long id) {
        permisoRepositorio.deleteById(id);
    }
}
