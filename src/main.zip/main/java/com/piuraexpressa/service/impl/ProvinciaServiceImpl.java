package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.*;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.ProvinciaMapper;
import com.piuraexpressa.mapper.PuntoInteresMapper;
import com.piuraexpressa.mapper.HistoriaProvinciaMapper;
import com.piuraexpressa.mapper.EstadisticaProvinciaMapper;
import org.springframework.beans.factory.annotation.Autowired;
import com.piuraexpressa.model.*;
import com.piuraexpressa.repository.*;
import com.piuraexpressa.service.ProvinciaService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class ProvinciaServiceImpl implements ProvinciaService {

    private final ProvinciaRepository provinciaRepository;
    private final ProvinciaMapper provinciaMapper;
    private final PuntoInteresRepository puntoInteresRepository;
    private final HistoriaProvinciaRepository historiaProvinciaRepository;
    private final EstadisticaProvinciaRepository estadisticaProvinciaRepository;

    @Autowired
    private PuntoInteresMapper puntoInteresMapper;

    @Autowired
    private HistoriaProvinciaMapper historiaProvinciaMapper;
    @Autowired
    private EstadisticaProvinciaMapper estadisticaProvinciaMapper;

    @Override
    @Transactional(readOnly = true)
    public boolean existeEventoHistoricoConTitulo(Long provinciaId, String titulo) {
        // Implement custom query using existing repository methods or JPQL
        return historiaProvinciaRepository.findByProvinciaIdAndActivoTrueOrderByOrdenCronologicoAsc(provinciaId)
                .stream()
                .anyMatch(h -> h.getTitulo().equalsIgnoreCase(titulo));
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existeEventoHistoricoConTituloExceptoId(Long provinciaId, String titulo, Long id) {
        return historiaProvinciaRepository.findByProvinciaIdAndActivoTrueOrderByOrdenCronologicoAsc(provinciaId)
                .stream()
                .anyMatch(h -> !h.getId().equals(id) && h.getTitulo().equalsIgnoreCase(titulo));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProvinciaDTO> obtenerTodas() {
        log.debug("Obteniendo todas las provincias");
        List<Provincia> provincias = provinciaRepository.findAll();
        return provinciaMapper.toDTOList(provincias);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProvinciaDTO> obtenerTodasPaginadas(Pageable pageable) {
        log.debug("Obteniendo provincias paginadas: {}", pageable);
        Page<Provincia> provincias = provinciaRepository.findAll(pageable);
        return provincias.map(provinciaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<ProvinciaDTO> buscarPaginadas(String search, String estado, Pageable pageable) {
        log.debug("Buscando provincias paginadas - búsqueda: {}, estado: {}, pageable: {}", search, estado, pageable);

        Page<Provincia> provincias;

        Boolean activa = null;
        if ("true".equals(estado)) {
            activa = true;
        } else if ("false".equals(estado)) {
            activa = false;
        }

        if (search != null && !search.trim().isEmpty() && activa != null) {
            provincias = provinciaRepository.findByNombreContainingIgnoreCaseAndActiva(search.trim(), activa, pageable);
        } else if (search != null && !search.trim().isEmpty()) {
            provincias = provinciaRepository.findByNombreContainingIgnoreCase(search.trim(), pageable);
        } else if (activa != null) {
            provincias = provinciaRepository.findByActiva(activa, pageable);
        } else {
            provincias = provinciaRepository.findAll(pageable);
        }

        return provincias.map(provinciaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProvinciaDTO> obtenerTodasActivas() {
        log.debug("Obteniendo provincias activas");
        List<Provincia> provincias = provinciaRepository.findByActivaTrueOrderByNombreAsc();
        return provinciaMapper.toDTOList(provincias);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerPorId(Long id) {
        log.debug("Obteniendo provincia por ID: {}", id);
        return provinciaRepository.findById(id)
                .map(provinciaMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerPorNombre(String nombre) {
        log.debug("Obteniendo provincia por nombre: {}", nombre);
        return provinciaRepository.findByNombreIgnoreCaseAndActivaTrue(nombre)
                .map(provinciaMapper::toDTO);
    }

    @Override
    public ProvinciaDTO guardar(ProvinciaDTO provinciaDTO) {
        log.debug("Guardando nueva provincia: {}", provinciaDTO.getNombre());

        if (existePorNombre(provinciaDTO.getNombre())) {
            throw new IllegalArgumentException("Ya existe una provincia con el nombre: " + provinciaDTO.getNombre());
        }

        Provincia provincia = provinciaMapper.toEntity(provinciaDTO);

        // Removed nested collections management; handled separately

        Provincia provinciaGuardada = provinciaRepository.save(provincia);

        log.info("Provincia guardada exitosamente: {} con ID: {}",
                provinciaGuardada.getNombre(), provinciaGuardada.getId());

        return provinciaMapper.toDTO(provinciaGuardada);
    }

    @Override
    public ProvinciaDTO actualizar(Long id, ProvinciaDTO provinciaDTO) {
        log.debug("Actualizando provincia ID: {} con datos: {}", id, provinciaDTO.getNombre());

        Provincia provinciaExistente = provinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + id));

        if (existePorNombre(provinciaDTO.getNombre(), id)) {
            throw new IllegalArgumentException("Ya existe otra provincia con el nombre: " + provinciaDTO.getNombre());
        }

        provinciaMapper.updateEntityFromDTO(provinciaDTO, provinciaExistente);

        // Removed nested collections management; handled separately

        Provincia provinciaActualizada = provinciaRepository.save(provinciaExistente);

        log.info("Provincia actualizada exitosamente: {} con ID: {}",
                provinciaActualizada.getNombre(), provinciaActualizada.getId());

        return provinciaMapper.toDTO(provinciaActualizada);
    }

    @Override
    public void eliminar(Long id) {
        log.debug("Eliminando provincia ID: {}", id);

        if (!provinciaRepository.existsById(id)) {
            throw new ResourceNotFoundException("Provincia no encontrada con ID: " + id);
        }

        provinciaRepository.deleteById(id);
        log.info("Provincia eliminada exitosamente con ID: {}", id);
    }

    @Override
    public void activar(Long id) {
        log.debug("Activando provincia ID: {}", id);

        Provincia provincia = provinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + id));

        provincia.setActiva(true);
        provinciaRepository.save(provincia);

        log.info("Provincia activada exitosamente: {}", provincia.getNombre());
    }

    @Override
    public void desactivar(Long id) {
        log.debug("Desactivando provincia ID: {}", id);

        Provincia provincia = provinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + id));

        provincia.setActiva(false);
        provinciaRepository.save(provincia);

        log.info("Provincia desactivada exitosamente: {}", provincia.getNombre());
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerConEstadisticas(Long id) {
        log.debug("Obteniendo provincia con estadísticas ID: {}", id);

        return provinciaRepository.findById(id)
                .map(provincia -> {
                    provincia.getEstadisticas().size();
                    return provinciaMapper.toDTO(provincia);
                });
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerConClima(Long id) {
        log.debug("Obteniendo provincia con clima ID: {}", id);

        return provinciaRepository.findById(id)
                .map(provincia -> {
                    if (provincia.getClima() != null) {
                        provincia.getClima().getTemperaturaActual();
                    }
                    return provinciaMapper.toDTO(provincia);
                });
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerConGaleria(Long id) {
        log.debug("Obteniendo provincia con galería ID: {}", id);

        return provinciaRepository.findById(id)
                .map(provincia -> {
                    provincia.getGaleria().size();
                    return provinciaMapper.toDTO(provincia);
                });
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerConPuntosInteres(Long id) {
        log.debug("Obteniendo provincia con puntos de interés ID: {}", id);

        return provinciaRepository.findById(id)
                .map(provincia -> {
                    provincia.getPuntosInteres().size();
                    return provinciaMapper.toDTO(provincia);
                });
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerConHistoria(Long id) {
        log.debug("Obteniendo provincia con historia ID: {}", id);

        return provinciaRepository.findById(id)
                .map(provincia -> {
                    provincia.getHistoria().size();
                    return provinciaMapper.toDTO(provincia);
                });
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<ProvinciaDTO> obtenerCompleta(Long id) {
        log.debug("Obteniendo provincia completa ID: {}", id);

        return provinciaRepository.findById(id)
                .map(provincia -> {
                    provincia.getEstadisticas().size();
                    provincia.getGaleria().size();
                    provincia.getPuntosInteres().size();
                    provincia.getHistoria().size();
                    provincia.getEventos().size();
                    provincia.getPlatos().size();
                    if (provincia.getClima() != null) {
                        provincia.getClima().getTemperaturaActual();
                    }
                    return provinciaMapper.toDTO(provincia);
                });
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProvinciaDTO> obtenerConEstadisticasActuales() {
        log.debug("Obteniendo provincias con estadísticas actuales");

        List<Provincia> provincias = provinciaRepository.findActivasWithLatestStats();
        return provinciaMapper.toDTOList(provincias);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ProvinciaDTO> obtenerPorCoordenadasCercanas(BigDecimal latitud, BigDecimal longitud, double radioKm) {
        log.debug("Obteniendo provincias cercanas a lat: {}, lng: {}, radio: {} km", latitud, longitud, radioKm);

        BigDecimal deltaGrados = BigDecimal.valueOf(radioKm / 111.0);
        BigDecimal latMin = latitud.subtract(deltaGrados);
        BigDecimal latMax = latitud.add(deltaGrados);
        BigDecimal lngMin = longitud.subtract(deltaGrados);
        BigDecimal lngMax = longitud.add(deltaGrados);

        List<Provincia> provincias = provinciaRepository.findByCoordinatesRange(latMin, latMax, lngMin, lngMax);
        return provinciaMapper.toDTOList(provincias);
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existePorNombre(String nombre) {
        return provinciaRepository.findByNombreIgnoreCaseAndActivaTrue(nombre).isPresent();
    }

    @Override
    @Transactional(readOnly = true)
    public boolean existePorNombre(String nombre, Long excludeId) {
        return provinciaRepository.existsByNombreIgnoreCaseAndIdNot(nombre, excludeId);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarActivas() {
        return provinciaRepository.countByActivaTrue();
    }

    @Override
    public void actualizarEstadisticas(Long provinciaId) {
        log.debug("Actualizando estadísticas para provincia ID: {}", provinciaId);

        Provincia provincia = provinciaRepository.findById(provinciaId)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + provinciaId));

        // Aquí se implementaría la lógica para actualizar estadísticas
        // Por ejemplo, contar puntos de interés, eventos, etc.

        log.info("Estadísticas actualizadas para provincia: {}", provincia.getNombre());
    }

    @Override
    public void actualizarClima(Long provinciaId) {
        log.debug("Actualizando clima para provincia ID: {}", provinciaId);

        Provincia provincia = provinciaRepository.findById(provinciaId)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + provinciaId));

        // Aquí se implementaría la lógica para actualizar datos climáticos
        // Por ejemplo, llamar a una API externa de clima

        log.info("Clima actualizado para provincia: {}", provincia.getNombre());
    }

    // GESTIONAR LOS PUNTOS DE INTERES DE LAS PROVINCIAS
    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerPuntosInteresPorProvincia(Long provinciaId) {
        List<PuntoInteres> puntos = puntoInteresRepository.findByProvinciaIdAndActivoTrueOrderByNombreAsc(provinciaId);
        return puntoInteresMapper.toDTOList(puntos);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PuntoInteresDTO> obtenerPuntosInteresPorProvinciaPaginados(Long provinciaId, Pageable pageable) {
        Page<PuntoInteres> puntosPage = puntoInteresRepository.findByProvinciaIdAndActivoTrueOrderByNombreAsc(provinciaId, pageable);
        return puntosPage.map(puntoInteresMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public PuntoInteresDTO obtenerPuntoInteresPorId(Long id) {
        PuntoInteres punto = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de Interés no encontrado con ID: " + id));
        return puntoInteresMapper.toDTO(punto);
    }

    @Override
    public PuntoInteresDTO crearPuntoInteres(Long provinciaId, PuntoInteresDTO puntoInteresDTO) {
        Provincia provincia = provinciaRepository.findById(provinciaId)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + provinciaId));
        PuntoInteres punto = puntoInteresMapper.toEntity(puntoInteresDTO);
        punto.setProvincia(provincia);
        punto.setActivo(true);
        PuntoInteres puntoGuardado = puntoInteresRepository.save(punto);
        return puntoInteresMapper.toDTO(puntoGuardado);
    }

    @Override
    public PuntoInteresDTO actualizarPuntoInteres(Long id, PuntoInteresDTO puntoInteresDTO) {
        PuntoInteres puntoExistente = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de Interés no encontrado con ID: " + id));
        puntoInteresMapper.updateEntityFromDTO(puntoInteresDTO, puntoExistente);
        PuntoInteres puntoActualizado = puntoInteresRepository.save(puntoExistente);
        return puntoInteresMapper.toDTO(puntoActualizado);
    }

    @Override
    public void eliminarPuntoInteres(Long id) {
        PuntoInteres puntoExistente = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de Interés no encontrado con ID: " + id));
        puntoInteresRepository.delete(puntoExistente);
    }

    @Override
    public void activarPuntoInteres(Long id) {
        PuntoInteres puntoExistente = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de Interés no encontrado con ID: " + id));
        puntoExistente.setActivo(true);
        puntoInteresRepository.save(puntoExistente);
    }

    @Override
    public void desactivarPuntoInteres(Long id) {
        PuntoInteres puntoExistente = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de Interés no encontrado con ID: " + id));
        puntoExistente.setActivo(false);
        puntoInteresRepository.save(puntoExistente);
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////

    @Override
    @Transactional(readOnly = true)
    public Page<EstadisticaProvinciaDTO> obtenerEstadisticasPaginadas(Long provinciaId, Pageable pageable) {
        Page<EstadisticaProvincia> estadisticasPage = estadisticaProvinciaRepository.findByProvinciaIdOrderByAnoActualizacionDesc(provinciaId, pageable);
        return estadisticasPage.map(estadisticaProvinciaMapper::toDTO);
    }

    @Override
    public EstadisticaProvinciaDTO crearEstadistica(Long provinciaId, EstadisticaProvinciaDTO estadisticaDTO) {
        Provincia provincia = provinciaRepository.findById(provinciaId)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + provinciaId));
        EstadisticaProvincia estadistica = estadisticaProvinciaMapper.toEntity(estadisticaDTO);
        estadistica.setProvincia(provincia);
        EstadisticaProvincia estadisticaGuardada = estadisticaProvinciaRepository.save(estadistica);
        return estadisticaProvinciaMapper.toDTO(estadisticaGuardada);
    }

    @Override
    public EstadisticaProvinciaDTO actualizarEstadistica(Long id, EstadisticaProvinciaDTO estadisticaDTO) {
        EstadisticaProvincia estadisticaExistente = estadisticaProvinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Estadística no encontrada con ID: " + id));
        estadisticaProvinciaMapper.updateEntityFromDTO(estadisticaDTO, estadisticaExistente);
        EstadisticaProvincia estadisticaActualizada = estadisticaProvinciaRepository.save(estadisticaExistente);
        return estadisticaProvinciaMapper.toDTO(estadisticaActualizada);
    }

    @Override
    public void eliminarEstadistica(Long id) {
        EstadisticaProvincia estadisticaExistente = estadisticaProvinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Estadística no encontrada con ID: " + id));
        estadisticaProvinciaRepository.delete(estadisticaExistente);
    }


    @Override
    @Transactional(readOnly = true)
    public List<HistoriaProvinciaDTO> obtenerHistoriaPorProvincia(Long provinciaId) {
        List<HistoriaProvincia> historia = historiaProvinciaRepository
                .findByProvinciaIdAndActivoTrueOrderByOrdenCronologicoAsc(provinciaId);
        return historiaProvinciaMapper.toDTOList(historia);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<HistoriaProvinciaDTO> obtenerHistoriaPorProvinciaPaginada(Long provinciaId, Pageable pageable) {
        // The repository method does not support Pageable, so implement pagination manually
        List<HistoriaProvincia> historiaList = historiaProvinciaRepository.findByProvinciaIdAndActivoTrueOrderByOrdenCronologicoAsc(provinciaId);
        int start = (int) pageable.getOffset();
        int end = Math.min((start + pageable.getPageSize()), historiaList.size());
        List<HistoriaProvincia> subList = historiaList.subList(start, end);
        return new org.springframework.data.domain.PageImpl<>(
                subList.stream().map(historiaProvinciaMapper::toDTO).toList(),
                pageable,
                historiaList.size()
        );
    }

    @Override
    @Transactional(readOnly = true)
    public HistoriaProvinciaDTO obtenerEventoHistoricoPorId(Long id) {
        HistoriaProvincia evento = historiaProvinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Evento histórico no encontrado con ID: " + id));
        return historiaProvinciaMapper.toDTO(evento);
    }

    @Override
    public HistoriaProvinciaDTO crearEventoHistorico(Long provinciaId, HistoriaProvinciaDTO historiaProvinciaDTO) {
        Provincia provincia = provinciaRepository.findById(provinciaId)
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + provinciaId));
        HistoriaProvincia evento = historiaProvinciaMapper.toEntity(historiaProvinciaDTO);
        evento.setProvincia(provincia);
        evento.setActivo(true);
        HistoriaProvincia eventoGuardado = historiaProvinciaRepository.save(evento);
        return historiaProvinciaMapper.toDTO(eventoGuardado);
    }

    @Override
    public HistoriaProvinciaDTO actualizarEventoHistorico(Long id, HistoriaProvinciaDTO historiaProvinciaDTO) {
        HistoriaProvincia eventoExistente = historiaProvinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Evento histórico no encontrado con ID: " + id));
        historiaProvinciaMapper.updateEntityFromDTO(historiaProvinciaDTO, eventoExistente);
        HistoriaProvincia eventoActualizado = historiaProvinciaRepository.save(eventoExistente);
        return historiaProvinciaMapper.toDTO(eventoActualizado);
    }

    @Override
    public void eliminarEventoHistorico(Long id) {
        HistoriaProvincia eventoExistente = historiaProvinciaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Evento histórico no encontrado con ID: " + id));
        eventoExistente.setActivo(false);
        historiaProvinciaRepository.save(eventoExistente);
    }
}
