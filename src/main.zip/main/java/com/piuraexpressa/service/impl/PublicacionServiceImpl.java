package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.PublicacionDTO;
import com.piuraexpressa.model.Publicacion;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.model.UsuarioLikePublicacion;
import com.piuraexpressa.repository.PublicacionRepository;
import com.piuraexpressa.repository.UsuarioLikePublicacionRepository;
import com.piuraexpressa.service.PublicacionService;
import com.piuraexpressa.util.MapperUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Duration;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PublicacionServiceImpl implements PublicacionService {

    private final PublicacionRepository publicacionRepository;
    private final UsuarioLikePublicacionRepository likeRepository;

    // ---------- CRUD ----------
    @Override
    public Page<PublicacionDTO> obtenerTodasPaginadas(Pageable pageable, Long usuarioId) {
        return publicacionRepository.findAll(pageable)
                .map(publicacion -> mapearConExtras(publicacion, usuarioId));
    }

    @Override
    public Optional<PublicacionDTO> obtenerPorId(Long id, Long usuarioId) {
        return publicacionRepository.findById(id)
                .map(publicacion -> mapearConExtras(publicacion, usuarioId));
    }

    @Override
    public PublicacionDTO guardar(PublicacionDTO dto) {
        Publicacion entidad = MapperUtil.toEntity(dto);
        entidad.setActiva(true);
        entidad.setFechaCreacion(LocalDateTime.now());
        entidad.setFechaActualizacion(LocalDateTime.now());
        Publicacion guardada = publicacionRepository.save(entidad);
        return MapperUtil.toDto(guardada);
    }

    @Override
    public PublicacionDTO actualizar(Long id, PublicacionDTO dto) {
        Long usuarioId = dto.getUsuarioId();
        if (usuarioId == null || !puedeEditar(id, usuarioId)) {
            return null; // No tiene permiso
        }
        return publicacionRepository.findById(id).map(actual -> {
            actual.setTitulo(dto.getTitulo());
            actual.setContenido(dto.getContenido());
            actual.setImagen(dto.getImagen());
            actual.setFechaActualizacion(LocalDateTime.now());
            Publicacion actualizada = publicacionRepository.save(actual);
            return MapperUtil.toDto(actualizada);
        }).orElseThrow(() -> new RuntimeException("Publicación no encontrada"));
    }

    @Override
    public void eliminar(Long id) {
        // Método obsoleto, se recomienda usar eliminarConPermiso
        publicacionRepository.deleteById(id);
    }

    @Override
    @Transactional
    public boolean eliminarConPermiso(Long id, Long usuarioId, boolean esAdmin) {
        Optional<Publicacion> publicacionOpt = publicacionRepository.findById(id);
        if (publicacionOpt.isEmpty()) {
            return false;
        }
        Publicacion publicacion = publicacionOpt.get();
        if (publicacion.getUsuario().getId().equals(usuarioId) || esAdmin) {
            publicacionRepository.delete(publicacion);
            return true;
        }
        return false;
    }

    @Override
    @Transactional
    public void actualizarImagen(Long id, String rutaImagen) {
        publicacionRepository.findById(id).ifPresent(publicacion -> {
            publicacion.setImagen(rutaImagen);
            publicacion.setFechaActualizacion(LocalDateTime.now());
            publicacionRepository.save(publicacion);
        });
    }

    @Override
    public void activar(Long id) {
        cambiarEstado(id, true);
    }

    @Override
    public void desactivar(Long id) {
        cambiarEstado(id, false);
    }

    private void cambiarEstado(Long id, boolean activa) {
        publicacionRepository.findById(id).ifPresent(pub -> {
            pub.setActiva(activa);
            publicacionRepository.save(pub);
        });
    }

    // ---------- BÚSQUEDAS ACTIVAS ----------
    @Override
    public Page<PublicacionDTO> obtenerActivasPaginadas(Pageable pageable, Long usuarioId) {
        return publicacionRepository.findByActivaTrueOrderByFechaCreacionDesc(pageable)
                .map(publicacion -> mapearConExtras(publicacion, usuarioId));
    }

    @Override
    public Page<PublicacionDTO> obtenerActivasPorUsuario(Long usuarioId, Pageable pageable) {
        Page<Publicacion> publicaciones = publicacionRepository
                .findByUsuarioIdOrderByFechaCreacionDesc(usuarioId, pageable);
        return publicaciones.map(publicacion -> mapearConExtras(publicacion, usuarioId));
    }

    // ---------- BÚSQUEDAS POR USUARIO ----------
    @Override
    public Page<PublicacionDTO> obtenerPorUsuarioPaginadas(Long usuarioId, Pageable pageable) {
        return publicacionRepository.findByUsuarioIdOrderByFechaCreacionDesc(usuarioId, pageable)
                .map(publicacion -> mapearConExtras(publicacion, usuarioId));
    }

    // ---------- BÚSQUEDA POR TEXTO ----------
    @Override
    public Page<PublicacionDTO> buscarPorTexto(String searchTerm, Pageable pageable) {
        return publicacionRepository.findBySearchTerm(searchTerm, pageable)
                .map(publicacion -> mapearConExtras(publicacion, null));
    }

    // ---------- DESTACADAS ----------
    @Override
    public List<PublicacionDTO> obtenerMasComentadas(int limite) {
        return publicacionRepository.findMostCommented(Pageable.ofSize(limite)).stream()
                .map(publicacion -> mapearConExtras(publicacion, null))
                .collect(Collectors.toList());
    }

    @Override
    public List<PublicacionDTO> obtenerMasLikeadas(int limite) {
        return publicacionRepository.findMostLiked(Pageable.ofSize(limite)).stream()
                .map(publicacion -> mapearConExtras(publicacion, null))
                .collect(Collectors.toList());
    }

    @Override
    public List<PublicacionDTO> obtenerRecientes(int limite) {
        return publicacionRepository.findByActivaTrueOrderByFechaCreacionDesc(Pageable.ofSize(limite)).stream()
                .map(publicacion -> mapearConExtras(publicacion, null))
                .collect(Collectors.toList());
    }

    // ---------- CONTADORES ----------
    @Override
    public long contarTodas() {
        return publicacionRepository.count();
    }

    @Override
    public long contarActivas() {
        return publicacionRepository.countByActivaTrue();
    }

    @Override
    public long contarPorUsuario(Long usuarioId) {
        return publicacionRepository.countByUsuarioId(usuarioId);
    }

    @Override
    public long contarActivasPorUsuario(Long usuarioId) {
        return publicacionRepository.countByUsuarioIdAndActivaTrue(usuarioId);
    }

    // ---------- LIKES ----------
    @Override
    public void darLike(Long publicacionId, Long usuarioId) {
        String tipoReaccion = "like";
        if (!likeRepository.existsByUsuarioIdAndPublicacionIdAndTipoReaccion(usuarioId, publicacionId, tipoReaccion)) {
            UsuarioLikePublicacion like = new UsuarioLikePublicacion();
            like.setId(new UsuarioLikePublicacion.UsuarioLikePublicacionId(usuarioId, publicacionId));
            like.setPublicacion(new Publicacion(publicacionId)); // Constructor con ID
            like.setUsuario(new Usuario(usuarioId)); // Constructor con ID
            like.setTipoReaccion(tipoReaccion);
            like.setFechaLike(LocalDateTime.now());
            likeRepository.save(like);
        }
    }
        // ... otros métodos ...

    @Override
    @Transactional
    public void quitarLike(Long publicacionId, Long usuarioId) {
        String tipoReaccion = "like";
        likeRepository.deleteByUsuarioIdAndPublicacionIdAndTipoReaccion(usuarioId, publicacionId, tipoReaccion);
    }

    @Override
    public void darReaccion(Long publicacionId, Long usuarioId, String tipoReaccion) {
        if (!likeRepository.existsByUsuarioIdAndPublicacionIdAndTipoReaccion(usuarioId, publicacionId, tipoReaccion)) {
            UsuarioLikePublicacion reaccion = new UsuarioLikePublicacion();
            reaccion.setPublicacion(new Publicacion(publicacionId));
            reaccion.setUsuario(new Usuario(usuarioId));
            reaccion.setTipoReaccion(tipoReaccion);
            reaccion.setFechaLike(LocalDateTime.now());
            likeRepository.save(reaccion);
        }
    }

    @Override
    public void quitarReaccion(Long publicacionId, Long usuarioId, String tipoReaccion) {
        likeRepository.deleteByUsuarioIdAndPublicacionIdAndTipoReaccion(usuarioId, publicacionId, tipoReaccion);
    }

    @Override
    public boolean usuarioHaDadoReaccion(Long publicacionId, Long usuarioId, String tipoReaccion) {
        return likeRepository.existsByUsuarioIdAndPublicacionIdAndTipoReaccion(usuarioId, publicacionId, tipoReaccion);
    }

    @Override
    public long contarReacciones(Long publicacionId, String tipoReaccion) {
        return likeRepository.countByPublicacionId(publicacionId); // Puede mejorarse para contar por tipoReaccion si se añade método en repositorio
    }

    @Override
    public boolean usuarioHaDadoLike(Long publicacionId, Long usuarioId) {
        return likeRepository.existsByUsuarioIdAndPublicacionId(usuarioId, publicacionId);
    }

    @Override
    public long contarLikes(Long publicacionId) {
        return likeRepository.countByPublicacionId(publicacionId);
    }

    // ---------- PERMISOS ----------
    @Override
    public boolean puedeEditar(Long publicacionId, Long usuarioId) {
        return publicacionRepository.findById(publicacionId)
                .map(p -> p.getUsuario().getId().equals(usuarioId))
                .orElse(false);
    }

    @Override
    public boolean puedeEliminar(Long publicacionId, Long usuarioId) {
        return puedeEditar(publicacionId, usuarioId); // misma lógica
    }

    // ---------- UTILIDAD ----------
    private PublicacionDTO mapearConExtras(Publicacion publicacion, Long usuarioId) {
        PublicacionDTO dto = MapperUtil.toDto(publicacion);
        dto.setTotalLikes((int) contarLikes(publicacion.getId()));
        dto.setTiempoTranscurrido(obtenerTiempoTranscurrido(publicacion.getFechaCreacion()));
        if (usuarioId != null) {
            dto.setPuedeEditar(puedeEditar(publicacion.getId(), usuarioId));
            dto.setPuedeEliminar(puedeEliminar(publicacion.getId(), usuarioId));
        } else {
            dto.setPuedeEditar(false);
            dto.setPuedeEliminar(false);
        }
        return dto;
    }

    private String obtenerTiempoTranscurrido(LocalDateTime fecha) {
        Duration duracion = Duration.between(fecha, LocalDateTime.now());
        if (duracion.toMinutes() < 60)
            return duracion.toMinutes() + " min";
        if (duracion.toHours() < 24)
            return duracion.toHours() + " h";
        return duracion.toDays() + " d";
    }

    @Override
    public boolean reportarPublicacion(Long publicacionId, String username) {
        // TODO: Implementar lógica para reportar publicación
        // Por ejemplo, crear un registro en tabla reportes con usuario y publicación
        return true;
    }

    @Override
    public boolean guardarPublicacion(Long publicacionId, String username) {
        // TODO: Implementar lógica para guardar publicación
        // Por ejemplo, crear un registro en tabla guardados con usuario y publicación
        return true;
    }

    @Override
    public boolean compartirPublicacion(Long publicacionId, String username) {
        // TODO: Implementar lógica para compartir publicación
        // Por ejemplo, incrementar contador de compartidos o registrar evento
        return true;
    }
}
