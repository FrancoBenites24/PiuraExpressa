package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.PuntoInteresDTO;
import com.piuraexpressa.exception.ResourceNotFoundException;
import com.piuraexpressa.mapper.PuntoInteresMapper;
import com.piuraexpressa.model.PuntoInteres;
import com.piuraexpressa.model.Provincia;
import com.piuraexpressa.repository.PuntoInteresRepository;
import com.piuraexpressa.repository.ProvinciaRepository;
import com.piuraexpressa.service.PuntoInteresService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

@Service
@RequiredArgsConstructor
@Slf4j
@Transactional
public class PuntoInteresServiceImpl implements PuntoInteresService {

    private final PuntoInteresRepository puntoInteresRepository;
    private final ProvinciaRepository provinciaRepository;
    private final PuntoInteresMapper puntoInteresMapper;

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerTodos() {
        log.debug("Obteniendo todos los puntos de interés");
        List<PuntoInteres> puntosInteres = puntoInteresRepository.findAll();
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PuntoInteresDTO> obtenerTodosPaginados(Pageable pageable) {
        log.debug("Obteniendo puntos de interés paginados: {}", pageable);
        Page<PuntoInteres> puntosInteres = puntoInteresRepository.findAll(pageable);
        return puntosInteres.map(puntoInteresMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public Optional<PuntoInteresDTO> obtenerPorId(Long id) {
        log.debug("Obteniendo punto de interés por ID: {}", id);
        return puntoInteresRepository.findById(id)
                .map(puntoInteresMapper::toDTO);
    }

    @Override
    public PuntoInteresDTO guardar(PuntoInteresDTO puntoInteresDTO) {
        log.debug("Guardando nuevo punto de interés: {}", puntoInteresDTO.getNombre());
        
        // Validar que la provincia existe
        Provincia provincia = provinciaRepository.findById(puntoInteresDTO.getProvinciaId())
                .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + puntoInteresDTO.getProvinciaId()));

        PuntoInteres puntoInteres = puntoInteresMapper.toEntity(puntoInteresDTO);
        puntoInteres.setProvincia(provincia);
        
        PuntoInteres puntoGuardado = puntoInteresRepository.save(puntoInteres);
        
        log.info("Punto de interés guardado exitosamente: {} con ID: {}", 
                puntoGuardado.getNombre(), puntoGuardado.getId());
        
        return puntoInteresMapper.toDTO(puntoGuardado);
    }

    @Override
    public PuntoInteresDTO actualizar(Long id, PuntoInteresDTO puntoInteresDTO) {
        log.debug("Actualizando punto de interés ID: {} con datos: {}", id, puntoInteresDTO.getNombre());
        
        PuntoInteres puntoExistente = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de interés no encontrado con ID: " + id));

        // Validar provincia si cambió
        if (!puntoExistente.getProvincia().getId().equals(puntoInteresDTO.getProvinciaId())) {
            Provincia nuevaProvincia = provinciaRepository.findById(puntoInteresDTO.getProvinciaId())
                    .orElseThrow(() -> new ResourceNotFoundException("Provincia no encontrada con ID: " + puntoInteresDTO.getProvinciaId()));
            puntoExistente.setProvincia(nuevaProvincia);
        }

        puntoInteresMapper.updateEntityFromDTO(puntoInteresDTO, puntoExistente);
        PuntoInteres puntoActualizado = puntoInteresRepository.save(puntoExistente);
        
        log.info("Punto de interés actualizado exitosamente: {} con ID: {}", 
                puntoActualizado.getNombre(), puntoActualizado.getId());
        
        return puntoInteresMapper.toDTO(puntoActualizado);
    }

    @Override
    public void eliminar(Long id) {
        log.debug("Eliminando punto de interés ID: {}", id);
        
        if (!puntoInteresRepository.existsById(id)) {
            throw new ResourceNotFoundException("Punto de interés no encontrado con ID: " + id);
        }

        puntoInteresRepository.deleteById(id);
        log.info("Punto de interés eliminado exitosamente con ID: {}", id);
    }

    @Override
    public void activar(Long id) {
        log.debug("Activando punto de interés ID: {}", id);
        
        PuntoInteres puntoInteres = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de interés no encontrado con ID: " + id));

        puntoInteres.setActivo(true);
        puntoInteresRepository.save(puntoInteres);
        
        log.info("Punto de interés activado exitosamente: {}", puntoInteres.getNombre());
    }

    @Override
    public void desactivar(Long id) {
        log.debug("Desactivando punto de interés ID: {}", id);
        
        PuntoInteres puntoInteres = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de interés no encontrado con ID: " + id));

        puntoInteres.setActivo(false);
        puntoInteresRepository.save(puntoInteres);
        
        log.info("Punto de interés desactivado exitosamente: {}", puntoInteres.getNombre());
    }

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerPorProvincia(Long provinciaId) {
        log.debug("Obteniendo puntos de interés por provincia ID: {}", provinciaId);
        
        List<PuntoInteres> puntosInteres = puntoInteresRepository
                .findByProvinciaIdAndActivoTrueOrderByNombreAsc(provinciaId);
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PuntoInteresDTO> obtenerPorProvinciaPaginados(Long provinciaId, Pageable pageable) {
        log.debug("Obteniendo puntos de interés por provincia ID: {} paginados: {}", provinciaId, pageable);
        
        Page<PuntoInteres> puntosInteres = puntoInteresRepository
                .findByProvinciaIdAndActivoTrueOrderByNombreAsc(provinciaId, pageable);
        return puntosInteres.map(puntoInteresMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerPorProvinciaYTipo(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo) {
        log.debug("Obteniendo puntos de interés por provincia ID: {} y tipo: {}", provinciaId, tipo);
        
        List<PuntoInteres> puntosInteres = puntoInteresRepository
                .findByProvinciaIdAndTipoAndActivoTrueOrderByCalificacionDesc(provinciaId, tipo);
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerMejoresPorTipo(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo, int limite) {
        log.debug("Obteniendo mejores {} puntos de interés por provincia ID: {} y tipo: {}", limite, provinciaId, tipo);
        
        Pageable pageable = PageRequest.of(0, limite);
        List<PuntoInteres> puntosInteres = puntoInteresRepository
                .findTopByProvinciaAndTipo(provinciaId, tipo, pageable);
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerPorCalificacionMinima(Long provinciaId, BigDecimal calificacionMinima) {
        log.debug("Obteniendo puntos de interés por provincia ID: {} con calificación mínima: {}", 
                provinciaId, calificacionMinima);
        
        List<PuntoInteres> puntosInteres = puntoInteresRepository
                .findByProvinciaIdAndActivoTrueAndCalificacionGreaterThanEqualOrderByCalificacionDesc(
                        provinciaId, calificacionMinima);
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerPorRangoPrecios(Long provinciaId, BigDecimal precioMin, BigDecimal precioMax) {
        log.debug("Obteniendo puntos de interés por provincia ID: {} con rango de precios: {} - {}", 
                provinciaId, precioMin, precioMax);
        
        List<PuntoInteres> puntosInteres = puntoInteresRepository
                .findByProvinciaIdAndActivoTrueAndPrecioPromedioBetweenOrderByPrecioPromedioAsc(
                        provinciaId, precioMin, precioMax);
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PuntoInteresDTO> obtenerCercanos(BigDecimal latitud, BigDecimal longitud, double radioKm) {
        log.debug("Obteniendo puntos de interés cercanos a lat: {}, lng: {}, radio: {} km", 
                latitud, longitud, radioKm);
        
        // Calcular rango aproximado (1 grado ≈ 111 km)
        BigDecimal deltaGrados = BigDecimal.valueOf(radioKm / 111.0);
        BigDecimal latMin = latitud.subtract(deltaGrados);
        BigDecimal latMax = latitud.add(deltaGrados);
        BigDecimal lngMin = longitud.subtract(deltaGrados);
        BigDecimal lngMax = longitud.add(deltaGrados);
        
        List<PuntoInteres> puntosInteres = puntoInteresRepository
                .findByCoordinatesRange(latMin, latMax, lngMin, lngMax);
        return puntoInteresMapper.toDTOList(puntosInteres);
    }

    @Override
    @Transactional(readOnly = true)
    public Page<PuntoInteresDTO> buscarPorTexto(String searchTerm, Pageable pageable) {
        log.debug("Buscando puntos de interés por texto: '{}' paginado: {}", searchTerm, pageable);
        
        Page<PuntoInteres> puntosInteres = puntoInteresRepository.findBySearchTerm(searchTerm, pageable);
        return puntosInteres.map(puntoInteresMapper::toDTO);
    }

    @Override
    @Transactional(readOnly = true)
    public long contarPorProvinciaYTipo(Long provinciaId, PuntoInteres.TipoPuntoInteres tipo) {
        log.debug("Contando puntos de interés por provincia ID: {} y tipo: {}", provinciaId, tipo);
        
        return puntoInteresRepository.countByProvinciaIdAndTipoAndActivoTrue(provinciaId, tipo);
    }

    @Override
    public void actualizarCalificacion(Long id, BigDecimal nuevaCalificacion) {
        log.debug("Actualizando calificación del punto de interés ID: {} a: {}", id, nuevaCalificacion);
        
        PuntoInteres puntoInteres = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de interés no encontrado con ID: " + id));

        puntoInteres.setCalificacion(nuevaCalificacion);
        puntoInteresRepository.save(puntoInteres);
        
        log.info("Calificación actualizada para punto de interés: {}", puntoInteres.getNombre());
    }

    @Override
    public void incrementarResenas(Long id) {
        log.debug("Incrementando número de reseñas del punto de interés ID: {}", id);
        
        PuntoInteres puntoInteres = puntoInteresRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Punto de interés no encontrado con ID: " + id));

        puntoInteres.setNumeroResenas(puntoInteres.getNumeroResenas() + 1);
        puntoInteresRepository.save(puntoInteres);
        
        log.info("Número de reseñas incrementado para punto de interés: {}", puntoInteres.getNombre());
    }
}
