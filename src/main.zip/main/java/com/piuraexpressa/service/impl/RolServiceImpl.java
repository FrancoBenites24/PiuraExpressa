package com.piuraexpressa.service.impl;

import com.piuraexpressa.model.Rol;
import com.piuraexpressa.repository.RolRepository;
import com.piuraexpressa.service.RolService;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class RolServiceImpl implements RolService {

    private final RolRepository rolRepositorio;

    @Override
    public Page<Rol> listarTodos(Pageable pageable) {
        return rolRepositorio.findAll(pageable);
    }

    @Override
    public Optional<Rol> buscarPorId(Long id) {
        return rolRepositorio.findById(id);
    }

    @Override
    public Optional<Rol> buscarPorNombre(String nombre) {
        return rolRepositorio.buscarPorNombre(nombre);
    }

    @Override
    public Rol guardar(Rol rol) {
        return rolRepositorio.save(rol);
    }

    @Override
    public void eliminar(Long id) {
        rolRepositorio.deleteById(id);
    }
}
