package com.piuraexpressa.service.impl;

import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.repository.UsuarioRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Collection;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
@RequiredArgsConstructor
@Slf4j
public class UserDetailsServiceImpl implements UserDetailsService {

    private final UsuarioRepository usuarioRepository;

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        log.debug("Cargando usuario por username: {}", username);

        Usuario usuario = usuarioRepository.findByUsernameAndActivoTrue(username)
                .orElseThrow(() -> {
                    log.error("Usuario no encontrado: {}", username);
                    return new UsernameNotFoundException("Usuario no encontrado: " + username);
                });

        Collection<GrantedAuthority> authorities = usuario.getRoles().stream()
                .flatMap(rol -> {
                    // Agregar rol como autoridad con prefijo ROLE_
                    Stream<GrantedAuthority> rolAuthority = Stream.of(new SimpleGrantedAuthority("ROLE_" + rol.getNombre()));
                    // Agregar permisos del rol como autoridades
                    Stream<GrantedAuthority> permisoAuthorities = rol.getPermisos().stream()
                            .map(permiso -> new SimpleGrantedAuthority(permiso.getNombre()));
                    // Combinar rol y permisos
                    return Stream.concat(rolAuthority, permisoAuthorities);
                })
                .collect(Collectors.toList());

        log.debug("Usuario cargado exitosamente: {} con roles: {}", username, authorities);
        // Log adicional para mostrar permisos cargados
        authorities.forEach(auth -> log.debug("Permiso cargado: {}", auth.getAuthority()));

        return User.builder()
                .username(usuario.getUsername())
                .password(usuario.getPassword())
                .authorities(authorities)
                .accountExpired(false)
                .accountLocked(!usuario.isActivo())
                .credentialsExpired(false)
                .disabled(!usuario.isActivo())
                .build();
    }
}
