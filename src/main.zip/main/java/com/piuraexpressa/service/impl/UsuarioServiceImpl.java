package com.piuraexpressa.service.impl;

import com.piuraexpressa.dto.UsuarioDTO;
import com.piuraexpressa.mapper.UsuarioMapper;
import com.piuraexpressa.model.Rol;
import com.piuraexpressa.model.Usuario;
import com.piuraexpressa.model.UsuarioRol;
import com.piuraexpressa.model.UsuarioRolId;
import com.piuraexpressa.repository.RolRepository;
import com.piuraexpressa.repository.UsuarioRepository;
import com.piuraexpressa.repository.UsuarioRolRepository;
import com.piuraexpressa.service.UsuarioService;

import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class UsuarioServiceImpl implements UsuarioService {

    private final UsuarioRepository usuarioRepository;
    private final UsuarioMapper usuarioMapper;
    private final RolRepository rolRepository;
    private final UsuarioRolRepository usuarioRolRepository;

    @Override
    public Page<UsuarioDTO> listarTodos(Pageable pageable) {
        return usuarioRepository.findAll(pageable)
                .map(usuarioMapper::toDto);
    }

    @Override
    public Optional<UsuarioDTO> buscarPorId(Long id) {
        return usuarioRepository.findById(id).map(usuarioMapper::toDto);
    }

    @Override
    public Optional<UsuarioDTO> buscarPorEmail(String email) {
        return usuarioRepository.buscarPorEmail(email).map(usuarioMapper::toDto);
    }

    @Override
    public Optional<UsuarioDTO> buscarPorUsername(String username) {
        return usuarioRepository.buscarPorUsername(username).map(usuarioMapper::toDto);
    }

    @Override
    public UsuarioDTO guardar(UsuarioDTO dto) {
        Usuario usuario = usuarioMapper.toEntidad(dto);
        return usuarioMapper.toDto(usuarioRepository.save(usuario));
    }

    @Override
    public void eliminar(Long id) {
        usuarioRepository.deleteById(id);
    }

    @Override
    public Page<UsuarioDTO> buscarUsuariosPaginados(String filtro, String provincia, Pageable pageable) {
        // Esto es ejemplo, debes implementar el método real en el repositorio
        return usuarioRepository.findAll(pageable) // ← reemplazar por búsqueda filtrada real
                .map(usuarioMapper::toDto);
    }

    @Override
    public void desactivar(Long id) {
        usuarioRepository.findById(id).ifPresent(usuario -> {
            usuario.setActivo(false);
            usuarioRepository.save(usuario);
        });
    }

    @Override
    public void activar(Long id) {
        usuarioRepository.findById(id).ifPresent(usuario -> {
            usuario.setActivo(true);
            usuarioRepository.save(usuario);
        });
    }

    @Override
    public void cambiarRolUsuario(Long usuarioId, Long rolId) {
        Optional<Usuario> usuarioOpt = usuarioRepository.findById(usuarioId);
        Optional<Rol> rolOpt = rolRepository.findById(rolId);

        if (usuarioOpt.isPresent() && rolOpt.isPresent()) {
            Usuario usuario = usuarioOpt.get();
            Rol rol = rolOpt.get();

            UsuarioRolId id = new UsuarioRolId(usuario.getId(), rol.getId());
            UsuarioRol relacion = new UsuarioRol(id, usuario, rol);
            usuarioRolRepository.save(relacion);
        }
    }
}
